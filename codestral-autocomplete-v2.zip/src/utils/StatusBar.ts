import * as vscode from 'vscode';

export enum StatusBarStatus {
    Disabled = 'disabled',
    Enabled = 'enabled',
    Loading = 'loading',
    Error = 'error'
}

export class StatusBarManager {
    private statusBarItem: vscode.StatusBarItem;
    private currentStatus: StatusBarStatus = StatusBarStatus.Disabled;
    private loadingTimeout: NodeJS.Timeout | undefined;

    constructor() {
        this.statusBarItem = vscode.window.createStatusBarItem(
            vscode.StatusBarAlignment.Right,
            100
        );
        this.statusBarItem.command = 'codestral-autocomplete.toggle';
        this.updateStatusBar();
        this.statusBarItem.show();
    }

    setStatus(status: StatusBarStatus): void {
        this.currentStatus = status;
        this.updateStatusBar();
    }

    setLoading(loading: boolean): void {
        if (loading) {
            this.setStatus(StatusBarStatus.Loading);
            // Auto-clear loading after 5 seconds to prevent stuck loading state
            this.loadingTimeout = setTimeout(() => {
                if (this.currentStatus === StatusBarStatus.Loading) {
                    this.setStatus(StatusBarStatus.Enabled);
                }
            }, 5000);
        } else {
            if (this.loadingTimeout) {
                clearTimeout(this.loadingTimeout);
                this.loadingTimeout = undefined;
            }
            // Only clear loading if currently loading
            if (this.currentStatus === StatusBarStatus.Loading) {
                this.setStatus(StatusBarStatus.Enabled);
            }
        }
    }

    setError(hasError: boolean): void {
        if (hasError) {
            this.setStatus(StatusBarStatus.Error);
        } else if (this.currentStatus === StatusBarStatus.Error) {
            this.setStatus(StatusBarStatus.Enabled);
        }
    }

    toggle(): void {
        switch (this.currentStatus) {
            case StatusBarStatus.Disabled:
                this.setStatus(StatusBarStatus.Enabled);
                break;
            case StatusBarStatus.Enabled:
            case StatusBarStatus.Loading:
                this.setStatus(StatusBarStatus.Disabled);
                break;
            case StatusBarStatus.Error:
                this.setStatus(StatusBarStatus.Enabled);
                break;
        }
    }

    getStatus(): StatusBarStatus {
        return this.currentStatus;
    }

    isEnabled(): boolean {
        return this.currentStatus === StatusBarStatus.Enabled || 
               this.currentStatus === StatusBarStatus.Loading;
    }

    private updateStatusBar(): void {
        switch (this.currentStatus) {
            case StatusBarStatus.Disabled:
                this.statusBarItem.text = '$(circle-slash) Codestral';
                this.statusBarItem.tooltip = 'Codestral autocomplete is disabled. Click to enable.';
                this.statusBarItem.backgroundColor = undefined;
                break;
            case StatusBarStatus.Enabled:
                this.statusBarItem.text = '$(check) Codestral';
                this.statusBarItem.tooltip = 'Codestral autocomplete is enabled. Click to disable.';
                this.statusBarItem.backgroundColor = undefined;
                break;
            case StatusBarStatus.Loading:
                this.statusBarItem.text = '$(loading~spin) Codestral';
                this.statusBarItem.tooltip = 'Codestral is generating completion...';
                this.statusBarItem.backgroundColor = undefined;
                break;
            case StatusBarStatus.Error:
                this.statusBarItem.text = '$(alert) Codestral';
                this.statusBarItem.tooltip = 'Codestral autocomplete error. Check configuration and logs.';
                this.statusBarItem.backgroundColor = new vscode.ThemeColor('statusBarItem.errorBackground');
                break;
        }
    }

    dispose(): void {
        if (this.loadingTimeout) {
            clearTimeout(this.loadingTimeout);
        }
        this.statusBarItem.dispose();
    }
}
