import * as assert from 'assert';
import { processSingleLineCompletion, isSingleLineCompletion, getLastLineOfCompletion } from '../utils/processSingleLineCompletion';

suite('processSingleLineCompletion Test Suite', () => {
    
    test('should handle simple insertion at end of line', () => {
        const result = processSingleLineCompletion('hello world', '', 5);
        assert.strictEqual(result?.completionText, 'hello world');
        assert.strictEqual(result?.range, undefined);
    });

    test('should handle completion with existing text after cursor', () => {
        const result = processSingleLineCompletion('hello world', 'world', 6);
        assert.strictEqual(result?.completionText, 'hello world');
        assert.ok(result?.range);
        assert.strictEqual(result?.range?.start, 6);
        assert.strictEqual(result?.range?.end, 11); // 6 + 'world'.length
    });

    test('should handle midline insertion', () => {
        const result = processSingleLineCompletion('hello', 'world', 0);
        assert.strictEqual(result?.completionText, 'hello');
        assert.strictEqual(result?.range, undefined);
    });

    test('should return undefined for empty completion', () => {
        const result = processSingleLineCompletion('', 'existing', 0);
        assert.strictEqual(result?.completionText, '');
    });

    test('should handle completion that partially matches existing text', () => {
        const result = processSingleLineCompletion('function test()', 'test()', 9);
        assert.ok(result);
        assert.strictEqual(result.completionText, 'function test()');
    });
});

suite('isSingleLineCompletion Test Suite', () => {
    
    test('should return true for single line', () => {
        assert.strictEqual(isSingleLineCompletion('hello world'), true);
    });

    test('should return false for multi-line', () => {
        assert.strictEqual(isSingleLineCompletion('hello\nworld'), false);
    });

    test('should return true for empty string', () => {
        assert.strictEqual(isSingleLineCompletion(''), true);
    });

    test('should return false for string with multiple newlines', () => {
        assert.strictEqual(isSingleLineCompletion('line1\nline2\nline3'), false);
    });
});

suite('getLastLineOfCompletion Test Suite', () => {
    
    test('should return the string itself for single line', () => {
        assert.strictEqual(getLastLineOfCompletion('hello world'), 'hello world');
    });

    test('should return last line for multi-line', () => {
        assert.strictEqual(getLastLineOfCompletion('line1\nline2\nline3'), 'line3');
    });

    test('should return empty string for empty input', () => {
        assert.strictEqual(getLastLineOfCompletion(''), '');
    });

    test('should handle string ending with newline', () => {
        assert.strictEqual(getLastLineOfCompletion('line1\nline2\n'), '');
    });

    test('should handle single newline', () => {
        assert.strictEqual(getLastLineOfCompletion('\n'), '');
    });
});
