import * as Diff from "diff";

export interface SingleLineCompletionResult {
    completionText: string;
    range?: {
        start: number;
        end: number;
    };
}

interface DiffType {
    count?: number;
    added?: boolean;
    removed?: boolean;
    value: string;
}

type DiffPartType = "+" | "-" | "=";

function diffPatternMatches(
    diffs: DiffType[],
    pattern: DiffPartType[]
): boolean {
    if (diffs.length !== pattern.length) {
        return false;
    }

    for (let i = 0; i < diffs.length; i++) {
        const diff = diffs[i];
        const diffPartType: DiffPartType = !diff.added && !diff.removed
            ? "="
            : diff.added
            ? "+"
            : "-";

        if (diffPartType !== pattern[i]) {
            return false;
        }
    }

    return true;
}

/**
 * Process single-line completions to handle proper text replacement and positioning.
 * This is adapted from Continue's proven implementation for handling inline completions.
 * 
 * @param lastLineOfCompletionText The completion text for the current line
 * @param currentText The current text on the line after the cursor
 * @param cursorPosition The current cursor position on the line
 * @returns Processed completion result with text and optional range
 */
export function processSingleLineCompletion(
    lastLineOfCompletionText: string,
    currentText: string,
    cursorPosition: number
): SingleLineCompletionResult | undefined {
    // Use word-level diff to understand the relationship between current text and completion
    const diffs: DiffType[] = Diff.diffWords(
        currentText,
        lastLineOfCompletionText
    );

    // Case 1: Just insert at the end (most common case)
    if (diffPatternMatches(diffs, ["+"])) {
        return {
            completionText: lastLineOfCompletionText,
        };
    }

    // Case 2: Model repeated text after cursor to end of line
    // This handles cases where the model includes existing text in its completion
    if (
        diffPatternMatches(diffs, ["+", "="]) ||
        diffPatternMatches(diffs, ["+", "=", "+"])
    ) {
        return {
            completionText: lastLineOfCompletionText,
            range: {
                start: cursorPosition,
                end: currentText.length + cursorPosition,
            },
        };
    }

    // Case 3: Midline insertion/replacement
    // Model inserted without repeating to end of line
    if (
        diffPatternMatches(diffs, ["+", "-"]) ||
        diffPatternMatches(diffs, ["-", "+"])
    ) {
        return {
            completionText: lastLineOfCompletionText,
        };
    }

    // Case 4: Use first added part if available
    if (diffs[0]?.added) {
        return {
            completionText: diffs[0].value,
        };
    }

    // Default case: treat as simple insertion
    return {
        completionText: lastLineOfCompletionText,
    };
}

/**
 * Check if a completion should be processed as single-line
 * @param completion The completion text
 * @returns True if completion is single-line
 */
export function isSingleLineCompletion(completion: string): boolean {
    return completion.split('\n').length <= 1;
}

/**
 * Extract the last line from a multi-line completion
 * @param completion The completion text
 * @returns The last line of the completion
 */
export function getLastLineOfCompletion(completion: string): string {
    return completion.split('\n').pop() || '';
}
