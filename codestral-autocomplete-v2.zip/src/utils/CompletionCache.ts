import LRUCache = require('lru-cache');

export class CompletionCache {
    private cache: LRUCache<string, string>;
    private static instance: CompletionCache;

    private constructor() {
        this.cache = new LRUCache<string, string>({
            max: 1000, // Maximum number of cached completions
            ttl: 1000 * 60 * 10, // 10 minutes TTL
            updateAgeOnGet: true,
        });
    }

    static getInstance(): CompletionCache {
        if (!CompletionCache.instance) {
            CompletionCache.instance = new CompletionCache();
        }
        return CompletionCache.instance;
    }

    /**
     * Generate a cache key from prefix and suffix
     */
    private generateKey(prefix: string, suffix: string = ''): string {
        // Use a hash-like approach to create a consistent key
        // Take last 200 chars of prefix and first 50 chars of suffix for reasonable key size
        const prefixPart = prefix.length > 200 ? prefix.slice(-200) : prefix;
        const suffixPart = suffix.length > 50 ? suffix.slice(0, 50) : suffix;
        return `${prefixPart}|||${suffixPart}`;
    }

    /**
     * Get cached completion
     */
    get(prefix: string, suffix: string = ''): string | undefined {
        const key = this.generateKey(prefix, suffix);
        return this.cache.get(key);
    }

    /**
     * Store completion in cache
     */
    set(prefix: string, suffix: string = '', completion: string): void {
        const key = this.generateKey(prefix, suffix);
        this.cache.set(key, completion);
    }

    /**
     * Check if completion exists in cache
     */
    has(prefix: string, suffix: string = ''): boolean {
        const key = this.generateKey(prefix, suffix);
        return this.cache.has(key);
    }

    /**
     * Clear all cached completions
     */
    clear(): void {
        this.cache.clear();
    }

    /**
     * Get cache statistics
     */
    getStats(): { size: number; max: number } {
        return {
            size: this.cache.size,
            max: this.cache.max,
        };
    }
}
