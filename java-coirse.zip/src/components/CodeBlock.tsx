
"use client";

import { useState, useActionState } from "react";
import { useFormStatus } from "react-dom";
import { Button } from "@/components/ui/button";
import { Check, Copy, Sparkles, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { getExplanation, type ExplainState } from "@/app/actions";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";

interface CodeBlockProps {
  code: string;
  language: string;
}

// By moving the Dialog's content into its own component, we can ensure that its
// state (including the useActionState hook) is completely reset every time the
// dialog is opened. This is because we will only render this component when
// the dialog is open, so it gets mounted and unmounted, clearing its state.
function ExplainDialogContent({ code, language }: CodeBlockProps) {
  const initialState: ExplainState = {};
  const [state, formAction] = useActionState(getExplanation, initialState);

  return (
    <DialogContent className="sm:max-w-[625px]">
      <form action={formAction}>
        <input type="hidden" name="code" value={code} />
        <input type="hidden" name="language" value={language} />
        <DialogHeader>
          <DialogTitle className="font-headline">AI Explanation</DialogTitle>
        </DialogHeader>
        <div className="py-4">
          {state.explanation ? (
            <div className="prose prose-sm dark:prose-invert max-h-[60vh] overflow-y-auto rounded-md border p-4">
              <p>{state.explanation}</p>
            </div>
          ) : state.error ? (
              <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{state.error}</AlertDescription>
            </Alert>
          ) : (
            <div>
                <p className="text-sm text-muted-foreground mb-4">The AI will explain this code snippet:</p>
              <pre className="text-xs bg-muted text-muted-foreground p-4 rounded-md overflow-x-auto max-h-48">
                  <code>{code}</code>
              </pre>
            </div>
          )}
        </div>
        <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Close</Button>
          </DialogClose>
          {/* Only show the generate button if we don't have a result yet */}
          {!state.explanation && !state.error && <SubmitButton />}
        </DialogFooter>
      </form>
    </DialogContent>
  );
}


export function CodeBlock({ code, language }: CodeBlockProps) {
  const [isCopied, setIsCopied] = useState(false);
  const [open, setOpen] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };
  
  return (
    <div className="relative group my-4 rounded-lg bg-[#282c34] text-white">
      <div className="absolute top-2 right-2 flex items-center space-x-2">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 hover:text-white"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Explain
            </Button>
          </DialogTrigger>
          {/* Conditionally rendering the content ensures its state is reset when closed and reopened */}
          {open && <ExplainDialogContent code={code} language={language} />}
        </Dialog>
        <Button
          variant="ghost"
          size="sm"
          onClick={copyToClipboard}
          className="text-white hover:bg-white/20 hover:text-white"
        >
          {isCopied ? (
            <Check className="h-4 w-4" />
          ) : (
            <Copy className="h-4 w-4" />
          )}
          <span className="sr-only">Copy code</span>
        </Button>
      </div>
      <pre
        className={cn(
          "p-4 overflow-x-auto text-sm rounded-lg font-code",
          `language-${language}`
        )}
      >
        <code>{code}</code>
      </pre>
    </div>
  );
}


function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? (
        <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Please wait</>
      ) : (
        "Generate Explanation"
      )}
    </Button>
  );
}
