import { courseData } from "@/lib/course-data";
import { notFound } from "next/navigation";
import { ContentSection } from "@/components/ContentSection";

export function generateStaticParams() {
    return courseData
        .filter((part) => part.slug !== "final-exam")
        .map((part) => ({
            slug: part.slug,
        }));
}

export default async function CoursePartPage({ params }: { params: { slug: string } }) {
    // Immediately delegate "final-exam" to its own page.
    // This prevents this component from processing a route it shouldn't handle.
    if (params.slug === "final-exam") {
        notFound();
    }
    
    const part = courseData.find((p) => p.slug === params.slug);

    // If no corresponding part is found in the data, show a 404 page.
    if (!part) {
        notFound();
    }
    
    const titleParts = part.title.split(/:\s(.*)/s);
    const partLabel = titleParts.length > 1 ? titleParts[0] : null;
    const mainTitle = titleParts.length > 1 ? titleParts[1] : titleParts[0];


    return (
        <article className="max-w-4xl mx-auto p-6 sm:p-8 md:p-12">
            <header className="mb-8">
                {partLabel && <p className="text-primary font-bold font-headline">{partLabel}</p>}
                <h1 className="text-4xl font-bold font-headline tracking-tight mt-1">{mainTitle}</h1>
                <p className="text-lg text-muted-foreground mt-2">{part.description}</p>
            </header>
            
            <div className="space-y-12">
                {part.sections.map((section, index) => (
                    <section key={index}>
                        <h2 className="font-headline text-3xl font-semibold border-b pb-2 mb-6">{section.title}</h2>
                        <ContentSection content={section.content} slug={params.slug} />
                    </section>
                ))}
            </div>
        </article>
    );
}
