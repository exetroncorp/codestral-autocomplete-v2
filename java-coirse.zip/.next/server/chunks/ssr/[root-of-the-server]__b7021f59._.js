module.exports = {

"[externals]/perf_hooks [external] (perf_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("perf_hooks", () => require("perf_hooks"));

module.exports = mod;
}}),
"[externals]/node:perf_hooks [external] (node:perf_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:perf_hooks", () => require("node:perf_hooks"));

module.exports = mod;
}}),
"[externals]/async_hooks [external] (async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("async_hooks", () => require("async_hooks"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[externals]/os [external] (os, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}}),
"[externals]/process [external] (process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}}),
"[externals]/child_process [external] (child_process, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/require-in-the-middle [external] (require-in-the-middle, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("require-in-the-middle", () => require("require-in-the-middle"));

module.exports = mod;
}}),
"[externals]/import-in-the-middle [external] (import-in-the-middle, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("import-in-the-middle", () => require("import-in-the-middle"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/tls [external] (tls, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}}),
"[externals]/net [external] (net, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}}),
"[externals]/http2 [external] (http2, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}}),
"[externals]/dns [external] (dns, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("dns", () => require("dns"));

module.exports = mod;
}}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/express [external] (express, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("express", () => require("express"));

module.exports = mod;
}}),
"[externals]/fs/promises [external] (fs/promises, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs/promises", () => require("fs/promises"));

module.exports = mod;
}}),
"[externals]/node:crypto [external] (node:crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}}),
"[project]/src/ai/genkit.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ai": (()=>ai)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/index.mjs [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$genkit$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/genkit.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$genkit$2d$ai$2f$googleai$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/@genkit-ai/googleai/lib/index.mjs [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$genkit$2d$ai$2f$googleai$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@genkit-ai/googleai/lib/index.mjs [app-rsc] (ecmascript) <locals>");
;
;
const ai = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$genkit$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["genkit"])({
    plugins: [
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$genkit$2d$ai$2f$googleai$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["googleAI"])()
    ],
    model: 'googleai/gemini-2.0-flash'
});
}}),
"[project]/src/ai/flows/explain-code-snippet.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/ai/flows/explain-code-snippet.ts
/* __next_internal_action_entry_do_not_use__ [{"40459d7c457e19ad7c4e398014f69ebd148133e6b1":"explainCodeSnippet"},"",""] */ __turbopack_context__.s({
    "explainCodeSnippet": (()=>explainCodeSnippet)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
/**
 * @fileOverview An AI agent that explains a given code snippet.
 *
 * - explainCodeSnippet - A function that takes a code snippet and returns an explanation.
 * - ExplainCodeSnippetInput - The input type for the explainCodeSnippet function.
 * - ExplainCodeSnippetOutput - The return type for the explainCodeSnippet function.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/genkit.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/index.mjs [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/genkit/lib/common.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
const ExplainCodeSnippetInputSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].object({
    codeSnippet: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('The code snippet to be explained.'),
    language: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().optional().describe('The programming language of the code snippet.')
});
const ExplainCodeSnippetOutputSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].object({
    explanation: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$genkit$2f$lib$2f$common$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string().describe('The explanation of the code snippet.')
});
async function explainCodeSnippet(input) {
    return explainCodeSnippetFlow(input);
}
const prompt = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ai"].definePrompt({
    name: 'explainCodeSnippetPrompt',
    input: {
        schema: ExplainCodeSnippetInputSchema
    },
    output: {
        schema: ExplainCodeSnippetOutputSchema
    },
    prompt: `You are an expert software developer. You are good at explaining code snippets in simple terms.

  Explain the following code snippet. If you know the language of the code, please provide a language-specific explanation. The language is optional, so you should still generate a good answer if it's not available.
  Language: {{{language}}}
  Code Snippet:
  \`\`\`{{{language}}}
  {{{codeSnippet}}}
  \`\`\`
  `
});
const explainCodeSnippetFlow = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$genkit$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ai"].defineFlow({
    name: 'explainCodeSnippetFlow',
    inputSchema: ExplainCodeSnippetInputSchema,
    outputSchema: ExplainCodeSnippetOutputSchema
}, async (input)=>{
    const { output } = await prompt(input);
    return output;
});
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    explainCodeSnippet
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(explainCodeSnippet, "40459d7c457e19ad7c4e398014f69ebd148133e6b1", null);
}}),
"[project]/src/app/actions.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"605f11402be18e4a935bbfba95aec2e7c912ad4088":"getExplanation"},"",""] */ __turbopack_context__.s({
    "getExplanation": (()=>getExplanation)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/server-reference.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$app$2d$render$2f$encryption$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/app-render/encryption.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$explain$2d$code$2d$snippet$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/ai/flows/explain-code-snippet.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/lib/index.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-validate.js [app-rsc] (ecmascript)");
;
;
;
;
const explainSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].object({
    code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string(),
    language: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["z"].string()
});
async function getExplanation(prevState, formData) {
    try {
        const { code, language } = explainSchema.parse({
            code: formData.get("code"),
            language: formData.get("language")
        });
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$explain$2d$code$2d$snippet$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["explainCodeSnippet"])({
            codeSnippet: code,
            language
        });
        return {
            explanation: result.explanation
        };
    } catch (e) {
        const error = e instanceof Error ? e.message : "An unknown error occurred.";
        return {
            error
        };
    }
}
;
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$validate$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ensureServerEntryExports"])([
    getExplanation
]);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$server$2d$reference$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerServerReference"])(getExplanation, "605f11402be18e4a935bbfba95aec2e7c912ad4088", null);
}}),
"[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/app/actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/actions.ts [app-rsc] (ecmascript)");
;
}}),
"[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/app/actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$course$292f5b$slug$5d2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => "[project]/src/app/actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/app/actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript) <exports>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "605f11402be18e4a935bbfba95aec2e7c912ad4088": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getExplanation"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/actions.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$course$292f5b$slug$5d2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => "[project]/src/app/actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <locals>');
}}),
"[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => \"[project]/src/app/actions.ts [app-rsc] (ecmascript)\" } [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "605f11402be18e4a935bbfba95aec2e7c912ad4088": (()=>__TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$course$292f5b$slug$5d2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__["605f11402be18e4a935bbfba95aec2e7c912ad4088"])
});
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$course$292f5b$slug$5d2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => "[project]/src/app/actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <module evaluation>');
var __TURBOPACK__imported__module__$5b$project$5d2f2e$next$2d$internal$2f$server$2f$app$2f28$course$292f5b$slug$5d2f$page$2f$actions$2e$js__$7b$__ACTIONS_MODULE0__$3d3e$__$225b$project$5d2f$src$2f$app$2f$actions$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$2922$__$7d$__$5b$app$2d$rsc$5d$__$28$server__actions__loader$2c$__ecmascript$29$__$3c$exports$3e$__ = __turbopack_context__.i('[project]/.next-internal/server/app/(course)/[slug]/page/actions.js { ACTIONS_MODULE0 => "[project]/src/app/actions.ts [app-rsc] (ecmascript)" } [app-rsc] (server actions loader, ecmascript) <exports>');
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}}),
"[project]/src/app/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/app/(course)/layout.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/(course)/layout.tsx [app-rsc] (ecmascript)"));
}}),
"[project]/src/lib/course-data.ts [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "courseData": (()=>courseData)
});
const courseData = [
    {
        id: "part-1",
        slug: "part-1-the-basics",
        title: "Part 1: The Basics - No Build Tools",
        description: "From source code to running application without build tools.",
        sections: [
            {
                title: "1.1 Simple Java Application",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's start with a basic example. Here's the file structure we'll use:"
                    },
                    {
                        type: "console",
                        title: "Project Structure",
                        output: `workshop/\n├── src/\n│   └── com/\n│       └── example/\n│           ├── Main.java\n│           └── util/\n│               └── Helper.java\n└── lib/\n    └── gson-2.8.9.jar`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "Main.java",
                        code: `package com.example;\nimport com.example.util.Helper;\nimport com.google.gson.Gson;\n\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello from Main!");\n        Helper.greet();\n        \n        Gson gson = new Gson();\n        String json = gson.toJson("Hello JSON");\n        System.out.println("JSON: " + json);\n    }\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "Helper.java",
                        code: `package com.example.util;\n\npublic class Helper {\n    public static void greet() {\n        System.out.println("Hello from Helper!");\n    }\n}`
                    }
                ]
            },
            {
                title: "1.2 Manual Compilation",
                content: [
                    {
                        type: "code",
                        language: "bash",
                        title: "Compilation Command",
                        code: `# Create output directory\nmkdir -p build/classes\n\n# Compile with external library\njavac -d build/classes \\\n      -cp lib/gson-2.8.9.jar \\\n      src/com/example/*.java \\\n      src/com/example/util/*.java`
                    },
                    {
                        type: "paragraph",
                        text: "What happens here:\n- `-d build/classes`: Sets the output directory for compiled `.class` files.\n- `-cp lib/gson-2.8.9.jar`: Specifies the classpath, telling the compiler where to find external dependencies like GSON.\n- `src/com/example/*.java ...`: The source files to compile."
                    }
                ]
            },
            {
                title: "1.3 Manual Execution",
                content: [
                    {
                        type: "code",
                        language: "bash",
                        title: "Execution Command",
                        code: `java -cp build/classes:lib/gson-2.8.9.jar com.example.Main`
                    },
                    {
                        type: "paragraph",
                        text: "What happens here:\n- `-cp build/classes:lib/gson-2.8.9.jar`: Defines the runtime classpath, which includes our compiled classes and the GSON library.\n- `com.example.Main`: The fully qualified name of the class containing the `main` method."
                    },
                    {
                        type: "console",
                        title: "Expected Output",
                        output: `Hello from Main!\nHello from Helper!\nJSON: "Hello JSON"`
                    },
                    {
                        type: "quiz",
                        question: "In the `javac` command, what does the `-d` flag do?",
                        options: [
                            "Specifies a dependency",
                            "Sets the destination directory for .class files",
                            "Disables debugging information",
                            "Defines the main class"
                        ],
                        correctAnswer: "Sets the destination directory for .class files",
                        explanation: "The `-d` flag in `javac` specifies the destination directory where the compiled `.class` files will be placed, preserving the package structure."
                    }
                ]
            }
        ]
    },
    {
        id: "part-2",
        slug: "part-2-understanding-classpath",
        title: "Part 2: Understanding Classpath",
        description: "Learn what the classpath is and how it works.",
        sections: [
            {
                title: "2.1 What is Classpath?",
                content: [
                    {
                        type: "paragraph",
                        text: "The classpath is a crucial parameter for the Java Virtual Machine (JVM) that specifies the locations of user-defined classes and packages. It tells the JVM where to find:\n1. Your compiled classes (.class files)\n2. External libraries (.jar files)\n3. Resources (properties files, images, etc.)"
                    }
                ]
            },
            {
                title: "2.2 Classpath Examples",
                content: [
                    {
                        type: "code",
                        language: "bash",
                        title: "Classpath Examples",
                        code: `# Multiple directories and JARs (Unix/macOS)\njava -cp "build/classes:lib/gson.jar:lib/commons-lang.jar:resources" com.example.Main\n\n# Using wildcards (for all JARs in a directory)\njava -cp "build/classes:lib/*:resources" com.example.Main\n\n# Windows example (note the semicolons)\njava -cp "build\\classes;lib\\*;resources" com.example.Main`
                    }
                ]
            },
            {
                title: "2.3 Classpath Investigation",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's create a utility to inspect the classpath at runtime."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "ClasspathInspector.java",
                        code: `package com.example;\nimport java.net.URL;\nimport java.net.URLClassLoader;\n\npublic class ClasspathInspector {\n    public static void main(String[] args) {\n        System.out.println("=== CLASSPATH INVESTIGATION ===");\n        \n        String classpath = System.getProperty("java.class.path");\n        System.out.println("System Classpath:");\n        for (String path : classpath.split(System.getProperty("path.separator"))) {\n            System.out.println("  " + path);\n        }\n        \n        ClassLoader cl = ClasspathInspector.class.getClassLoader();\n        if (cl instanceof URLClassLoader) {\n            System.out.println("\\nClassLoader URLs:");\n            for (URL url : ((URLClassLoader) cl).getURLs()) {\n                System.out.println("  " + url);\n            }\n        }\n    }\n}`
                    },
                    {
                        type: "quiz",
                        question: "What character is used to separate multiple paths in a Java classpath on Windows?",
                        options: [
                            ": (colon)",
                            ", (comma)",
                            "; (semicolon)",
                            "& (ampersand)"
                        ],
                        correctAnswer: "; (semicolon)",
                        explanation: "Windows uses a semicolon (`;`) to separate entries in the classpath, while Unix-like systems (Linux, macOS) use a colon (`:`)."
                    }
                ]
            }
        ]
    },
    {
        id: "part-3",
        slug: "part-3-resources-and-working-directory",
        title: "Part 3: Resources & Working Directory",
        description: "Learn how to load resources and the importance of the working directory.",
        sections: [
            {
                title: "3.1 Resources Example",
                content: [
                    {
                        type: "paragraph",
                        text: "Resources are non-code files bundled with your application. Here's a typical setup:"
                    },
                    {
                        type: "console",
                        title: "Project Structure",
                        output: `workshop/\n├── src/\n│   └── com/example/ResourceDemo.java\n├── resources/\n│   ├── config.properties\n│   └── data/\n│       └── sample.json\n└── build/\n    └── classes/`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "ResourceDemo.java",
                        code: `package com.example;\nimport java.io.*;\nimport java.util.Properties;\n\npublic class ResourceDemo {\n    public static void main(String[] args) throws Exception {\n        System.out.println("Working Directory: " + System.getProperty("user.dir"));\n        \n        // Method 1: Using ClassLoader (from classpath)\n        try (InputStream stream = ResourceDemo.class.getClassLoader()\n            .getResourceAsStream("config.properties")) {\n            if (stream != null) {\n                Properties props = new Properties();\n                props.load(stream);\n                System.out.println("From classpath: " + props.getProperty("app.name"));\n            } else {\n                 System.out.println("Resource 'config.properties' not found in classpath.");\n            }\n        }\n    }\n}`
                    },
                    {
                        type: "code",
                        language: "properties",
                        title: "config.properties",
                        code: `app.name=My Workshop App\napp.version=1.0`
                    }
                ]
            },
            {
                title: "3.2 Running with Resources",
                content: [
                    {
                        type: "paragraph",
                        text: "To make resources available, they must be on the classpath."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Running with Resources",
                        code: `# Option 1: Copy resources to the classes directory\ncp -r resources/* build/classes/\njava -cp build/classes com.example.ResourceDemo\n\n# Option 2: Add the 'resources' directory to the classpath\njava -cp build/classes:resources com.example.ResourceDemo`
                    },
                    {
                        type: "quiz",
                        question: "What is the recommended way to load a resource file that is bundled inside your JAR?",
                        options: [
                            "new File(\"path/to/resource\")",
                            "ClassLoader.getResourceAsStream(\"resource/name.txt\")",
                            "System.getProperty(\"resource.path\")",
                            "Reading from an absolute file path"
                        ],
                        correctAnswer: "ClassLoader.getResourceAsStream(\"resource/name.txt\")",
                        explanation: "`ClassLoader.getResourceAsStream` is the standard, reliable way to access resources from the classpath, as it works whether the resource is in a folder or packed inside a JAR file."
                    }
                ]
            }
        ]
    },
    {
        id: "part-4",
        slug: "part-4-a-glimpse-inside-the-jvm",
        title: "Part 4: A Glimpse Inside the JVM",
        description: "Understand the Java Virtual Machine that runs your code.",
        sections: [
            {
                title: "4.1 What is the JVM?",
                content: [
                    {
                        type: "paragraph",
                        text: "The Java Virtual Machine (JVM) is the engine that drives the Java ecosystem. It's an abstract computing machine that enables a computer to run a Java program. The primary goal of the JVM is to make Java platform-independent."
                    },
                    {
                        type: "paragraph",
                        text: "This leads to the famous slogan: **\"Write Once, Run Anywhere\" (WORA)**. You can compile your Java code on a Windows machine, and the resulting `.class` files can run on any other machine (like macOS or Linux) that has a compliant JVM installed, without any changes. The JVM acts as a translation layer between your compiled Java code (bytecode) and the specific operating system and hardware it's running on."
                    }
                ]
            },
            {
                title: "4.2 The Journey of a .class File",
                content: [
                    {
                        type: "paragraph",
                        text: "When you compile a `.java` file, you get a `.class` file containing platform-neutral bytecode. This bytecode is the set of instructions for the JVM. Here is a high-level overview of what happens when you run `java MyApp`."
                    },
                    {
                        type: "diagram",
                        diagram: `MyApp.java
    |
 (javac)
    |
    v
MyApp.class (Bytecode)
    |
 (java MyApp)
    |
    v
+-----------------------------------------------------------------+
|                         JVM Instance                            |
|                                                                 |
|  [Class Loader Subsystem] ---> [Runtime Data Areas] <--- [Execution Engine] |
|   - Loads .class files       - Heap (Objects live here)  - Interpreter      |
|   - Links & Initializes      - Stack (Method calls)      - JIT Compiler     |
|                              - Method Area (Class data)  - Garbage Collector|
|                                                                 |
+-----------------------------------------------------------------+
    |
    v
[Native Machine Code -> Runs on Host OS/CPU]`
                    },
                    {
                        type: "paragraph",
                        text: "The `.class` file is first loaded into memory by the Class Loader Subsystem. It's verified and prepared, and memory is allocated for it in the Runtime Data Areas. Finally, a component of the JVM called the Execution Engine runs the bytecode, either by interpreting it or by compiling it 'just-in-time' into native machine code for much faster execution."
                    }
                ]
            },
            {
                title: "4.3 Key JVM Components",
                content: [
                    {
                        type: "paragraph",
                        text: "The JVM has several key parts that work together:"
                    },
                    {
                        type: "table",
                        headers: [
                            "Component",
                            "Description"
                        ],
                        rows: [
                            [
                                {
                                    text: "Class Loader",
                                    highlight: true
                                },
                                "Responsible for dynamically loading Java classes into the JVM at runtime. It finds the `.class` files (using the classpath), loads their bytecode, and prepares them for execution."
                            ],
                            [
                                {
                                    text: "Heap",
                                    highlight: false
                                },
                                "The primary memory area where all objects created by your application are stored. This memory is shared among all threads and is managed by the Garbage Collector."
                            ],
                            [
                                {
                                    text: "Stack",
                                    highlight: false
                                },
                                "Each thread in the JVM has its own private stack. It stores frames for each method invocation, containing local variables, parameters, and partial results. When a method is called, a new frame is pushed onto the stack; when it completes, the frame is popped."
                            ],
                            [
                                {
                                    text: "Method Area / Metaspace",
                                    highlight: false
                                },
                                "A shared memory area that stores per-class structures, such as the runtime constant pool, field and method data, and the code for methods."
                            ],
                            [
                                {
                                    text: "Execution Engine",
                                    highlight: true
                                },
                                "This is the core of the JVM. It executes the bytecode from the loaded `.class` files. It contains an **Interpreter** (reads and executes bytecode line by line) and a **Just-In-Time (JIT) Compiler** (compiles frequently used 'hot' bytecode into native machine code for significant performance boosts)."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "4.4 Garbage Collection (GC) 101",
                content: [
                    {
                        type: "paragraph",
                        text: "One of the most important features of the JVM is automatic memory management, also known as Garbage Collection (GC). Instead of you having to manually allocate and deallocate memory, the GC automatically reclaims memory occupied by objects that are no longer in use by the application."
                    },
                    {
                        type: "paragraph",
                        text: "A common GC strategy is called **Mark and Sweep**. It works in two phases:\n1.  **Mark Phase:** The GC starts from a set of 'root' objects (like variables on the stack) and traverses the entire object graph, marking every object it can reach as 'in use'.\n2.  **Sweep Phase:** The GC then scans the entire heap and reclaims the memory used by any object that was not marked. These are the 'garbage' objects."
                    },
                    {
                        type: "diagram",
                        diagram: `        [HEAP]
    (Before GC)
    [ Obj A (root) ] -> [ Obj B ] -> [ Obj C ]

    [ Obj D (lost) ]

    (After GC)
    [ Obj A (root) ] -> [ Obj B ] -> [ Obj C ]

    [ <free memory>  ]

1. Mark: Start from roots (e.g., stack variables), find all reachable objects (A, B, C).
2. Sweep: Go through the heap and remove all unmarked (unreachable) objects (D).`
                    },
                    {
                        type: "quiz",
                        question: "In the JVM, where are objects created by your application primarily stored?",
                        options: [
                            "The Stack",
                            "The Heap",
                            "PC Registers",
                            "The Method Area"
                        ],
                        correctAnswer: "The Heap",
                        explanation: "The Heap is the runtime data area from which memory for all class instances and arrays is allocated. It is the main memory resource managed by the Garbage Collector."
                    }
                ]
            }
        ]
    },
    {
        id: "part-5",
        slug: "part-5-mavens-role",
        title: "Part 5: Maven's Role",
        description: "Understand how Maven automates compilation and packaging.",
        sections: [
            {
                title: "5.1 What Maven Does",
                content: [
                    {
                        type: "paragraph",
                        text: "Maven is a powerful build automation tool that automates the manual processes we've covered. It handles dependency management, compilation, testing, and packaging based on conventions and a central `pom.xml` file."
                    }
                ]
            },
            {
                title: "5.2 Maven Directory Structure",
                content: [
                    {
                        type: "paragraph",
                        text: "Maven expects a standard project layout, known as 'convention over configuration'."
                    },
                    {
                        type: "console",
                        title: "Standard Maven Layout",
                        output: `my-project/\n├── pom.xml\n├── src/\n│   ├── main/\n│   │   ├── java/          # Source code\n│   │   └── resources/     # Resources (copied to classpath)\n│   └── test/\n│       ├── java/          # Test code\n│       └── resources/     # Test resources\n└── target/                  # Build output\n    ├── classes/           # Compiled main classes + resources\n    └── my-project.jar     # Final JAR`
                    }
                ]
            },
            {
                title: "5.3 Maven Commands Explained",
                content: [
                    {
                        type: "paragraph",
                        text: "Here's what happens behind the scenes for common Maven commands:"
                    },
                    {
                        type: "diagram",
                        diagram: `[pom.xml] ----------> [Maven] ------> Downloads Dependencies (from Maven Central)
                        |
[src/main/java] ----> Compiles Code ----> [target/classes]
                        ^
                        |
[src/main/resources] -> Copies Resources --+
                        |
                        +--> Runs Tests
                        |
                        +--> Packages into JAR -> [target/my-project.jar]`
                    },
                    {
                        type: "console",
                        title: "mvn compile",
                        output: `→ Downloads dependencies\n→ Runs: javac -d target/classes -cp [...] src/main/java/**/*.java\n→ Runs: cp src/main/resources/* target/classes/`
                    },
                    {
                        type: "console",
                        title: "mvn package",
                        output: `→ Runs 'compile' phase first\n→ Runs tests\n→ Runs: jar -cf target/my-project.jar -C target/classes .`
                    },
                    {
                        type: "console",
                        title: "mvn exec:java",
                        output: `→ Runs 'compile' phase first\n→ Runs: java -cp target/classes:[all-runtime-dependencies] com.example.Main`
                    },
                    {
                        type: "quiz",
                        question: "In a standard Maven project, where should you place your main application's resource files?",
                        options: [
                            "src/main/java",
                            "src/resources",
                            "src/main/resources",
                            "resources/"
                        ],
                        correctAnswer: "src/main/resources",
                        explanation: "Maven's convention is to place application resources in `src/main/resources`. These files are then automatically copied to the `target/classes` directory during the build process, making them available on the classpath."
                    }
                ]
            }
        ]
    },
    {
        id: "part-6",
        slug: "part-6-spring-boots-role",
        title: "Part 6: Spring Boot's Role",
        description: "Discover how Spring Boot creates self-contained, executable 'fat JARs'.",
        sections: [
            {
                title: "6.1 What is a JAR and How Does it Become Executable?",
                content: [
                    {
                        type: "paragraph",
                        text: "A JAR (Java ARchive) file is a package file format used to aggregate many Java class files, associated metadata, and resources into one distributable file. It's essentially a ZIP file with a `.jar` extension."
                    },
                    {
                        type: "paragraph",
                        text: "But how does `java -jar myapp.jar` know which class to run? This is a standard Java feature, not something specific to Maven or Spring Boot. It works using a special file inside the JAR called `META-INF/MANIFEST.MF`."
                    },
                    {
                        type: "paragraph",
                        text: "This manifest file can contain a `Main-Class` attribute. When you execute `java -jar myapp.jar`, the JVM looks inside the JAR for this manifest file, reads the value of `Main-Class`, and then executes the `main` method of that specified class."
                    },
                    {
                        type: "console",
                        title: "Example MANIFEST.MF",
                        output: `Manifest-Version: 1.0\nMain-Class: com.example.MyApplication`
                    },
                    {
                        type: "paragraph",
                        text: "So, the ability to run a JAR directly is a core Java feature. The magic of different build tools and frameworks lies in *what* they put into the manifest and how they structure the JAR file around it."
                    }
                ]
            },
            {
                title: "6.2 The Dependency Problem: Why Nested JARs Don't Work",
                content: [
                    {
                        type: "paragraph",
                        text: "You might be thinking, \"Why can't I just put my dependency JARs (like `gson.jar`) inside my main `myapp.jar`?\" This is an excellent question that reveals a core limitation of standard Java."
                    },
                    {
                        type: "paragraph",
                        text: "The reason is that the default Java ClassLoader—the component responsible for finding and loading `.class` files at runtime—can only load code from directories or from the root of JAR files listed directly on the classpath. It **does not know how to look *inside* a JAR file to find *another* nested JAR file** and then load classes from it.\n\nIf you were to place `gson.jar` inside `myapp.jar`, the JVM would simply not be able to find any of the GSON classes when your code runs, resulting in a `NoClassDefFoundError`."
                    },
                    {
                        type: "paragraph",
                        text: "This is the core dependency problem with standard JARs. To run the application, you must place your JAR (`myapp.jar`) and all of its dependency JARs (`gson.jar`, etc.) side-by-side and list them all explicitly on the classpath."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "The Manual Classpath Requirement",
                        code: `# You need to manually provide every single dependency on the classpath!\njava -cp "app.jar:lib/spring-core.jar:lib/spring-web.jar:lib/tomcat.jar:..." com.example.Main`
                    }
                ]
            },
            {
                title: "6.3 The Spring Boot Way: A Smarter Fat JAR",
                content: [
                    {
                        type: "paragraph",
                        text: "So, if `java -jar` is a standard feature and nested JARs don't work by default, what does Spring Boot do that's special? It cleverly uses this standard mechanism. Instead of setting `Main-Class` to *your* application's main class, the `spring-boot-maven-plugin` sets it to a special launcher class provided by Spring Boot itself, like `org.springframework.boot.loader.launch.JarLauncher`."
                    },
                    {
                        type: "paragraph",
                        text: "When you run `java -jar my-app.jar`, you are actually running the `JarLauncher`. This launcher then does two crucial things:\n1. It creates a special ClassLoader that **knows how to find and load classes from the nested dependency JARs** located in the `BOOT-INF/lib/` directory inside the main JAR.\n2. Once the ClassLoader is ready, the launcher finds your *actual* main class (the one annotated with `@SpringBootApplication`, which it discovers from another manifest entry) and invokes its `main` method."
                    },
                    {
                        type: "diagram",
                        diagram: `my-app.jar
├── BOOT-INF/
│   ├── classes/           # Your compiled code (com/example/Main.class)
│   └── lib/               # All dependencies NESTED as is (spring-core.jar, etc.)
├── META-INF/
│   └── MANIFEST.MF        # Main-Class points to Spring Boot's launcher
└── org/
    └── springframework/
        └── boot/
            └── loader/    # Spring Boot's custom ClassLoader code`
                    }
                ]
            },
            {
                title: "6.4 A Spring Boot Example",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's see what this looks like in practice. Here is a very simple `pom.xml` for a Spring Boot web application. It has one core dependency: `spring-boot-starter-web`."
                    },
                    {
                        type: "code",
                        language: "xml",
                        title: "pom.xml (partial)",
                        code: `<dependencies>\n    <dependency>\n        <groupId>org.springframework.boot</groupId>\n        <artifactId>spring-boot-starter-web</artifactId>\n    </dependency>\n</dependencies>\n\n<build>\n    <plugins>\n        <plugin>\n            <groupId>org.springframework.boot</groupId>\n            <artifactId>spring-boot-maven-plugin</artifactId>\n        </plugin>\n    </plugins>\n</build>`
                    },
                    {
                        type: "paragraph",
                        text: "The `<dependency>` pulls in Spring's web framework, which in turn pulls in other dependencies like Tomcat. The crucial part is the `<plugin>`. The `spring-boot-maven-plugin`'s `repackage` goal is what takes the standard JAR that Maven creates and re-packages it into the special fat JAR structure we've been discussing."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "DemoApplication.java",
                        code: `package com.example.demo;\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\nimport org.springframework.web.bind.annotation.GetMapping;\nimport org.springframework.web.bind.annotation.RestController;\n\n@SpringBootApplication\n@RestController\npublic class DemoApplication {\n\n    public static void main(String[] args) {\n        SpringApplication.run(DemoApplication.class, args);\n    }\n\n    @GetMapping("/")\n    public String hello() {\n        return "Hello from Spring Boot!";\n    }\n}`
                    },
                    {
                        type: "paragraph",
                        text: "When you run `mvn package`, this code gets compiled, and the plugin creates an executable JAR. The `MANIFEST.MF` inside will point to Spring's launcher, *not* `com.example.demo.DemoApplication`."
                    }
                ]
            },
            {
                title: "6.5 Deconstructing the Spring Boot Application",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's break down the key parts of our `DemoApplication.java` to understand what's happening."
                    },
                    {
                        type: "table",
                        headers: [
                            "Annotation / Method",
                            "What It Does"
                        ],
                        rows: [
                            [
                                {
                                    text: "@SpringBootApplication",
                                    highlight: true
                                },
                                "A master annotation that combines three key annotations: `@Configuration`, `@EnableAutoConfiguration`, and `@ComponentScan`. It's the primary entry point for Spring Boot features."
                            ],
                            [
                                {
                                    text: "    @EnableAutoConfiguration",
                                    highlight: false
                                },
                                "Tells Spring Boot to intelligently configure your application based on the JAR dependencies you have on the classpath. For example, because `spring-boot-starter-web` is present, it automatically sets up an embedded Tomcat server and configures Spring MVC."
                            ],
                            [
                                {
                                    text: "    @ComponentScan",
                                    highlight: false
                                },
                                "Tells Spring to scan the current package (`com.example.demo`) and its sub-packages for other components, configurations, and services to register as beans in the application context."
                            ],
                            [
                                {
                                    text: "@RestController",
                                    highlight: true
                                },
                                "A convenience annotation that combines `@Controller` and `@ResponseBody`. It marks the class as a web controller, and tells Spring that the return value of methods within this class should be written directly to the HTTP response body (e.g., as JSON) instead of being resolved to a view template."
                            ],
                            [
                                {
                                    text: "SpringApplication.run(...)",
                                    highlight: true
                                },
                                "This static method bootstraps the entire application. It creates the Spring Application Context, runs the auto-configuration process, and starts the embedded web server, making the application ready to handle requests."
                            ],
                            [
                                {
                                    text: "    DemoApplication.class",
                                    highlight: false
                                },
                                "This is a Java **class literal**. In Java, every class has a special static variable named `class` that provides a `Class` object representing the class at runtime. This object contains all the class's metadata, such as its name, methods, and—most importantly for Spring—its annotations. It's how you refer to the class itself as an object.\n\n**Purpose:** Passing `DemoApplication.class` tells Spring Boot \"start everything from here.\" It serves two main purposes for Spring:\n1.  **Primary Configuration Source:** Spring examines this class object for annotations, most importantly `@SpringBootApplication`, which kicks off all of Spring Boot's magic.\n2.  **Component Scan Anchor:** Spring uses the package of this class (in this case, `com.example.demo`) as the starting point to scan for other components, services, and configurations (`@Component`, `@RestController`, etc.) you've defined in your project."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "6.6 Spring Boot Execution",
                content: [
                    {
                        type: "paragraph",
                        text: "This clever packaging simplifies execution dramatically."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Running a Spring Boot Application",
                        code: `# No more complex classpath needed!\njava -jar my-spring-boot-app.jar`
                    },
                    {
                        type: "paragraph",
                        text: "This single command works because the JVM runs Spring Boot's `JarLauncher` (specified in the manifest), which then correctly sets up its custom classpath from the nested JARs and runs your application."
                    },
                    {
                        type: "quiz",
                        question: "Why can't a standard `java -jar` command run an application with its dependencies nested as JARs inside the main JAR?",
                        options: [
                            "It's a security restriction",
                            "The default Java ClassLoader cannot read from nested JARs",
                            "The MANIFEST.MF file does not support it",
                            "It requires a special license from Oracle"
                        ],
                        correctAnswer: "The default Java ClassLoader cannot read from nested JARs",
                        explanation: "The core Java ClassLoader is designed to load from directories and JARs on the classpath, but not from JARs contained within other JARs. Spring Boot solves this by providing its own launcher and custom ClassLoader."
                    }
                ]
            }
        ]
    },
    {
        id: "part-7",
        slug: "part-7-spring-boot-magic",
        title: "Part 7: Spring Boot Magic - Under the Hood",
        description: "A deeper look at auto-configuration and component scanning.",
        sections: [
            {
                title: "7.1 The Power of DemoApplication.class",
                content: [
                    {
                        type: "paragraph",
                        text: "As we saw, passing `DemoApplication.class` to `SpringApplication.run()` is the key that starts the engine. Let's explore the two main jobs it performs for Spring Boot:\n\n1.  **Primary Configuration Source:** It acts as the main configuration file for the entire application.\n2.  **Component Scan Anchor:** It defines the starting point for finding all your other application components."
                    },
                    {
                        type: "paragraph",
                        text: "First, a quick refresher on the syntax. `DemoApplication.class` is a **Java class literal**. In Java, every class has a special static variable named `class` that provides a `java.lang.Class` object. This object represents the class itself at runtime and contains all its metadata, like its name, its methods, and, most importantly for Spring, its annotations. It's how you can pass a class around like any other object."
                    }
                ]
            },
            {
                title: "7.2 Purpose 1: Primary Configuration Source",
                content: [
                    {
                        type: "paragraph",
                        text: "When Spring receives the `DemoApplication.class` object, the first thing it does is inspect it for annotations. The `@SpringBootApplication` annotation is the most important one. It's a master switch that enables Spring Boot's **auto-configuration** feature."
                    },
                    {
                        type: "paragraph",
                        text: "Auto-configuration is Spring's way of being helpful. It looks at the dependencies (the JARs) you've included in your `pom.xml` and makes intelligent guesses about how you want to configure your application.\n\n- **If it sees `spring-boot-starter-web`:** It assumes you want to build a web application. It will then automatically start and configure an embedded Tomcat web server and set up the necessary components to handle HTTP requests (like Spring MVC's `DispatcherServlet`).\n- **If it sees `spring-boot-starter-data-jpa` and a database driver like `h2`:** It assumes you want to connect to a database. It will then automatically configure a data source, an entity manager, and other necessary beans for database interaction.\n\nThis all happens without you writing a single line of XML or Java configuration for these components. It's convention over configuration, driven by the dependencies you've chosen."
                    }
                ]
            },
            {
                title: "7.3 Purpose 2: Component Scan Anchor",
                content: [
                    {
                        type: "paragraph",
                        text: "The second job is to act as a starting point for **component scanning**. The `@SpringBootApplication` annotation also includes `@ComponentScan`. This tells Spring: \"Look in the package of this class, and all of its sub-packages, for any other classes marked with annotations like `@Component`, `@Service`, `@Repository`, or `@RestController`.\"\n\nLet's see an example. Imagine this project structure:"
                    },
                    {
                        type: "console",
                        title: "Example Project Structure",
                        output: `src/main/java/\n└── com/\n    └── example/\n        └── myapp/\n            ├── Application.java          // Our main class with @SpringBootApplication\n            ├── controller/\n            │   └── UserController.java   // A @RestController\n            └── service/\n                └── UserService.java      // A @Service`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "Application.java",
                        code: `package com.example.myapp;\n\nimport org.springframework.boot.SpringApplication;\nimport org.springframework.boot.autoconfigure.SpringBootApplication;\n\n@SpringBootApplication\npublic class Application {\n    public static void main(String[] args) {\n        SpringApplication.run(Application.class, args);\n    }\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "UserController.java",
                        code: `package com.example.myapp.controller;\n\nimport com.example.myapp.service.UserService;\nimport org.springframework.web.bind.annotation.RestController;\nimport org.springframework.beans.factory.annotation.Autowired;\n\n@RestController\npublic class UserController {\n    @Autowired\n    private UserService userService; // Spring will inject this!\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "UserService.java",
                        code: `package com.example.myapp.service;\n\nimport org.springframework.stereotype.Service;\n\n@Service\npublic class UserService {\n    public String getUser() {\n        return "John Doe";\n    }\n}`
                    },
                    {
                        type: "paragraph",
                        text: "Because `Application.java` is in the `com.example.myapp` package, the component scan automatically finds `UserController` (in `com.example.myapp.controller`) and `UserService` (in `com.example.myapp.service`). Spring then creates instances of these classes (called 'beans') and manages their lifecycle. It's even smart enough to handle the `@Autowired` annotation in `UserController` and inject the `UserService` bean into it.\n\nIf you were to place `UserService` in a different package, like `com.another.package`, Spring would *not* find it by default."
                    },
                    {
                        type: "quiz",
                        question: "If you place a `@Service` annotated class in a package *outside* the package tree of your main `@SpringBootApplication` class, what happens by default?",
                        options: [
                            "Spring Boot automatically finds and registers it.",
                            "It will not be found or registered as a Spring bean.",
                            "The application will fail to compile.",
                            "You will get a warning at runtime."
                        ],
                        correctAnswer: "It will not be found or registered as a Spring bean.",
                        explanation: "By default, `@ComponentScan` (part of `@SpringBootApplication`) only scans the package of the main class and its sub-packages. To include other packages, you must explicitly configure them using the `@ComponentScan` annotation with package names."
                    }
                ]
            },
            {
                title: "7.4 The Magic of @Autowired: Dependency Injection",
                content: [
                    {
                        type: "paragraph",
                        text: "In our `UserController` example, we saw the `@Autowired` annotation. This is where Spring's most powerful feature comes into play: **Dependency Injection (DI)**."
                    },
                    {
                        type: "paragraph",
                        text: "Without Spring, if `UserController` needed a `UserService`, you would have to create it yourself, like this: `private UserService userService = new UserService();`. This creates a tight coupling between the two classes. `UserController` is permanently tied to that specific implementation of `UserService`."
                    },
                    {
                        type: "paragraph",
                        text: "Dependency Injection inverts this. It's a form of a broader principle called **Inversion of Control (IoC)**. Instead of your object controlling the creation of its dependencies, control is inverted: the Spring Framework *controls* the creation of objects (called 'beans') and 'injects' them where they are needed. `UserController` no longer creates `UserService`; it simply declares that it needs one, and Spring provides it."
                    },
                    {
                        type: "diagram",
                        diagram: `   [Spring IoC Container]
(manages all beans it knows about)
  /------------------\\
  | @Service         |
  |  UserService bean|
  \\------------------/
       |
       |  @Autowired
       +-------------> [UserController]
                       |
                       | private UserService userService;
                       |  (Spring injects the bean here)
                       \\--------------------------------/`
                    },
                    {
                        type: "paragraph",
                        text: "The benefits are immense. Your components are decoupled, making them easier to manage, reuse, and, critically, test. In a unit test for `UserController`, you can easily inject a *mock* version of `UserService` to test the controller in isolation, without needing a real service."
                    },
                    {
                        type: "paragraph",
                        text: "So the flow is:\n1. Spring starts, component-scans, finds `@Service` on `UserService`, and creates a single instance (a bean) of it for the whole application.\n2. Spring then finds `@RestController` on `UserController` and starts creating a bean for it.\n3. It sees the `@Autowired` annotation on the `userService` field.\n4. It looks in its container of beans, finds the `UserService` bean it created in step 1, and assigns (injects) that instance into the `userService` field.\n\nAll of this happens automatically, managed by the Spring IoC container."
                    },
                    {
                        type: "quiz",
                        question: "What is the primary benefit of using Dependency Injection in Spring?",
                        options: [
                            "It makes the application run faster.",
                            "It reduces the final JAR size.",
                            "It decouples components, making them more modular and easier to test.",
                            "It automatically writes database queries for you."
                        ],
                        correctAnswer: "It decouples components, making them more modular and easier to test.",
                        explanation: "DI allows objects to receive their dependencies from an external source rather than creating them. This removes hard-coded connections between components and simplifies unit testing by allowing mock dependencies to be injected."
                    }
                ]
            }
        ]
    },
    {
        id: "part-8",
        slug: "part-8-the-world-of-spring-beans",
        title: "Part 8: The World of Spring Beans",
        description: "Learn about the fundamental building blocks of a Spring application: Beans and the IoC Container.",
        sections: [
            {
                title: "8.1 What is a Spring Bean?",
                content: [
                    {
                        type: "paragraph",
                        text: "In Spring, a **bean** is simply an object that is instantiated, assembled, and otherwise managed by a Spring **Inversion of Control (IoC) container**. They are the fundamental building blocks of any Spring application."
                    },
                    {
                        type: "paragraph",
                        text: "Think of them not as special, magical entities, but as the regular Java objects (POJOs - Plain Old Java Objects) that form the backbone of your application. When we annotated `UserService` with `@Service` or `UserController` with `@RestController`, we were telling Spring: \"Please create an instance of this class for me, and manage it. Make it a bean.\""
                    },
                    {
                        type: "paragraph",
                        text: "The container gets its instructions on what to instantiate, configure, and assemble by reading configuration metadata. In modern Spring Boot, this metadata is primarily the stereotype annotations:"
                    },
                    {
                        type: "table",
                        headers: [
                            "Annotation",
                            "Purpose"
                        ],
                        rows: [
                            [
                                {
                                    text: "@Component",
                                    highlight: true
                                },
                                "The generic stereotype for any Spring-managed component. It's the base annotation."
                            ],
                            [
                                {
                                    text: "@Service",
                                    highlight: false
                                },
                                "A specialization of `@Component` for the service layer. It indicates that the class holds business logic."
                            ],
                            [
                                {
                                    text: "@Repository",
                                    highlight: false
                                },
                                "A specialization for the persistence layer. It's used on classes that access the database, and it enables Spring's exception translation feature."
                            ],
                            [
                                {
                                    text: "@Controller",
                                    highlight: false
                                },
                                "Indicates a class that handles web requests, typically returning a view name."
                            ],
                            [
                                {
                                    text: "@RestController",
                                    highlight: false
                                },
                                "A convenience annotation that combines `@Controller` and `@ResponseBody`, used for creating RESTful web services."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "8.2 The IoC Container and ApplicationContext",
                content: [
                    {
                        type: "paragraph",
                        text: "The **IoC container** is the heart of the Spring Framework. It's the factory that is responsible for creating the beans, wiring them together, configuring them, and managing their complete lifecycle. The `ApplicationContext` is the central interface in Spring for providing configuration information to the application, and it is the most commonly used implementation of the IoC container."
                    },
                    {
                        type: "diagram",
                        diagram: `+--------------------------------------------------------+
|                   ApplicationContext                       |
|                (Spring IoC Container)                      |
|                                                        |
|  +----------------+  @Autowired   +---------------------+  |
|  | UserService    |------------->|  UserController     |  |
|  | (Bean)         |<-------------|  (Bean)             |  |
|  +----------------+  (injects)    +---------------------+  |
|                                                        |
|           [Manages lifecycle: creation, wiring, destruction]           |
+--------------------------------------------------------+`
                    },
                    {
                        type: "paragraph",
                        text: "When we called `SpringApplication.run()`, we were essentially telling Spring Boot to create and initialize an `ApplicationContext`. This context then performs the component scan, finds all the classes marked as beans, instantiates them, and injects their dependencies (like injecting `UserService` into `UserController`)."
                    }
                ]
            },
            {
                title: "8.3 Understanding Bean Scopes",
                content: [
                    {
                        type: "paragraph",
                        text: "Not all beans are created equal. A bean's **scope** controls how many instances of that bean are created and how long they live. Spring defines several scopes, but the most important one by far is `singleton`."
                    },
                    {
                        type: "table",
                        headers: [
                            "Scope",
                            "Description"
                        ],
                        rows: [
                            [
                                {
                                    text: "singleton",
                                    highlight: true
                                },
                                "**(Default)** Only one single instance of the bean is created per Spring IoC container. When your code asks for this bean, the container always returns the exact same instance. This is ideal for stateless services like repositories and controllers."
                            ],
                            [
                                {
                                    text: "prototype",
                                    highlight: false
                                },
                                "A new instance of the bean is created every single time it is requested from the container. Useful for stateful objects where each user needs their own copy."
                            ],
                            [
                                {
                                    text: "request",
                                    highlight: false
                                },
                                "**(Web-aware)** A new instance is created for each individual HTTP request. Only valid in the context of a web-aware Spring ApplicationContext."
                            ],
                            [
                                {
                                    text: "session",
                                    highlight: false
                                },
                                "**(Web-aware)** A new instance is created for each HTTP session. Only valid in the context of a web-aware Spring ApplicationContext."
                            ]
                        ]
                    },
                    {
                        type: "paragraph",
                        text: "For the vast majority of applications, especially for stateless components like services, repositories, and controllers, the default `singleton` scope is exactly what you want and need."
                    }
                ]
            },
            {
                title: "8.4 Bean Lifecycle Callbacks",
                content: [
                    {
                        type: "paragraph",
                        text: "Because the container manages the beans, it knows exactly when they are created, when their dependencies are injected, and when they are about to be destroyed. This allows you to hook into the bean's lifecycle to perform custom initialization or cleanup logic."
                    },
                    {
                        type: "paragraph",
                        text: "The two most common lifecycle annotations are:\n- **`@PostConstruct`**: Marks a method to be executed *after* the bean has been created and all its dependencies have been injected. This is a perfect place to perform any initialization logic that requires those dependencies.\n- **`@PreDestroy`**: Marks a method to be executed just *before* the bean is removed from the container and destroyed. This is the ideal place for cleanup tasks, like closing a database connection or releasing other resources.\n\n*A note on imports: Since Java 9, the `javax.annotation` package is no longer included by default. The modern standard is to use the `jakarta.annotation` package, which requires the `jakarta.annotation-api` dependency. The code below uses this modern standard.*"
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "LifecycleExampleService.java",
                        code: `package com.example.myapp.service;\n\nimport jakarta.annotation.PostConstruct;\nimport jakarta.annotation.PreDestroy;\nimport org.springframework.stereotype.Service;\n\n@Service\npublic class LifecycleExampleService {\n\n    public LifecycleExampleService() {\n        System.out.println("1. Constructor called.");\n    }\n\n    @PostConstruct\n    public void init() {\n        System.out.println("2. @PostConstruct: Bean is ready, dependencies are injected. Initializing resources...");\n    }\n\n    public void doWork() {\n        System.out.println("3. Doing work...");\n    }\n\n    @PreDestroy\n    public void cleanup() {\n        System.out.println("4. @PreDestroy: Application is shutting down. Cleaning up resources...");\n    }\n}`
                    },
                    {
                        type: "console",
                        title: "Expected Log Output on Application Start/Stop",
                        output: `1. Constructor called.\n2. @PostConstruct: Bean is ready, dependencies are injected. Initializing resources...\n...\n(Application runs, doWork() might be called)\n...\n4. @PreDestroy: Application is shutting down. Cleaning up resources...`
                    },
                    {
                        type: "quiz",
                        question: "What is the default scope of a Spring bean?",
                        options: [
                            "prototype",
                            "request",
                            "session",
                            "singleton"
                        ],
                        correctAnswer: "singleton",
                        explanation: "By default, every bean defined in a Spring container is a singleton, meaning only one instance of that bean will be created and shared throughout the application."
                    }
                ]
            }
        ]
    },
    {
        id: "part-9",
        slug: "part-9-spring-profiles",
        title: "Part 9: Spring Profiles Deep Dive",
        description: "Master environment-specific configurations using Spring Profiles.",
        sections: [
            {
                title: "9.1 The Problem: One Configuration to Rule Them All?",
                content: [
                    {
                        type: "paragraph",
                        text: "As your application grows, you'll quickly realize that you need different configurations for different environments. The database connection you use for local development is not the same as the production database. You might want verbose logging in development, but only log errors in production. Hardcoding these values or constantly changing them is inefficient and dangerous."
                    },
                    {
                        type: "paragraph",
                        text: "This is a common challenge: How do you manage configuration that varies between environments like development, testing, staging, and production? Spring provides an elegant solution to this problem called **Profiles**."
                    }
                ]
            },
            {
                title: "9.2 What are Spring Profiles?",
                content: [
                    {
                        type: "paragraph",
                        text: "Spring Profiles are a core feature of the framework that allows you to register different beans and configuration properties for different environments. A profile is essentially a named, logical group of settings that is only enabled when that profile is 'active'."
                    },
                    {
                        type: "paragraph",
                        text: "The simplest way to use profiles is with property files. By default, Spring Boot applications load properties from `application.properties`. You can provide profile-specific overrides by creating new files in the format `application-{profile}.properties`."
                    },
                    {
                        type: "console",
                        title: "Profile-Specific Property Files",
                        output: `src/main/resources/\n├── application.properties       # Default properties for all profiles\n├── application-dev.properties   # Active when 'dev' profile is used\n├── application-prod.properties  # Active when 'prod' profile is used`
                    },
                    {
                        type: "paragraph",
                        text: "Properties in a specific profile file will override the ones in the default `application.properties` file when that profile is active."
                    }
                ]
            },
            {
                title: "9.3 Activating Profiles and Order of Precedence",
                content: [
                    {
                        type: "paragraph",
                        text: "To make a profile's configuration take effect, you must activate it. Spring offers several ways to do this, with a clear **order of precedence**. This means that settings from a more specific source will always override those from a less specific one. For example, a profile activated via a command-line argument will win over a profile activated in the `application.properties` file.\n\nThe table below lists the most common activation methods, ordered from lowest to highest precedence."
                    },
                    {
                        type: "table",
                        headers: [
                            "Method",
                            "Example",
                            "Notes"
                        ],
                        rows: [
                            [
                                {
                                    text: "In `application.properties`",
                                    highlight: true
                                },
                                {
                                    text: "spring.profiles.active=dev",
                                    highlight: false
                                },
                                "Lowest precedence. Good for setting a default profile, but easily overridden by any other method."
                            ],
                            [
                                {
                                    text: "Environment Variable",
                                    highlight: true
                                },
                                {
                                    text: "export SPRING_PROFILES_ACTIVE=prod",
                                    highlight: false
                                },
                                "Common in containerized/cloud environments. Overrides `application.properties` but not command-line arguments."
                            ],
                            [
                                {
                                    text: "Maven Command (System Property)",
                                    highlight: true
                                },
                                {
                                    text: "mvn spring-boot:run -Dspring-boot.run.profiles=dev",
                                    highlight: false
                                },
                                "Sets a Java System Property. This has higher precedence than environment variables for this specific goal."
                            ],
                            [
                                {
                                    text: "Command-Line Argument (for JAR)",
                                    highlight: true
                                },
                                {
                                    text: "java -jar my-app.jar --spring.profiles.active=prod",
                                    highlight: false
                                },
                                "One of the highest precedence sources. The standard way to configure a packaged application in a specific environment."
                            ]
                        ]
                    },
                    {
                        type: "paragraph",
                        text: "You can even activate multiple profiles at once by providing a comma-separated list, e.g., `--spring.profiles.active=prod,aws`."
                    }
                ]
            },
            {
                title: "9.4 Profile-Specific Beans with @Profile",
                content: [
                    {
                        type: "paragraph",
                        text: "Beyond properties, you can use the `@Profile` annotation to conditionally register entire beans. This is incredibly powerful. You can define two different beans that implement the same interface, and tell Spring to only create and use the one that matches the active profile."
                    },
                    {
                        type: "paragraph",
                        text: "Let's imagine we have a `DataSourceConfig` interface. For development, we want a simple in-memory H2 database. For production, we want to connect to a real PostgreSQL database."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "DevDataSourceConfig.java",
                        code: `package com.example.config;\n\nimport org.springframework.context.annotation.Bean;\nimport org.springframework.context.annotation.Configuration;\nimport org.springframework.context.annotation.Profile;\n\n@Configuration\n@Profile("dev")\npublic class DevDataSourceConfig {\n\n    @Bean\n    public DataSource dataSource() {\n        System.out.println("Creating DEV H2 DataSource");\n        // Logic to create an in-memory H2 data source...\n        return new H2DataSource();\n    }\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "ProdDataSourceConfig.java",
                        code: `package com.example.config;\n\nimport org.springframework.context.annotation.Bean;\nimport org.springframework.context.annotation.Configuration;\nimport org.springframework.context.annotation.Profile;\n\n@Configuration\n@Profile("prod")\npublic class ProdDataSourceConfig {\n\n    @Bean\n    public DataSource dataSource() {\n        System.out.println("Creating PROD PostgreSQL DataSource");\n        // Logic to create a production PostgreSQL data source...\n        return new PostgreSQLDataSource();\n    }\n}`
                    },
                    {
                        type: "paragraph",
                        text: "When the 'dev' profile is active, Spring will only process `DevDataSourceConfig` and create the H2 bean. When 'prod' is active, it will only process `ProdDataSourceConfig` and create the PostgreSQL bean. If neither is active, neither bean is created."
                    },
                    {
                        type: "quiz",
                        question: "If a property is defined in both `application.properties` and `application-prod.properties`, which value will be used when the application is run with `--spring.profiles.active=prod`?",
                        options: [
                            "The value from `application.properties`",
                            "The application will fail to start due to a conflict",
                            "The value from `application-prod.properties`",
                            "The values will be merged together"
                        ],
                        correctAnswer: "The value from `application-prod.properties`",
                        explanation: "Profile-specific properties always override the default properties in `application.properties` when that profile is active."
                    }
                ]
            }
        ]
    },
    {
        id: "part-10",
        slug: "part-10-maven-multi-module",
        title: "Part 10: Maven Multi-Module Projects",
        description: "Organize large applications with parent POMs and child modules.",
        sections: [
            {
                title: "10.1 Why Go Multi-Module?",
                content: [
                    {
                        type: "paragraph",
                        text: "As applications grow, a single module (a monolith) can become difficult to manage. Code for data access, business logic, and web presentation all gets tangled together. This makes it hard to maintain, test, and for teams to work on different parts concurrently."
                    },
                    {
                        type: "paragraph",
                        text: "Maven provides a solution: the **multi-module project**. This allows you to break your application into several smaller, interconnected sub-projects (modules), all managed by a single parent project. Think of it as organizing a large book into chapters."
                    },
                    {
                        type: "table",
                        headers: [
                            "Benefit",
                            "Description"
                        ],
                        rows: [
                            [
                                {
                                    text: "Separation of Concerns",
                                    highlight: true
                                },
                                "Each module has a clear purpose (e.g., `api` for data contracts, `core` for business logic, `web` for the user interface)."
                            ],
                            [
                                {
                                    text: "Reusability",
                                    highlight: false
                                },
                                "A `common-utils` module can be created and reused across multiple applications."
                            ],
                            [
                                {
                                    text: "Independent Development",
                                    highlight: false
                                },
                                "Different teams can work on different modules simultaneously with fewer merge conflicts."
                            ],
                            [
                                {
                                    text: "Controlled Build",
                                    highlight: false
                                },
                                "You can build the entire project at once, or just a single module and its dependencies."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "10.2 Structure of a Multi-Module Project",
                content: [
                    {
                        type: "paragraph",
                        text: "A multi-module project has a parent project that contains a `pom.xml` and one or more directories for the child modules."
                    },
                    {
                        type: "console",
                        title: "Typical Multi-Module Structure",
                        output: `my-application/  (Root Project Folder)
├── pom.xml         (Parent POM - The Conductor)
│
├── api/            (API Module)
│   ├── pom.xml
│   └── src/main/java/com/example/api/  (DTOs, interfaces)
│
├── core/           (Core Logic Module)
│   ├── pom.xml
│   └── src/main/java/com/example/core/ (Services, business logic)
│
└── webapp/         (Web Application Module)
    ├── pom.xml
    └── src/main/java/com/example/webapp/ (@SpringBootApplication, Controllers)`
                    },
                    {
                        type: "paragraph",
                        text: "In this structure:\n- **`my-application`** is the parent project. Its `pom.xml` orchestrates the build.\n- **`api`** is a module that might contain shared data objects (DTOs) and service interfaces. It produces a JAR that other modules can use.\n- **`core`** contains the main business logic and services. It might depend on the `api` module.\n- **`webapp`** is the executable layer. It depends on `core` and `api` and contains the Spring Boot main class and web controllers. This is the module that will be packaged into a runnable 'fat JAR'."
                    }
                ]
            },
            {
                title: "10.3 The Parent POM: The Conductor of the Orchestra",
                content: [
                    {
                        type: "paragraph",
                        text: "The parent `pom.xml` is the most important piece for managing a multi-module project. Its role is to act as a conductor, ensuring all the child modules play together harmoniously. It enforces consistency and simplifies configuration across the entire project."
                    },
                    {
                        type: "paragraph",
                        text: "Here is a well-structured example of what a parent POM should contain, followed by a breakdown of what each part does and, just as importantly, what it should *not* do."
                    },
                    {
                        type: "code",
                        language: "xml",
                        title: "Parent pom.xml (Best Practices)",
                        code: `<project ...>
    <groupId>com.example</groupId>
    <artifactId>my-application-parent</artifactId>
    <version>1.0.0</version>
    <packaging>pom</packaging>

    <modules>
        <module>api</module>
        <module>core</module>
        <module>webapp</module>
    </modules>

    <properties>
        <java.version>17</java.version>
        <spring-boot.version>3.2.0</spring-boot.version>
    </properties>

    <!-- Defines dependency versions for all child modules -->
    <dependencyManagement>
        <dependencies>
            <!-- Import Spring Boot's bill-of-materials (BOM) -->
            <dependency>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-dependencies</artifactId>
                <version>\${spring-boot.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <!-- Defines plugin versions and configurations for all child modules -->
    <build>
        <pluginManagement>
            <plugins>
                <plugin>
                    <groupId>org.springframework.boot</groupId>
                    <artifactId>spring-boot-maven-plugin</artifactId>
                    <version>\${spring-boot.version}</version>
                </plugin>
            </plugins>
        </pluginManagement>
    </build>
</project>`
                    },
                    {
                        type: "table",
                        headers: [
                            "Element / Section",
                            "Belongs in Parent?",
                            "Why?"
                        ],
                        rows: [
                            [
                                {
                                    text: "<packaging>pom</packaging>",
                                    highlight: true
                                },
                                "**Yes**",
                                "Signals to Maven this is an aggregator POM that doesn't produce its own JAR. It only manages other modules."
                            ],
                            [
                                {
                                    text: "<modules>",
                                    highlight: true
                                },
                                "**Yes**",
                                "Lists all the child modules to be included in the build. This is how Maven's Reactor knows which projects to build."
                            ],
                            [
                                {
                                    text: "<properties>",
                                    highlight: true
                                },
                                "**Yes**",
                                "A best practice for centralizing versions of dependencies, plugins, and Java itself. All child modules inherit these properties."
                            ],
                            [
                                {
                                    text: "<dependencyManagement>",
                                    highlight: true
                                },
                                "**Yes (Crucial)**",
                                "**Declares and centralizes dependency versions** for all children. This ensures consistency and avoids version conflicts. Children can then include a dependency without specifying a version."
                            ],
                            [
                                {
                                    text: "<pluginManagement>",
                                    highlight: true
                                },
                                "**Yes (Best Practice)**",
                                "Similar to `dependencyManagement`, but for plugins. **Declares and centralizes plugin versions and configurations**. Children can then use a plugin without repeating version or configuration details."
                            ],
                            [
                                {
                                    text: "<dependencies>",
                                    highlight: false
                                },
                                "**No (Generally)**",
                                "The parent should not have direct dependencies. Its role is to manage, not to contain code. Dependencies belong in the specific child modules that actually use them."
                            ],
                            [
                                {
                                    text: "spring-boot-maven-plugin (with <executions>)",
                                    highlight: false
                                },
                                "**No**",
                                "The `repackage` goal should **only** be executed in the final, runnable module (e.g., `webapp`). Executing it in the parent would cause Maven to incorrectly try to repackage every library module (`api`, `core`) into a standalone, executable JAR. This is incorrect, bloats the build, and creates misleading artifacts. The parent only *manages* the plugin's version and configuration via `<pluginManagement>`."
                            ],
                            [
                                {
                                    text: "src/ directory",
                                    highlight: false
                                },
                                "**No**",
                                "A parent `pom` project should not contain any source code. Its sole purpose is project aggregation and management."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "10.4 The Child Module and Inter-Module Dependencies",
                content: [
                    {
                        type: "paragraph",
                        text: "Each child module's `pom.xml` declares the parent POM and its own specific dependencies."
                    },
                    {
                        type: "code",
                        language: "xml",
                        title: "core/pom.xml",
                        code: `<project ...>
    <parent> <!-- Links back to the parent POM -->
        <groupId>com.example</groupId>
        <artifactId>my-application-parent</artifactId>
        <version>1.0.0</version>
        <relativePath/> <!-- Look for parent pom from repository, not relative path -->
    </parent>
    <artifactId>core</artifactId>
    <packaging>jar</packaging>

    <dependencies>
        <!-- Dependency on another module in our project -->
        <dependency>
            <groupId>com.example</groupId>
            <artifactId>api</artifactId>
            <version>\${project.version}</version>
        </dependency>

        <!-- External dependency - NO VERSION needed, it's in the parent's dependencyManagement -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
    </dependencies>
</project>`
                    },
                    {
                        type: "paragraph",
                        text: "The `webapp` module is special. It depends on the other modules and also contains the `spring-boot-maven-plugin` to create the final executable JAR."
                    },
                    {
                        type: "code",
                        language: "xml",
                        title: "webapp/pom.xml",
                        code: `<project ...>
    <parent>
        <groupId>com.example</groupId>
        <artifactId>my-application-parent</artifactId>
        <version>1.0.0</version>
        <relativePath/>
    </parent>
    <artifactId>webapp</artifactId>

    <dependencies>
        <!-- Dependency on our core logic module -->
        <dependency>
            <groupId>com.example</groupId>
            <artifactId>core</artifactId>
            <version>\${project.version}</version>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <!-- This plugin makes the fat JAR. Version is inherited from parent's pluginManagement -->
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <executions>
                    <execution>
                        <goals>
                            <!-- This goal is mandatory to create the executable JAR -->
                            <goal>repackage</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>`
                    },
                    {
                        type: "paragraph",
                        text: "The `webapp` module's POM is unique because it includes the `spring-boot-maven-plugin` with an `<executions>` block. The `repackage` goal is mandatory; it's what takes the standard JAR Maven builds and transforms it into the executable fat JAR that includes all the code and dependencies from the `core` and `api` modules."
                    }
                ]
            },
            {
                title: "10.5 Under the Hood: The Maven Lifecycle and Reactor",
                content: [
                    {
                        type: "paragraph",
                        text: "When you run a command like `mvn clean install` from the parent directory, you're interacting with two core Maven concepts: the **Build Lifecycle** and the **Reactor**."
                    },
                    {
                        type: "paragraph",
                        text: "**The Reactor** first analyzes the `<modules>` in your parent POM and the dependencies between them. It calculates the correct build order to ensure that a module is built before any modules that depend on it. For our project, the order is `api`, then `core`, then `webapp`."
                    },
                    {
                        type: "paragraph",
                        text: "**The Lifecycle** defines a sequence of phases (like `validate`, `compile`, `test`, `package`, `install`). When you run `mvn install`, you're telling Maven to execute every phase up to and including `install`. Plugin goals can be 'bound' to these phases. The `spring-boot-maven-plugin` binds its `repackage` goal to the `package` phase by default."
                    },
                    {
                        type: "paragraph",
                        text: "So, to answer your question: **Yes, the `repackage` goal runs automatically during `mvn clean install`.** Here's how it all comes together:"
                    },
                    {
                        type: "diagram",
                        diagram: `1. Reactor determines build order: api -> core -> webapp.

2. Build api:
   - Reactor executes 'clean' and 'install' phases for the 'api' module.
   - Produces -> api-1.0.0.jar
   - Installs it into the local ~/.m2/repository.

3. Build core:
   - Reactor executes 'clean' and 'install' for the 'core' module.
   - It finds its dependency (api-1.0.0.jar) in ~/.m2.
   - Produces -> core-1.0.0.jar
   - Installs it into the local ~/.m2/repository.

4. Build webapp:
   - Reactor executes 'clean' and 'install' for the 'webapp' module.
   - During the 'package' phase, two things happen:
     a) Maven's default 'jar' plugin runs, creating a standard webapp-1.0.0.jar.
     b) The 'repackage' goal from the spring-boot-maven-plugin runs immediately after, creating the final, executable webapp-1.0.0.jar.
   - During the 'install' phase, BOTH JARs are installed to your local repository. You'll see \`webapp-1.0.0.jar\` and \`webapp-1.0.0.jar.original\` (the thin JAR).`
                    },
                    {
                        type: "paragraph",
                        text: "The result is a single, self-contained, executable JAR from the `webapp/target` directory that contains all the code and dependencies from every module."
                    }
                ]
            },
            {
                title: "10.6 Spring's Component Scan in a Multi-Module World",
                content: [
                    {
                        type: "paragraph",
                        text: "There is one crucial detail for Spring Boot. By default, `@SpringBootApplication` only scans for components (like `@Service` or `@RestController`) within its own package and sub-packages."
                    },
                    {
                        type: "paragraph",
                        text: "In our example, `WebAppApplication` is in `com.example.webapp`. It will **not** find the `@Service` beans in the `com.example.core` package or the `@RestController` beans in a separate `com.example.api.controllers` package. You must explicitly tell Spring where to look."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "webapp/src/main/java/com/example/webapp/WebAppApplication.java",
                        code: `package com.example.webapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// We must tell Spring to scan the base packages of our other modules!
@SpringBootApplication(scanBasePackages = { "com.example.webapp", "com.example.core", "com.example.api" })
public class WebAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebAppApplication.class, args);
    }
}`
                    },
                    {
                        type: "quiz",
                        question: "In a multi-module project, what does `<packaging>pom</packaging>` in the parent POM signify?",
                        options: [
                            "The project will be packaged as a special 'pom.jar' file",
                            "It's a project that only manages other modules and does not produce its own artifact",
                            "It's a shorthand for a project that has no dependencies",
                            "It tells Maven to package all modules into a single POM file"
                        ],
                        correctAnswer: "It's a project that only manages other modules and does not produce its own artifact",
                        explanation: "The `pom` packaging type indicates that the project is an aggregator or a parent project. Its purpose is to define and manage a set of sub-modules, not to produce a JAR or WAR file itself."
                    }
                ]
            }
        ]
    },
    {
        id: "part-11",
        slug: "part-11-dev-mode-spring-boot-run",
        title: "Part 11: Dev Mode with `mvn spring-boot:run`",
        description: "Learn to run and debug your app in development, and how it handles multi-module projects.",
        sections: [
            {
                title: "11.1 What is `spring-boot:run`?",
                content: [
                    {
                        type: "paragraph",
                        text: "The `spring-boot:run` goal is a command provided by the `spring-boot-maven-plugin`. Its purpose is to run your Spring Boot application in an 'exploded' format, directly from your Maven project without needing to package it into a JAR first."
                    },
                    {
                        type: "paragraph",
                        text: "This is the primary way you will run your application during development. It's fast, convenient, and, as we'll see, has a special way of handling modules that is ideal for live coding."
                    }
                ]
            },
            {
                title: "11.2 The Magic Classpath: Why Live Changes Work",
                content: [
                    {
                        type: "paragraph",
                        text: "The most powerful feature of `spring-boot:run` is how it constructs the Java classpath, especially in a multi-module project. This is the answer to your question: How is it able to use local source files and not the JARs from `.m2`?"
                    },
                    {
                        type: "paragraph",
                        text: "It builds a hybrid classpath:\n- **For external dependencies** (like `spring-web`, `log4j`, etc.), it uses the standard JAR files from your local `.m2` repository.\n- **For your own project modules** (`api`, `core`, `webapp`), it does something different. Instead of using their JAR files from `.m2`, it adds their **`target/classes` directories** directly to the classpath."
                    },
                    {
                        type: "diagram",
                        diagram: `               [mvn spring-boot:run]
                         |
           [Builds a Classpath for the JVM]
                        /       \\
  +--------------------+         +-----------------------+
  | .m2/repository/    |         | Project Workspace     |
  | spring-core.jar    |         | /api/target/classes/  |
  | spring-web.jar     |         | /core/target/classes/ |
  | ... (external jars)|         | /webapp/target/classes/|
  +--------------------+         +-----------------------+`
                    },
                    {
                        type: "paragraph",
                        text: "This is the key. When you change a `.java` file in your `core` module and your IDE recompiles it, the updated `.class` file is placed in `core/target/classes`. Because that directory is on the live classpath, the running application can pick up the change instantly (usually with an automatic restart, as we'll see next)."
                    }
                ]
            },
            {
                title: "11.3 Supercharging with Spring Boot DevTools",
                content: [
                    {
                        type: "paragraph",
                        text: "To make this process seamless, you should always include the `spring-boot-devtools` dependency. This small library automates the process of watching for classpath changes and restarting your application."
                    },
                    {
                        type: "code",
                        language: "xml",
                        title: "Add to webapp/pom.xml",
                        code: `<dependency>\n    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-devtools</artifactId>
    <scope>runtime</scope>
    <optional>true</optional>\n</dependency>`
                    },
                    {
                        type: "paragraph",
                        text: "With DevTools, the development workflow is simple:\n1. Run `mvn spring-boot:run` in a terminal.\n2. Change a Java file in any module (e.g., `core`).\n3. Your IDE automatically compiles the change into that module's `target/classes` directory.\n4. DevTools detects the updated `.class` file and triggers a fast, intelligent restart of your application.\nYou don't have to stop and restart the server manually."
                    }
                ]
            },
            {
                title: "11.4 Debugging Your Application",
                content: [
                    {
                        type: "paragraph",
                        text: "Since `spring-boot:run` starts a real JVM process, you can easily attach a debugger to it. The standard way is to tell Maven to launch the JVM with the necessary debug agent parameters."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Run Maven in Debug Mode",
                        code: `mvn spring-boot:run -Dspring-boot.run.jvmArguments="-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=5005"`
                    },
                    {
                        type: "paragraph",
                        text: "This command tells the JVM to start a debug server on port `5005`. You can then go to your IDE (like IntelliJ or VS Code), create a 'Remote JVM Debug' configuration, point it to `localhost` and port `5005`, and connect. You can now set breakpoints anywhere in your code, across all modules, and debug your application live."
                    }
                ]
            },
            {
                title: "11.5 `spring-boot:run` vs. `java -jar`",
                content: [
                    {
                        type: "table",
                        headers: [
                            "Feature",
                            "`mvn spring-boot:run`",
                            "`java -jar my-app.jar`"
                        ],
                        rows: [
                            [
                                {
                                    text: "Purpose",
                                    highlight: false
                                },
                                "Development & Debugging",
                                "Production & Staging Execution"
                            ],
                            [
                                {
                                    text: "Classpath",
                                    highlight: true
                                },
                                "Dynamic. Uses `target/classes` for project modules.",
                                "Static. All code is inside the JAR file."
                            ],
                            [
                                {
                                    text: "Live Changes",
                                    highlight: false
                                },
                                "Excellent support with DevTools.",
                                "Not possible. Must rebuild the JAR to see changes."
                            ],
                            [
                                {
                                    text: "Startup Speed",
                                    highlight: false
                                },
                                "Generally faster initial startup for small changes.",
                                "Can be faster for a clean start as no compilation is needed."
                            ]
                        ]
                    },
                    {
                        type: "quiz",
                        question: "When using `mvn spring-boot:run` in a multi-module project, where does it load your code from for the other modules (e.g., a 'core' module)?",
                        options: [
                            "The JAR file in the local `.m2` repository",
                            "The `target/classes` directory of that module",
                            "The `src/main/java` directory directly",
                            "It downloads a fresh copy from a remote repository"
                        ],
                        correctAnswer: "The `target/classes` directory of that module",
                        explanation: "This is the key feature of `spring-boot:run`. It puts the compiled output directories of your project's own modules on the classpath, which is what allows for live reloading during development."
                    }
                ]
            }
        ]
    },
    {
        id: "part-12",
        slug: "part-12-ide-magic",
        title: "Part 12: The IDE's Magic: Running Without Fat Jars",
        description: "Discover how IDEs like IntelliJ compile and run your application using a plain Java command.",
        sections: [
            {
                title: "12.1 How Your IDE Runs the Application",
                content: [
                    {
                        type: "paragraph",
                        text: "When you click the green 'Run' arrow next to your `main` method in an IDE like IntelliJ, it is **not** running `mvn spring-boot:run` and it is **not** building a fat JAR. For the sake of speed and debugging, it uses a much more direct approach."
                    },
                    {
                        type: "paragraph",
                        text: "Behind the scenes, the IDE creates its own 'Run Configuration'. This configuration automates a two-step process designed for the fastest possible development feedback loop."
                    }
                ]
            },
            {
                title: "12.2 The Two-Step Process: Compile and Run",
                content: [
                    {
                        type: "paragraph",
                        text: "Here’s what your IDE actually does:\n\n1.  **Compile Phase:** It acts like a very fast build tool. It reads all your `pom.xml` files to understand the project's structure and then compiles all the `.java` source files from all your modules (`api`, `core`, `webapp`, etc.) into their respective `target/classes` directories. This is often done incrementally, so only changed files are recompiled.\n\n2.  **Run Phase:** This is the clever part. The IDE constructs a very long `java -cp ...` command and executes it directly. It doesn't use `java -jar`. Instead, it manually builds a complete classpath and tells the JVM exactly which main class to run."
                    },
                    {
                        type: "diagram",
                        diagram: `[IDE 'Run' Click]
     |
     v
1. Compile Phase (Incremental)
   - Compiles api -> api/target/classes
   - Compiles core -> core/target/classes
   - Compiles webapp -> webapp/target/classes
     |
     v
2. Run Phase (Constructs & executes a plain \`java\` command)
   - Command: java -cp [classpath] com.example.webapp.WebAppApplication
   - Classpath contains:
     -> webapp/target/classes
     -> core/target/classes
     -> api/target/classes
     -> ~/.m2/repository/spring-boot-starter-web.jar
     -> ~/.m2/repository/spring-core.jar
     -> ... (and every other required dependency JAR) ...`
                    }
                ]
            },
            {
                title: "12.3 Passing Profiles and Parameters",
                content: [
                    {
                        type: "paragraph",
                        text: "So how does the IDE handle things like Spring Profiles or custom command-line arguments? It simply adds them to the `java` command it constructs. The 'Run/Debug Configuration' screen in your IDE is a user-friendly interface for building this command line."
                    },
                    {
                        type: "paragraph",
                        text: "There are two main ways parameters are passed:"
                    },
                    {
                        type: "table",
                        headers: [
                            "Parameter Type",
                            "IDE Setting",
                            "Resulting Command Part"
                        ],
                        rows: [
                            [
                                {
                                    text: "VM Options",
                                    highlight: true
                                },
                                "Often labeled 'VM options' or 'VM arguments'. This is where you put standard Java system properties.",
                                {
                                    text: "java -Dspring.profiles.active=dev ...",
                                    highlight: false
                                }
                            ],
                            [
                                {
                                    text: "Program Arguments",
                                    highlight: true
                                },
                                "Labeled 'Program arguments' or 'Command-line arguments'. These are passed to your application's `main` method.",
                                {
                                    text: "... MainClass --server.port=9090 --my.prop=value",
                                    highlight: false
                                }
                            ]
                        ]
                    },
                    {
                        type: "paragraph",
                        text: "Spring Boot is smart enough to parse both types of arguments. Properties set with `-D` become system properties, while arguments like `--server.port` are parsed as command-line arguments. Both have high precedence and will override values from `application.properties`."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Full IDE Command (Conceptual)",
                        code: `# The IDE constructs a command that looks something like this:\n\njava \\\n  -Dspring.profiles.active=dev \\\n  -cp "webapp/target/classes:core/target/classes:api/target/classes:/Users/user/.m2/repository/spring-boot/..." \\\n  com.example.webapp.WebAppApplication \\\n  --server.port=9090`
                    }
                ]
            },
            {
                title: "12.4 Why This Works: Pure Classpath Execution",
                content: [
                    {
                        type: "paragraph",
                        text: "This method is the 'purest' way to run a Java application. By directly invoking `java ... com.example.webapp.WebAppApplication`, the IDE starts your application just as the JVM intends. The `SpringApplication.run()` method in your `main` class then takes over."
                    },
                    {
                        type: "paragraph",
                        text: "Because the IDE has meticulously constructed a classpath containing every single class your application needs (from your modules' `target/classes` and all the external JARs from `.m2`), Spring Boot's auto-configuration and component-scanning work perfectly. It can find every `@Service`, `@RestController`, and dependency on the classpath to initialize the `ApplicationContext` correctly."
                    }
                ]
            },
            {
                title: "12.5 Comparison: IDE vs. Maven vs. JAR",
                content: [
                    {
                        type: "table",
                        headers: [
                            "Feature",
                            "IDE Run (`▶️`)",
                            "`mvn spring-boot:run`",
                            "`java -jar my-app.jar`"
                        ],
                        rows: [
                            [
                                {
                                    text: "Execution Command",
                                    highlight: false
                                },
                                "`java -cp ... MainClass`",
                                "Maven Plugin",
                                "`java -jar ...`"
                            ],
                            [
                                {
                                    text: "Main Class Called",
                                    highlight: true
                                },
                                "Your application's main class",
                                "Your application's main class",
                                "Spring Boot's `JarLauncher`"
                            ],
                            [
                                {
                                    text: "Classpath Source",
                                    highlight: false
                                },
                                "`target/classes` + `.m2` JARs",
                                "`target/classes` + `.m2` JARs",
                                "Nested JARs inside the fat JAR"
                            ],
                            [
                                {
                                    text: "Primary Use Case",
                                    highlight: false
                                },
                                "Day-to-day development and debugging",
                                "Command-line development and some CI builds",
                                "Production / Staging / CI execution"
                            ]
                        ]
                    },
                    {
                        type: "quiz",
                        question: "When you run a Spring Boot application from an IDE like IntelliJ, how does it typically build the classpath for execution?",
                        options: [
                            "It builds a fat JAR and runs `java -jar`.",
                            "It uses the JARs from the `target` directory of each module.",
                            "It points directly to the `target/classes` directories of your modules and all required dependency JARs from the `.m2` repository.",
                            "It exclusively uses the `mvn spring-boot:run` command behind the scenes."
                        ],
                        correctAnswer: "It points directly to the `target/classes` directories of your modules and all required dependency JARs from the `.m2` repository.",
                        explanation: "IDEs prioritize speed by compiling source to `target/classes` and then constructing a long, explicit classpath that includes these directories and all external JARs from your local Maven repository, before running a standard `java` command."
                    }
                ]
            }
        ]
    },
    {
        id: "part-13",
        slug: "part-13-clean-architecture",
        title: "Part 13: Modern Architecture: Clean & Hexagonal",
        description: "Apply modern architectural patterns to your multi-module projects.",
        sections: [
            {
                title: "13.1 Beyond Modules: The Need for an Architecture",
                content: [
                    {
                        type: "paragraph",
                        text: "We've seen how to organize our code into modules. This is a great first step! But simply having `api`, `core`, and `webapp` modules doesn't automatically give us a good architecture. Without clear rules, dependencies can become a tangled mess, defeating the purpose of our modular setup."
                    },
                    {
                        type: "paragraph",
                        text: "This is where architectural patterns like **Clean Architecture** or **Hexagonal Architecture** (also known as Ports and Adapters) come in. They provide a set of rules for how different parts of the system should interact, with a primary focus on one thing: **protecting your core business logic from external concerns.**"
                    }
                ]
            },
            {
                title: "13.2 The Core Principle: The Dependency Rule",
                content: [
                    {
                        type: "paragraph",
                        text: "The single most important rule in Clean/Hexagonal architecture is **The Dependency Rule**. It states that all dependencies must flow inwards. The outer layers can know about the inner layers, but the inner layers must know nothing about the outer layers."
                    },
                    {
                        type: "diagram",
                        diagram: `
      +-------------------------------------------+
      |       Adapters (e.g., Web, Database)      |
      |   +-----------------------------------+   |
      |   |   Application Services (Use Cases)|   |
      |   |   +---------------------------+   |   |
      |   |   |   Domain Entities         |   |   |
      |   |   +---------------------------+   |   |
      |   +-----------------------------------+   |
      +-------------------------------------------+
      -----------------> Dependency Flow ----------------->`
                    },
                    {
                        type: "paragraph",
                        text: "- **Domain Entities**: The heart of your application. These are the core business objects and rules. They have no dependencies on anything else.\n- **Application Services (Use Cases)**: This layer orchestrates the flow of data to and from the entities. It contains the application-specific business logic. It depends on the Entities but knows nothing about the web, databases, or any other external technology.\n- **Adapters**: This is the outermost layer. It contains everything that interacts with the outside world: web controllers, database repositories, message queue listeners, etc. This layer depends on the Application Services, but not the other way around."
                    }
                ]
            },
            {
                title: "13.3 Mapping Our Modules to Hexagonal Architecture",
                content: [
                    {
                        type: "paragraph",
                        text: "How can we map our modules to this architecture? A common and effective approach is to clearly define the role of each module based on the Dependency Rule."
                    },
                    {
                        type: "table",
                        headers: [
                            "Architectural Layer",
                            "Mapped Module",
                            "Contents & Responsibilities"
                        ],
                        rows: [
                            [
                                {
                                    text: "Ports & Data Contracts",
                                    highlight: true
                                },
                                "`api`",
                                "Defines the **boundary** of your application. Contains the **Ports** (Java interfaces for services and repositories) and the **Data Transfer Objects (DTOs)**. It has ZERO dependencies on frameworks or other modules."
                            ],
                            [
                                {
                                    text: "Domain & Application Core (The Hexagon)",
                                    highlight: true
                                },
                                "`core`",
                                "The heart of your application. Contains your rich **Domain Objects** (Entities, Aggregates) and the **Application Services** (Use Cases) that implement the service ports from the `api` module. Depends only on `api`."
                            ],
                            [
                                {
                                    text: "Driving Adapters (Primary)",
                                    highlight: false
                                },
                                "`webapp`",
                                "Code that *drives* the application (e.g., `@RestController`s). This module depends on `api` to call the application's ports, but knows nothing about the `core`'s implementation details."
                            ],
                            [
                                {
                                    text: "Driven Adapters (Secondary)",
                                    highlight: false
                                },
                                "(new module, e.g., `persistence`)",
                                "Code that is *driven by* the application (e.g., database repositories). This module would implement the repository ports defined in `api`. It depends on `api` and `core`."
                            ]
                        ]
                    },
                    {
                        type: "paragraph",
                        text: "Notice the inversion. The `core` logic defines what it needs via an interface in the `api` module (e.g., `UserRepositoryPort`). A separate `persistence` module then provides the concrete implementation. This decouples the business logic from the database technology, which is the central goal."
                    }
                ]
            },
            {
                title: "13.4 Example: Ports and Adapters in Action",
                content: [
                    {
                        type: "paragraph",
                        text: "Let's make this concrete. We want to get a user. We define the 'Port' (the interface) and the data contract (the DTO) in our `api` module."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "api/src/.../dto/UserDto.java",
                        code: `package com.example.api.dto;\n\n// A simple data container for transfer\npublic class UserDto {\n    private String name;\n    // constructor, getters, setters...\n}`
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "api/src/.../port/UserPort.java",
                        code: `package com.example.api.port;\n\nimport com.example.api.dto.UserDto;\n\n// The Port defines WHAT the application can do\npublic interface UserPort {\n    UserDto getUserById(Long id);\n}`
                    },
                    {
                        type: "paragraph",
                        text: "The web controller in the `webapp` module (an Adapter) uses this Port via dependency injection. It knows what it wants to do, but not how it's done."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "webapp/src/.../controller/UserController.java",
                        code: `package com.example.webapp.controller;\n\nimport com.example.api.port.UserPort;\nimport org.springframework.web.bind.annotation.RestController;\n\n@RestController\npublic class UserController {\n    private final UserPort userPort; // Depends on the Port, not the implementation\n\n    public UserController(UserPort userPort) { // Injected by Spring\n        this.userPort = userPort;\n    }\n    // ... methods that call userPort.getUserById() ...\n}`
                    },
                    {
                        type: "paragraph",
                        text: "Finally, the 'Adapter' in our `core` module implements the Port. This class contains the actual business logic."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "core/src/.../service/UserService.java",
                        code: `package com.example.core.service;\n\nimport com.example.api.port.UserPort;\nimport com.example.api.dto.UserDto;\nimport com.example.core.domain.User; // The actual domain entity!\nimport org.springframework.stereotype.Service;\n\n@Service // This is the implementation Spring will find and inject\npublic class UserService implements UserPort {\n    @Override\n    public UserDto getUserById(Long id) {\n        // ... business logic to fetch a domain.User object ...\n        User user = // ... fetch from database via another port ...\n        // ... map domain object to DTO ...\n        return new UserDto(user.getName());\n    }\n}`
                    },
                    {
                        type: "paragraph",
                        text: "With this structure, the `core` and `api` modules are completely isolated from the web. We could swap out the `webapp` for a command-line interface or a message queue listener without changing a single line of code in `core` or `api`."
                    },
                    {
                        type: "quiz",
                        question: "What is the main goal of the Dependency Rule in Clean/Hexagonal Architecture?",
                        options: [
                            "To ensure all layers have access to the database.",
                            "To make sure dependencies flow inwards, protecting the core business logic from external concerns.",
                            "To force every class to use an interface.",
                            "To minimize the number of modules in a project."
                        ],
                        correctAnswer: "To make sure dependencies flow inwards, protecting the core business logic from external concerns.",
                        explanation: "The Dependency Rule is the cornerstone of this architecture. By making sure inner layers are completely unaware of outer layers (like the UI or database), it ensures the core logic is pure, reusable, and easy to test independently."
                    }
                ]
            }
        ]
    },
    {
        id: "part-14",
        slug: "part-14-whats-new-in-spring-boot-3",
        title: "Part 14: What's New in Spring Boot 3?",
        description: "Explore the major features and changes introduced in Spring Boot 3.",
        sections: [
            {
                title: "14.1 A New Foundation: Java 17 & Jakarta EE",
                content: [
                    {
                        type: "paragraph",
                        text: "Spring Boot 3 represents a major generational shift. The two most fundamental changes are the new baseline requirements:\n\n1.  **Java 17 is Now the Minimum:** You can no longer run Spring Boot 3 applications on older versions of Java like 8 or 11. This allows the framework to leverage modern Java features for better performance and security.\n2.  **Migration to Jakarta EE:** Spring Boot 3 moves from Java EE to Jakarta EE APIs. This is a critical **breaking change**. The `javax.*` packages used for servlets, persistence (JPA), validation, etc., have all been renamed to `jakarta.*`."
                    },
                    {
                        type: "table",
                        headers: [
                            "Old Package (`javax.*`)",
                            "New Package (`jakarta.*`)"
                        ],
                        rows: [
                            [
                                {
                                    text: "javax.servlet.http.HttpServlet",
                                    highlight: false
                                },
                                {
                                    text: "jakarta.servlet.http.HttpServlet",
                                    highlight: false
                                }
                            ],
                            [
                                {
                                    text: "javax.persistence.Entity",
                                    highlight: false
                                },
                                {
                                    text: "jakarta.persistence.Entity",
                                    highlight: false
                                }
                            ],
                            [
                                {
                                    text: "javax.validation.constraints.NotNull",
                                    highlight: false
                                },
                                {
                                    text: "jakarta.validation.constraints.NotNull",
                                    highlight: false
                                }
                            ]
                        ]
                    },
                    {
                        type: "paragraph",
                        text: "When upgrading an existing project, you must perform a project-wide search and replace on these imports. Build tools can help, but it's a mandatory migration step."
                    }
                ]
            },
            {
                title: "14.2 Ahead-of-Time (AOT) and GraalVM Native Images",
                content: [
                    {
                        type: "paragraph",
                        text: "Perhaps the most exciting feature in Spring Boot 3 is first-class support for **Ahead-of-Time (AOT) compilation** to produce **GraalVM native images**."
                    },
                    {
                        type: "paragraph",
                        text: "Traditionally, Java uses a **Just-in-Time (JIT)** compiler, which compiles bytecode into native machine code at runtime. This allows for powerful dynamic optimizations but results in slower startup times and higher memory usage as the JVM and JIT need to run.\n\nAOT changes this. During the build process, the Spring AOT engine analyzes your application, performs all the necessary work that would normally happen at startup (like component scanning and auto-configuration), and generates the required code. The GraalVM Native Image tool then uses this output to compile your application directly into a self-contained, platform-specific executable file."
                    },
                    {
                        type: "table",
                        headers: [
                            "Feature",
                            "JIT Compilation (Traditional)",
                            "AOT / Native Image (New)"
                        ],
                        rows: [
                            [
                                {
                                    text: "Startup Time",
                                    highlight: false
                                },
                                "Seconds",
                                "Milliseconds"
                            ],
                            [
                                {
                                    text: "Memory Usage",
                                    highlight: false
                                },
                                "Hundreds of MB",
                                "Tens of MB"
                            ],
                            [
                                {
                                    text: "Build Time",
                                    highlight: false
                                },
                                "Fast",
                                "Significantly slower"
                            ],
                            [
                                {
                                    text: "Dynamic Features",
                                    highlight: true
                                },
                                "Fully supported (reflection, proxies)",
                                "Limited (requires configuration)"
                            ]
                        ]
                    },
                    {
                        type: "paragraph",
                        text: "This makes Spring Boot applications ideal for serverless functions and containerized environments where fast startup and low resource consumption are critical. The trade-off is a longer build time and the need to provide configuration hints for dynamic Java features like reflection."
                    }
                ]
            },
            {
                title: "14.3 Unified Observability with Micrometer",
                content: [
                    {
                        type: "paragraph",
                        text: "Spring Boot 3 introduces a new, unified approach to application monitoring called **Spring Boot Actuator for Observability**. It builds on top of the popular **Micrometer** library to provide a consistent way to handle both metrics and tracing."
                    },
                    {
                        type: "paragraph",
                        text: "Previously, you needed different libraries for different concerns (e.g., Micrometer for metrics, Spring Cloud Sleuth for tracing). Now, it's all integrated. By adding the Actuator dependency and a Micrometer bridge for a tracing system (like Zipkin or OpenTelemetry), you automatically get:\n\n- **Metrics:** Detailed information about HTTP requests, JVM performance, and more, which can be exported to systems like Prometheus.\n- **Tracing:** Distributed tracing support out-of-the-box. All incoming and outgoing requests are automatically instrumented with trace and span IDs, allowing you to follow a single request as it travels through multiple microservices."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Example HTTP Log with Tracing",
                        output: `2023-11-20T10:00:00.123Z INFO [my-app,655b62a4b9c8,655b62a4b9c8] 12345 --- [http-nio-8080-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring DispatcherServlet 'dispatcherServlet'`
                    },
                    {
                        type: "paragraph",
                        text: "The bracketed values `[my-app,655b62a4b9c8,655b62a4b9c8]` represent `[application-name, trace-id, span-id]`, which are now automatically included in logs."
                    }
                ]
            },
            {
                title: "14.4 Performance Boost with Virtual Threads",
                content: [
                    {
                        type: "paragraph",
                        text: "Starting with Spring Boot 3.2, there is now support for **Virtual Threads**, a flagship feature of Java 21's Project Loom. Traditional Java threads are mapped one-to-one with operating system threads, which are a scarce and heavy resource. This limits the number of concurrent requests an application can handle."
                    },
                    {
                        type: "paragraph",
                        text: "Virtual threads are lightweight threads managed by the JVM, not the OS. Millions of virtual threads can be mapped to a small number of OS threads. When a virtual thread executes blocking I/O (like a database call or a network request), it 'unmounts' from the OS thread, freeing it up to do other work. This allows an application to handle a massively larger number of concurrent requests with a small number of system threads, dramatically improving throughput for I/O-bound applications."
                    },
                    {
                        type: "paragraph",
                        text: "Enabling virtual threads in Spring Boot 3.2+ is as simple as setting one property:"
                    },
                    {
                        type: "code",
                        language: "properties",
                        title: "application.properties",
                        code: `spring.threads.virtual.enabled=true`
                    },
                    {
                        type: "quiz",
                        question: "What is the most significant breaking change when migrating an application to Spring Boot 3?",
                        options: [
                            "The minimum Java version is now 17.",
                            "You must use Maven instead of Gradle.",
                            "The migration from `javax.*` to `jakarta.*` namespaces for all EE dependencies.",
                            "The default web server is no longer Tomcat."
                        ],
                        correctAnswer: "The migration from `javax.*` to `jakarta.*` namespaces for all EE dependencies.",
                        explanation: "While requiring Java 17 is a major step, the package renaming from `javax` to `jakarta` is a direct breaking change that requires code-level modifications to imports throughout the entire application."
                    }
                ]
            }
        ]
    },
    {
        id: "part-15",
        slug: "part-15-advanced-principles-tdd-ddd",
        title: "Part 15: Advanced Principles: TDD & DDD",
        description: "Integrate Test-Driven Development and Domain-Driven Design into your architecture.",
        sections: [
            {
                title: "15.1 What is Test-Driven Development (TDD)?",
                content: [
                    {
                        type: "paragraph",
                        text: "Test-Driven Development (TDD) is a software development process that flips the traditional model on its head. Instead of writing production code first and then writing tests, TDD follows a short, repetitive cycle: **Red-Green-Refactor**."
                    },
                    {
                        type: "paragraph",
                        text: "You begin by writing a small, automated test case for a new feature. Since the feature doesn't exist yet, this test will **fail** (Red). Next, you write the simplest possible production code to make that test **pass** (Green). Finally, you clean up and improve the code you just wrote, ensuring all tests still pass (Refactor). You then repeat this cycle for the next piece of functionality."
                    },
                    {
                        type: "table",
                        headers: [
                            "Step",
                            "Action",
                            "Goal"
                        ],
                        rows: [
                            [
                                {
                                    text: "1. Red",
                                    highlight: true
                                },
                                "Write a failing test for a tiny piece of new functionality.",
                                "Clearly define what the new code needs to do before you write it."
                            ],
                            [
                                {
                                    text: "2. Green",
                                    highlight: true
                                },
                                "Write the absolute minimum amount of code required to make the test pass.",
                                "Quickly get to a working state, even if the code isn't perfect."
                            ],
                            [
                                {
                                    text: "3. Refactor",
                                    highlight: true
                                },
                                "Clean up the code you just wrote (improve names, remove duplication) while keeping the tests green.",
                                "Ensure the code is maintainable and well-designed without breaking existing functionality."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "15.2 TDD in Hexagonal Architecture",
                content: [
                    {
                        type: "paragraph",
                        text: "TDD and Hexagonal Architecture are a perfect match. The architecture's separation of concerns makes it easy to test each layer in isolation."
                    },
                    {
                        type: "paragraph",
                        text: "**Testing from the Inside Out:**\n1.  **Domain Entities:** Start by testing your core domain objects in the `core` module. They have no dependencies, making them the easiest to test.\n2.  **Application Services (Use Cases):** Test your services, also in the `core` module. Since they depend on Ports (interfaces from the `api` module), you can easily use a mocking framework like Mockito to provide fake implementations of those ports.\n3.  **Adapters:** Test your adapters in their respective modules. For a web controller, you can mock the application service port it calls. For a database repository, you might use an in-memory database like H2 to test its queries."
                    },
                    {
                        type: "code",
                        language: "java",
                        title: "Example: Testing an Application Service",
                        code: `import static org.mockito.Mockito.*;\nimport static org.junit.jupiter.api.Assertions.*;\n\n// Assume we have a port for a user repository in the 'api' module\ninterface UserRepositoryPort {\n    User findById(Long id);\n}\n\n// And a use case in the 'core' module that uses it\nclass GetUserUseCase {\n    private final UserRepositoryPort userRepo;\n    public GetUserUseCase(UserRepositoryPort userRepo) { this.userRepo = userRepo; }\n    public User execute(Long id) { return userRepo.findById(id); }\n}\n\n// The TDD-style test for the use case\n@Test\nvoid should_get_user_by_id() {\n    // Arrange (Setup)\n    UserRepositoryPort mockRepo = mock(UserRepositoryPort.class);\n    User expectedUser = new User(1L, "John Doe");\n    when(mockRepo.findById(1L)).thenReturn(expectedUser);\n    \n    GetUserUseCase useCase = new GetUserUseCase(mockRepo);\n\n    // Act (Execute)\n    User actualUser = useCase.execute(1L);\n\n    // Assert (Verify)\n    assertEquals(expectedUser, actualUser);\n    verify(mockRepo).findById(1L); // Verify the port was called correctly\n}`
                    }
                ]
            },
            {
                title: "15.3 What is Domain-Driven Design (DDD)?",
                content: [
                    {
                        type: "paragraph",
                        text: "Domain-Driven Design (DDD) is an approach to software development that focuses on modeling the software to match a specific **domain**, or subject area. The core idea is to build a deep understanding of the business domain and embed that understanding directly into your code."
                    },
                    {
                        type: "paragraph",
                        text: "A key part of DDD is creating a **Ubiquitous Language**—a common, shared vocabulary used by developers, domain experts, and stakeholders. This language is used in conversations, diagrams, and, most importantly, in the code itself (class names, method names, etc.). This reduces ambiguity and ensures the software accurately reflects the business reality."
                    },
                    {
                        type: "table",
                        headers: [
                            "DDD Concept",
                            "Description"
                        ],
                        rows: [
                            [
                                {
                                    text: "Ubiquitous Language",
                                    highlight: false
                                },
                                "A shared vocabulary between developers and domain experts."
                            ],
                            [
                                {
                                    text: "Bounded Context",
                                    highlight: false
                                },
                                "A specific boundary (e.g., a module or microservice) within which a particular domain model is defined and consistent."
                            ],
                            [
                                {
                                    text: "Aggregate",
                                    highlight: true
                                },
                                "A cluster of associated objects that are treated as a single unit for data changes. It has a root entity, and all access to the cluster must go through this root."
                            ],
                            [
                                {
                                    text: "Entity",
                                    highlight: false
                                },
                                "An object with a distinct identity that runs through time and different states (e.g., a `Customer` with an ID)."
                            ],
                            [
                                {
                                    text: "Value Object",
                                    highlight: false
                                },
                                "An immutable object that describes a characteristic, defined by its attributes rather than a unique identity (e.g., an `Address` or a `Money` object)."
                            ],
                            [
                                {
                                    text: "Repository",
                                    highlight: true
                                },
                                "An interface that provides access to all aggregates of a certain type, abstracting away the underlying storage mechanism."
                            ]
                        ]
                    }
                ]
            },
            {
                title: "15.4 Integrating DDD with Hexagonal Architecture",
                content: [
                    {
                        type: "paragraph",
                        text: "DDD provides the 'what' (the domain model), and Hexagonal Architecture provides the 'how' (the structure). They complement each other perfectly."
                    },
                    {
                        type: "diagram",
                        diagram: `Hexagonal Layer        | DDD Concepts
------------------------------------------------------
Application Core (core) | Entities, Value Objects, Aggregates
                       | Application Services
------------------------------------------------------
Ports & DTOs (api)     | Repository Interfaces (Ports)
                       | Service Interfaces (Ports), DTOs
------------------------------------------------------
Adapters               | Implementations of Repository Ports (e.g., JPA)
(webapp, persistence)  | Controllers that call Application Services`
                    },
                    {
                        type: "paragraph",
                        text: "In our multi-module project:\n- **`api` module:** This is the clean boundary. It contains your Repository and Service **interfaces** (Ports) and your DTOs. It is framework-agnostic.\n- **`core` module:** This is the heart of your domain. It contains your rich domain **Entities**, **Value Objects**, and **Aggregates**, along with the **Application Services** that implement the service ports from the `api` module.\n- **`persistence` module (an Adapter):** This module would contain the *implementations* of the Repository interfaces from `api`, using a technology like Spring Data JPA. It depends on `api` (for the interface) and `core` (for the domain entities it persists)."
                    },
                    {
                        type: "quiz",
                        question: "In the TDD cycle (Red-Green-Refactor), what is the primary goal of the 'Refactor' step?",
                        options: [
                            "To add new features",
                            "To make the failing test pass",
                            "To improve the design and readability of the code without changing its behavior",
                            "To write the test for the next feature"
                        ],
                        correctAnswer: "To improve the design and readability of the code without changing its behavior",
                        explanation: "The Refactor step is crucial for maintaining code quality. After getting a test to pass (Green), you clean up the code, confident that your test suite will catch any accidental breakages. This prevents technical debt from accumulating."
                    }
                ]
            }
        ]
    },
    {
        id: "part-16",
        slug: "part-16-troubleshooting-multi-module",
        title: "Part 16: Troubleshooting: The Maven Reactor vs. `spring-boot:run`",
        description: "Solve common Maven Reactor errors when running a specific module.",
        sections: [
            {
                title: "16.1 The Common Problem: Errors When Running a Specific Module",
                content: [
                    {
                        type: "paragraph",
                        text: "A frequent point of confusion in multi-module projects occurs when you try to run a specific module directly from the parent directory, like so:\n`my-application/ $ mvn -pl webapp spring-boot:run`"
                    },
                    {
                        type: "paragraph",
                        text: "This often results in one of two cryptic errors:\n1. A build failure with a message about **\"Reactor Pre-flight Checks\"** or **\"Enforce Reactor Convergence\"**, complaining that modules needed by `webapp` cannot be found in the current build plan.\n2. If you bypass that check (e.g., with `-Denforcer.skip=true`), the build might proceed, but the application will fail at runtime with `ClassNotFoundException` or `No main manifest attribute found`."
                    },
                    {
                        type: "paragraph",
                        text: "This is not a bug, but rather Maven behaving exactly as designed. The issue lies in understanding how Maven's **Reactor** works."
                    }
                ]
            },
            {
                title: "16.2 Understanding the Root Cause: The Maven Reactor",
                content: [
                    {
                        type: "paragraph",
                        text: "The **Maven Reactor** is the mechanism that discovers all the modules in a project (from the `<modules>` section in the parent POM), calculates the correct build order based on their dependencies, and then executes the specified goals."
                    },
                    {
                        type: "paragraph",
                        text: "The `-pl` (or `--projects`) flag tells Maven to create a **limited reactor** containing *only* the modules you specify. When you run `mvn -pl webapp ...`, you are instructing Maven to create a build plan that only includes the `webapp` module. The problem is that `webapp` depends on `core`, and `core` depends on `api`. Since `core` and `api` are not part of this limited build plan, Maven cannot find their code, leading to errors."
                    },
                    {
                        type: "diagram",
                        diagram: `Full Reactor ('mvn install'):
[ api, core, webapp ] -> Builds in correct order. SUCCESS.

Limited Reactor ('mvn -pl webapp ...'):
[ webapp ] -> ERROR! webapp needs 'core', but 'core' is not in this build plan.`
                    }
                ]
            },
            {
                title: "16.3 Solution 1 (The Professional Standard): Run from the Module's Directory",
                content: [
                    {
                        type: "paragraph",
                        text: "This is the simplest, most reliable, and professionally recommended method for running your application during development."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Run from Child Module",
                        code: `# 1. Navigate to the directory of the module with your @SpringBootApplication
cd webapp

# 2. Run the command. Maven automatically finds the parent POM and resolves all dependencies.
mvn spring-boot:run`
                    },
                    {
                        type: "paragraph",
                        text: "This works flawlessly because when run from within the child directory, Maven's context is that module. It reads the `<parent>` tag in the child's `pom.xml`, understands the full project structure, and correctly resolves all inter-module dependencies from your workspace before launching the application. This approach is unambiguous and avoids all Reactor-related headaches."
                    }
                ]
            },
            {
                title: "16.4 Solution 2 (The Advanced Method): The `-am` Flag",
                content: [
                    {
                        type: "paragraph",
                        text: "If you must run the command from the parent directory, you need to tell Maven to build the required dependencies as well. This is done with the `-am` flag."
                    },
                    {
                        type: "code",
                        language: "bash",
                        title: "Run from Parent Module",
                        code: `# Run from the parent directory
# -pl webapp: Selects the webapp module as the target for the goal.
# -am (also-make): Tells Maven to ALSO build all projects that webapp depends on.

mvn -pl webapp -am spring-boot:run`
                    },
                    {
                        type: "paragraph",
                        text: "The `-am` flag instructs the Reactor to include not just the specified project (`webapp`), but also all of its upstream dependencies (`api`, `core`). This creates the correct, full build plan on the fly, which should, in theory, resolve the errors."
                    }
                ]
            },
            {
                title: "16.5 The Pitfall: Why `-am` Can Still Fail",
                content: [
                    {
                        type: "paragraph",
                        text: "You might find that even with the correct `-am` flag, you still encounter a `No main manifest attribute` or `Main class not found` error. This is a known issue that highlights the brittleness of this approach."
                    },
                    {
                        type: "paragraph",
                        text: "The reason is subtle: even though `-am` correctly builds the classpath, the **execution context** of the `spring-boot:run` plugin itself can become confused when invoked from the parent. The plugin might look for configuration (like the main class to run) at the parent level instead of within the target child module (`webapp`), and since the parent has no main class, it fails. The reliability of this command can depend on the specific plugin version and project configuration."
                    },
                    {
                        type: "paragraph",
                        text: "**Key Takeaway:** While the `-pl` and `-am` flags are powerful for controlling complex builds, the simple `cd webapp && mvn spring-boot:run` approach is far more robust and reliable for local development because it provides an unambiguous context to both Maven and the Spring Boot plugin."
                    },
                    {
                        type: "quiz",
                        question: "You are in the root directory of a multi-module project and want to run the `webapp` module, which depends on a `core` module. What is the correct Maven command to tell the Reactor to build `webapp` and all its dependencies from the root directory?",
                        options: [
                            "mvn -pl webapp spring-boot:run",
                            "mvn -pl webapp -am spring-boot:run",
                            "mvn -rf webapp spring-boot:run",
                            "mvn spring-boot:run"
                        ],
                        correctAnswer: "mvn -pl webapp -am spring-boot:run",
                        explanation: "The `-pl` flag selects the `webapp` project, and `-am` (also-make) is crucial to tell Maven to also build any projects `webapp` depends on (`core`, `api`). While this is the correct command for the Reactor, remember that running from the child directory is often more reliable for `spring-boot:run`."
                    }
                ]
            }
        ]
    },
    {
        id: "part-17",
        slug: "final-exam",
        title: "Part 17: The Final Exam",
        description: "Test your knowledge and earn your diploma!",
        sections: []
    }
];
}}),
"[project]/src/components/CodeBlock.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CodeBlock": (()=>CodeBlock)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const CodeBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CodeBlock() from the server but CodeBlock is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/CodeBlock.tsx <module evaluation>", "CodeBlock");
}}),
"[project]/src/components/CodeBlock.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CodeBlock": (()=>CodeBlock)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const CodeBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call CodeBlock() from the server but CodeBlock is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/CodeBlock.tsx", "CodeBlock");
}}),
"[project]/src/components/CodeBlock.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CodeBlock$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/CodeBlock.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CodeBlock$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/src/components/CodeBlock.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CodeBlock$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/src/components/ConsoleOutput.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ConsoleOutput": (()=>ConsoleOutput)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function ConsoleOutput({ output, title }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "my-4 rounded-lg border bg-secondary/50 overflow-hidden",
        children: [
            title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 py-2 bg-muted border-b text-sm font-medium text-muted-foreground",
                children: title
            }, void 0, false, {
                fileName: "[project]/src/components/ConsoleOutput.tsx",
                lineNumber: 12,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                className: "p-4 overflow-x-auto text-sm font-code text-foreground",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                    children: output
                }, void 0, false, {
                    fileName: "[project]/src/components/ConsoleOutput.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ConsoleOutput.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ConsoleOutput.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/components/Quiz.tsx (client reference/proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Quiz": (()=>Quiz)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const Quiz = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Quiz() from the server but Quiz is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Quiz.tsx <module evaluation>", "Quiz");
}}),
"[project]/src/components/Quiz.tsx (client reference/proxy)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Quiz": (()=>Quiz)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server-edge.js [app-rsc] (ecmascript)");
;
const Quiz = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2d$edge$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Quiz() from the server but Quiz is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/Quiz.tsx", "Quiz");
}}),
"[project]/src/components/Quiz.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Quiz$2e$tsx__$28$client__reference$2f$proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/Quiz.tsx (client reference/proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Quiz$2e$tsx__$28$client__reference$2f$proxy$29$__ = __turbopack_context__.i("[project]/src/components/Quiz.tsx (client reference/proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Quiz$2e$tsx__$28$client__reference$2f$proxy$29$__);
}}),
"[project]/src/components/ui/card.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Card": (()=>Card),
    "CardContent": (()=>CardContent),
    "CardDescription": (()=>CardDescription),
    "CardFooter": (()=>CardFooter),
    "CardHeader": (()=>CardHeader),
    "CardTitle": (()=>CardTitle)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
const Card = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("rounded-lg border bg-card text-card-foreground shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, this));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("flex flex-col space-y-1.5 p-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 24,
        columnNumber: 3
    }, this));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("text-2xl font-semibold leading-none tracking-tight", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 36,
        columnNumber: 3
    }, this));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 51,
        columnNumber: 3
    }, this));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 63,
        columnNumber: 3
    }, this));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("flex items-center p-6 pt-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/card.tsx",
        lineNumber: 71,
        columnNumber: 3
    }, this));
CardFooter.displayName = "CardFooter";
;
}}),
"[project]/src/components/ui/table.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Table": (()=>Table),
    "TableBody": (()=>TableBody),
    "TableCaption": (()=>TableCaption),
    "TableCell": (()=>TableCell),
    "TableFooter": (()=>TableFooter),
    "TableHead": (()=>TableHead),
    "TableHeader": (()=>TableHeader),
    "TableRow": (()=>TableRow)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/utils.ts [app-rsc] (ecmascript)");
;
;
;
const Table = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative w-full overflow-auto",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
            ref: ref,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("w-full caption-bottom text-sm", className),
            ...props
        }, void 0, false, {
            fileName: "[project]/src/components/ui/table.tsx",
            lineNumber: 10,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 9,
        columnNumber: 3
    }, this));
Table.displayName = "Table";
const TableHeader = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("[&_tr]:border-b", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 23,
        columnNumber: 3
    }, this));
TableHeader.displayName = "TableHeader";
const TableBody = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("[&_tr:last-child]:border-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 31,
        columnNumber: 3
    }, this));
TableBody.displayName = "TableBody";
const TableFooter = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tfoot", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 43,
        columnNumber: 3
    }, this));
TableFooter.displayName = "TableFooter";
const TableRow = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 58,
        columnNumber: 3
    }, this));
TableRow.displayName = "TableRow";
const TableHead = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("h-12 px-4 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 73,
        columnNumber: 3
    }, this));
TableHead.displayName = "TableHead";
const TableCell = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("p-4 align-middle [&:has([role=checkbox])]:pr-0", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 88,
        columnNumber: 3
    }, this));
TableCell.displayName = "TableCell";
const TableCaption = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["forwardRef"])(({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("caption", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cn"])("mt-4 text-sm text-muted-foreground", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/src/components/ui/table.tsx",
        lineNumber: 100,
        columnNumber: 3
    }, this));
TableCaption.displayName = "TableCaption";
;
}}),
"[project]/src/components/ContentSection.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "ContentSection": (()=>ContentSection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CodeBlock$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/CodeBlock.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ConsoleOutput$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ConsoleOutput.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Quiz$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Quiz.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/card.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ui/table.tsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
function ContentSection({ content, slug }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: content.map((item, index)=>{
            switch(item.type){
                case "paragraph":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "leading-relaxed",
                        dangerouslySetInnerHTML: {
                            __html: item.text.replace(/\n/g, '<br />')
                        }
                    }, index, false, {
                        fileName: "[project]/src/components/ContentSection.tsx",
                        lineNumber: 14,
                        columnNumber: 20
                    }, this);
                case "code":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            item.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "font-headline text-lg font-semibold mt-6 mb-1",
                                children: item.title
                            }, void 0, false, {
                                fileName: "[project]/src/components/ContentSection.tsx",
                                lineNumber: 17,
                                columnNumber: 30
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$CodeBlock$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CodeBlock"], {
                                code: item.code,
                                language: item.language
                            }, void 0, false, {
                                fileName: "[project]/src/components/ContentSection.tsx",
                                lineNumber: 18,
                                columnNumber: 15
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/components/ContentSection.tsx",
                        lineNumber: 16,
                        columnNumber: 20
                    }, this);
                case "console":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ConsoleOutput$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ConsoleOutput"], {
                        output: item.output,
                        title: item.title
                    }, index, false, {
                        fileName: "[project]/src/components/ContentSection.tsx",
                        lineNumber: 21,
                        columnNumber: 20
                    }, this);
                case "quiz":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Quiz$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Quiz"], {
                        ...item,
                        slug: slug
                    }, index, false, {
                        fileName: "[project]/src/components/ContentSection.tsx",
                        lineNumber: 23,
                        columnNumber: 20
                    }, this);
                case "diagram":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ConsoleOutput$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ConsoleOutput"], {
                        output: item.diagram,
                        title: "Diagram"
                    }, index, false, {
                        fileName: "[project]/src/components/ContentSection.tsx",
                        lineNumber: 25,
                        columnNumber: 21
                    }, this);
                case "table":
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                        className: "my-6",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["CardContent"], {
                            className: "p-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Table"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TableHeader"], {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TableRow"], {
                                            children: item.headers.map((header, hIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TableHead"], {
                                                    className: hIndex === 0 ? "w-[200px]" : "",
                                                    children: header
                                                }, hIndex, false, {
                                                    fileName: "[project]/src/components/ContentSection.tsx",
                                                    lineNumber: 32,
                                                    columnNumber: 61
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ContentSection.tsx",
                                            lineNumber: 31,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ContentSection.tsx",
                                        lineNumber: 30,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TableBody"], {
                                        children: item.rows.map((row, rIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TableRow"], {
                                                children: row.map((cell, cIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["TableCell"], {
                                                        children: typeof cell === 'string' ? cell : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                                            className: "font-code text-primary bg-primary/10 px-1 py-0.5 rounded",
                                                            children: cell.text
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ContentSection.tsx",
                                                            lineNumber: 40,
                                                            columnNumber: 64
                                                        }, this)
                                                    }, cIndex, false, {
                                                        fileName: "[project]/src/components/ContentSection.tsx",
                                                        lineNumber: 39,
                                                        columnNumber: 27
                                                    }, this))
                                            }, rIndex, false, {
                                                fileName: "[project]/src/components/ContentSection.tsx",
                                                lineNumber: 37,
                                                columnNumber: 23
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ContentSection.tsx",
                                        lineNumber: 35,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ContentSection.tsx",
                                lineNumber: 29,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ContentSection.tsx",
                            lineNumber: 28,
                            columnNumber: 15
                        }, this)
                    }, index, false, {
                        fileName: "[project]/src/components/ContentSection.tsx",
                        lineNumber: 27,
                        columnNumber: 20
                    }, this);
                default:
                    return null;
            }
        })
    }, void 0, false, {
        fileName: "[project]/src/components/ContentSection.tsx",
        lineNumber: 10,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/app/(course)/[slug]/page.tsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>CoursePartPage),
    "generateStaticParams": (()=>generateStaticParams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$course$2d$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/course-data.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ContentSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ContentSection.tsx [app-rsc] (ecmascript)");
;
;
;
;
function generateStaticParams() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$course$2d$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["courseData"].filter((part)=>part.slug !== "final-exam").map((part)=>({
            slug: part.slug
        }));
}
async function CoursePartPage({ params }) {
    // Immediately delegate "final-exam" to its own page.
    // This prevents this component from processing a route it shouldn't handle.
    if (params.slug === "final-exam") {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    const part = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$course$2d$data$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["courseData"].find((p)=>p.slug === params.slug);
    // If no corresponding part is found in the data, show a 404 page.
    if (!part) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    const titleParts = part.title.split(/:\s(.*)/s);
    const partLabel = titleParts.length > 1 ? titleParts[0] : null;
    const mainTitle = titleParts.length > 1 ? titleParts[1] : titleParts[0];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: "max-w-4xl mx-auto p-6 sm:p-8 md:p-12",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "mb-8",
                children: [
                    partLabel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-primary font-bold font-headline",
                        children: partLabel
                    }, void 0, false, {
                        fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                        lineNumber: 35,
                        columnNumber: 31
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold font-headline tracking-tight mt-1",
                        children: mainTitle
                    }, void 0, false, {
                        fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                        lineNumber: 36,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-lg text-muted-foreground mt-2",
                        children: part.description
                    }, void 0, false, {
                        fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                        lineNumber: 37,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                lineNumber: 34,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-12",
                children: part.sections.map((section, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "font-headline text-3xl font-semibold border-b pb-2 mb-6",
                                children: section.title
                            }, void 0, false, {
                                fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                                lineNumber: 43,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ContentSection$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["ContentSection"], {
                                content: section.content,
                                slug: params.slug
                            }, void 0, false, {
                                fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                                lineNumber: 44,
                                columnNumber: 25
                            }, this)
                        ]
                    }, index, true, {
                        fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                        lineNumber: 42,
                        columnNumber: 21
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/app/(course)/[slug]/page.tsx",
                lineNumber: 40,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(course)/[slug]/page.tsx",
        lineNumber: 33,
        columnNumber: 9
    }, this);
}
}}),
"[project]/src/app/(course)/[slug]/page.tsx [app-rsc] (ecmascript, Next.js server component)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/(course)/[slug]/page.tsx [app-rsc] (ecmascript)"));
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__b7021f59._.js.map