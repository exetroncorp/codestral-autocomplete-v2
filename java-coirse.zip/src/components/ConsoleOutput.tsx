import { cn } from "@/lib/utils";

interface ConsoleOutputProps {
  output: string;
  title?: string;
}

export function ConsoleOutput({ output, title }: ConsoleOutputProps) {
  return (
    <div className="my-4 rounded-lg border bg-secondary/50 overflow-hidden">
      {title && (
        <div className="px-4 py-2 bg-muted border-b text-sm font-medium text-muted-foreground">
          {title}
        </div>
      )}
      <pre className="p-4 overflow-x-auto text-sm font-code text-foreground">
        <code>{output}</code>
      </pre>
    </div>
  );
}
