import * as vscode from 'vscode';
import { ConfigManager, CodestralConfig } from './config/ConfigManager';
import { CodestralClient } from './completion/CodestralClient';
import { CodestralCompletionProvider } from './completion/CompletionProvider';
import { Logger } from './utils/Logger';
import { StatusBarManager, StatusBarStatus } from './utils/StatusBar';
import { CompletionCache } from './utils/CompletionCache';

let logger: Logger;
let client: CodestralClient;
let completionProvider: CodestralCompletionProvider;
let statusBar: StatusBarManager;
let completionProviderDisposable: vscode.Disposable | null = null;
let configChangeDisposable: vscode.Disposable | null = null;

export function activate(context: vscode.ExtensionContext) {
    console.log('Codestral Autocomplete V2 extension is now active');

    try {
        // Initialize configuration and logger
        const config = ConfigManager.getConfig();
        logger = new Logger(config.enableLogging);
        logger.log('Extension activated');

        // Validate configuration
        const configErrors = ConfigManager.validateConfig(config);
        if (configErrors.length > 0) {
            const errorMessage = `Codestral configuration errors: ${configErrors.join(', ')}`;
            logger.error(errorMessage);
            vscode.window.showErrorMessage(errorMessage, 'Open Settings').then((selection) => {
                if (selection === 'Open Settings') {
                    vscode.commands.executeCommand('workbench.action.openSettings', 'codestral-autocomplete');
                }
            });
            return;
        }

        // Initialize components
        statusBar = new StatusBarManager();
        client = new CodestralClient(config, logger);
        completionProvider = new CodestralCompletionProvider(client, config, logger, statusBar);

        // Set initial status
        statusBar.setStatus(config.enabled ? StatusBarStatus.Enabled : StatusBarStatus.Disabled);

        // Register completion provider
        registerCompletionProvider();

        // Register commands
        registerCommands(context);

        // Watch for configuration changes
        configChangeDisposable = ConfigManager.onConfigurationChanged(() => {
            handleConfigurationChange();
        });

        // Add disposables to context
        context.subscriptions.push(
            logger,
            statusBar,
            configChangeDisposable
        );

        // Test connection on startup if API key is provided
        if (config.apiKey.trim()) {
            testConnectionOnStartup();
        } else {
            vscode.window.showWarningMessage(
                'Codestral API key not configured. Please set it in the extension settings.',
                'Open Settings'
            ).then(selection => {
                if (selection === 'Open Settings') {
                    vscode.commands.executeCommand('workbench.action.openSettings', 'codestral-autocomplete.apiKey');
                }
            });
        }

        logger.log('Extension initialization completed successfully');

    } catch (error) {
        logger?.error('Failed to initialize extension:', error);
        vscode.window.showErrorMessage('Failed to initialize Codestral Autocomplete extension');
    }
}

function registerCompletionProvider(): void {
    // Dispose existing provider if any
    if (completionProviderDisposable) {
        completionProviderDisposable.dispose();
    }

    // Register for all supported languages
    const supportedLanguages = [
        'javascript', 'typescript', 'python', 'java', 'csharp', 'cpp', 'c',
        'go', 'rust', 'php', 'ruby', 'swift', 'kotlin', 'scala', 'html',
        'css', 'scss', 'less', 'json', 'yaml', 'xml', 'markdown', 'sql',
        'shell', 'powershell', 'dockerfile', 'makefile'
    ];

    completionProviderDisposable = vscode.languages.registerInlineCompletionItemProvider(
        supportedLanguages,
        completionProvider
    );

    logger.log(`Completion provider registered for ${supportedLanguages.length} languages`);
}

function registerCommands(context: vscode.ExtensionContext): void {
    // Toggle autocomplete command
    const toggleCommand = vscode.commands.registerCommand('codestral-autocomplete.toggle', () => {
        statusBar.toggle();
        const isEnabled = statusBar.isEnabled();
        ConfigManager.updateConfig('enabled', isEnabled);
        
        const message = isEnabled ? 'Codestral autocomplete enabled' : 'Codestral autocomplete disabled';
        vscode.window.showInformationMessage(message);
        logger.log(message);
    });

    // Force completion command
    const forceCompletionCommand = vscode.commands.registerCommand('codestral-autocomplete.forceCompletion', () => {
        vscode.commands.executeCommand('editor.action.inlineSuggest.trigger');
    });

    // Clear cache command
    const clearCacheCommand = vscode.commands.registerCommand('codestral-autocomplete.clearCache', () => {
        const cache = CompletionCache.getInstance();
        cache.clear();
        vscode.window.showInformationMessage('Codestral completion cache cleared');
        logger.log('Completion cache cleared');
    });

    // Show logs command
    const showLogsCommand = vscode.commands.registerCommand('codestral-autocomplete.showLogs', () => {
        logger.show();
    });

    context.subscriptions.push(
        toggleCommand,
        forceCompletionCommand,
        clearCacheCommand,
        showLogsCommand
    );
}

function handleConfigurationChange(): void {
    try {
        logger.log('Configuration changed, updating components');
        
        const newConfig = ConfigManager.getConfig();
        
        // Validate new configuration
        const configErrors = ConfigManager.validateConfig(newConfig);
        if (configErrors.length > 0) {
            const errorMessage = `Codestral configuration errors: ${configErrors.join(', ')}`;
            logger.error(errorMessage);
            vscode.window.showErrorMessage(errorMessage);
            statusBar.setError(true);
            return;
        }

        // Clear any previous errors
        statusBar.setError(false);

        // Update components
        completionProvider.updateConfig(newConfig);
        statusBar.setStatus(newConfig.enabled ? StatusBarStatus.Enabled : StatusBarStatus.Disabled);

        // Re-register completion provider
        registerCompletionProvider();

        logger.log('Configuration update completed');

    } catch (error) {
        logger.error('Error handling configuration change:', error);
        statusBar.setError(true);
    }
}

async function testConnectionOnStartup(): Promise<void> {
    try {
        logger.log('Testing connection on startup');
        const isConnected = await client.testConnection();
        
        if (isConnected) {
            logger.log('Connection test successful');
            vscode.window.showInformationMessage('Codestral Autocomplete is ready!');
            statusBar.setError(false);
        } else {
            logger.error('Connection test failed');
            statusBar.setError(true);
            vscode.window.showWarningMessage(
                'Failed to connect to Codestral API. Please check your configuration.',
                'Open Settings',
                'Show Logs'
            ).then(selection => {
                if (selection === 'Open Settings') {
                    vscode.commands.executeCommand('workbench.action.openSettings', 'codestral-autocomplete');
                } else if (selection === 'Show Logs') {
                    logger.show();
                }
            });
        }
    } catch (error) {
        logger.error('Error during startup connection test:', error);
        statusBar.setError(true);
    }
}

export function deactivate() {
    logger?.log('Extension deactivated');
    
    // Dispose all components
    if (completionProviderDisposable) {
        completionProviderDisposable.dispose();
    }
    if (configChangeDisposable) {
        configChangeDisposable.dispose();
    }
    
    completionProvider?.dispose();
    statusBar?.dispose();
    logger?.dispose();
}
