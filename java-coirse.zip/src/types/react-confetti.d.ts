declare module 'react-confetti';
