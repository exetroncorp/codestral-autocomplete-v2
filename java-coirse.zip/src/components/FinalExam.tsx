
"use client";

import { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { Check, X, Clock, Trophy, PartyPopper, Printer, CheckCircle, XCircle, BookText, Frown } from 'lucide-react';
import Confetti from 'react-confetti';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import Image from 'next/image';

const examQuestions = [
    {
        question: "In a Spring Boot 'fat JAR', what does the `Main-Class` entry in `MANIFEST.MF` typically point to?",
        options: [
            "Your application's main class (e.g., com.example.MyApplication)",
            "A special launcher class provided by Spring Boot (e.g., JarLauncher)",
            "The Java Virtual Machine itself",
            "It is not required for Spring Boot applications"
        ],
        correctAnswer: "A special launcher class provided by Spring Boot (e.g., JarLauncher)",
        explanation: "Spring Boot's executable JAR sets its `Main-Class` to a special launcher. This launcher first sets up a custom ClassLoader that can read nested dependency JARs from `BOOT-INF/lib/` and then calls your application's actual main method."
    },
    {
        question: "What is the primary purpose of the `<dependencyManagement>` section in a parent POM?",
        options: [
            "To force all child modules to include a dependency.",
            "To centralize dependency versions for all child modules to use.",
            "To download dependencies for the parent project.",
            "To exclude dependencies from the final build."
        ],
        correctAnswer: "To centralize dependency versions for all child modules to use.",
        explanation: "The `<dependencyManagement>` block allows a parent POM to declare dependency versions without forcing those dependencies on its children. Child modules can then include the dependency without a version tag, inheriting the version from the parent, which ensures consistency across the entire project."
    },
    {
        question: "If you activate a Spring profile using a command-line argument (`--spring.profiles.active=prod`), and also have `spring.profiles.active=dev` in `application.properties`, which profile will be active?",
        options: ["dev", "prod", "Both will be active", "The application will fail to start"],
        correctAnswer: "prod",
        explanation: "Spring has a clear order of precedence for loading properties. Command-line arguments have higher precedence than properties defined in `application.properties`. Therefore, the `prod` profile will override the `dev` profile."
    },
    {
        question: "In the JVM, where are objects and class instances stored at runtime?",
        options: ["The Stack", "The Method Area", "The Heap", "PC Registers"],
        correctAnswer: "The Heap",
        explanation: "The Heap is the runtime data area from which memory for all class instances and arrays is allocated. It is the main memory resource managed by the Garbage Collector. The Stack is used for method execution frames and local variables."
    },
    {
        question: "When running a multi-module project with `mvn spring-boot:run`, how does it access the code from your other modules (like a 'core' library)?",
        options: [
            "It uses the module's JAR file from the `.m2` repository.",
            "It adds the module's `target/classes` directory to the classpath.",
            "It copies the source code into the main module.",
            "It requires you to publish the module to a remote repository first."
        ],
        correctAnswer: "It adds the module's `target/classes` directory to the classpath.",
        explanation: "This is a key feature for development. Instead of using the JAR from the local `.m2` repository, `spring-boot:run` uses the compiled output directory directly. This allows it to pick up changes on the fly when you recompile a single file, enabling hot-reloading with DevTools."
    },
    {
        question: "What is the primary benefit of Dependency Injection?",
        options: [
            "It makes applications run faster.",
            "It reduces the size of the final JAR.",
            "It decouples components, making them easier to test and maintain.",
            "It automatically secures your application."
        ],
        correctAnswer: "It decouples components, making them easier to test and maintain.",
        explanation: "Dependency Injection inverts control, so instead of an object creating its own dependencies, they are provided (injected) by the Spring container. This removes hard-coded connections, making it easy to substitute mock implementations for testing and improving modularity."
    },
    {
        question: "What does the `@PostConstruct` annotation do on a method in a Spring bean?",
        options: [
            "It runs the method before the bean's constructor is called.",
            "It runs the method every time the bean is accessed.",
            "It runs the method just before the bean is destroyed.",
            "It runs the method after the bean is created and its dependencies are injected."
        ],
        correctAnswer: "It runs the method after the bean is created and its dependencies are injected.",
        explanation: "The `@PostConstruct` annotation is a lifecycle callback. It ensures that the annotated method is executed only after the bean's constructor has been called and all `@Autowired` dependencies have been successfully injected, making it the perfect place for initialization logic that relies on those dependencies."
    },
    {
        question: "In Clean/Hexagonal Architecture, what is a 'Port'?",
        options: ["A specific technology adapter, like a REST controller.", "An interface defined in the core application layer that dictates a contract for interaction.", "A physical network port used for communication.", "A configuration file for database connections."],
        correctAnswer: "An interface defined in the core application layer that dictates a contract for interaction.",
        explanation: "In Hexagonal Architecture, a 'Port' is an interface that belongs to the application's core. It defines a contract for how the application can be driven (e.g., by a web controller) or how it drives other tools (e.g., a database), without knowing the specific technology used in the adapter."
    },
    {
        question: "What is the primary role of the Maven Reactor?",
        options: ["To download dependencies from Maven Central.", "To compile Java source code.", "To analyze project modules and determine the correct build order.", "To run unit tests and generate reports."],
        correctAnswer: "To analyze project modules and determine the correct build order.",
        explanation: "The Maven Reactor is the part of the Maven core that handles multi-module projects. It first reads all the module POMs, calculates the dependency graph between them, and creates a build plan that ensures modules are built in the correct order."
    },
    {
        question: "When using Spring Boot DevTools, what is its main function during development?",
        options: ["It provides an in-browser code editor.", "It automatically watches for classpath changes and triggers a fast application restart.", "It scans your code for security vulnerabilities.", "It optimizes the final JAR for production."],
        correctAnswer: "It automatically watches for classpath changes and triggers a fast application restart.",
        explanation: "Spring Boot DevTools significantly improves the development workflow by monitoring the classpath. When it detects a change (like a recompiled `.class` file), it performs an intelligent and fast restart of the application, allowing developers to see their code changes reflected almost instantly."
    },
    {
        question: "What is the purpose of the `<scope>import</scope>` when using a Maven Bill of Materials (BOM)?",
        options: ["It forces the dependency to be included in all child modules.", "It imports all dependencies from the BOM directly into your project's `<dependencies>` section.", "It allows you to manage the versions of multiple dependencies by importing them from the BOM's `<dependencyManagement>` section.", "It tells Maven to ignore the dependency during the `package` phase."],
        correctAnswer: "It allows you to manage the versions of multiple dependencies by importing them from the BOM's `<dependencyManagement>` section.",
        explanation: "Using `<scope>import` with a Bill of Materials (BOM) is a powerful way to manage dependency versions. It effectively merges the `<dependencyManagement>` section from the specified POM (like `spring-boot-dependencies`) into your own project's `<dependencyManagement>`."
    },
    {
        question: "In the JVM's Garbage Collection process, what is a 'Stop-the-World' event?",
        options: ["When the JVM shuts down completely.", "An event where the application's execution is paused completely while the GC runs.", "When the JIT compiler optimizes code.", "A security feature that prevents memory leaks."],
        correctAnswer: "An event where the application's execution is paused completely while the GC runs.",
        explanation: "Many garbage collection algorithms require a 'Stop-the-World' pause. During this event, all application threads are frozen so the GC can safely analyze the object graph and reclaim memory without the application modifying objects at the same time. Minimizing these pauses is a key goal of GC tuning."
    }
];

type QuizState = 'idle' | 'active' | 'finished';

export function FinalExam() {
    const [name, setName] = useState('');
    const [quizState, setQuizState] = useState<QuizState>('idle');
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
    const [answerStatus, setAnswerStatus] = useState<'correct' | 'incorrect' | null>(null);
    const [time, setTime] = useState(0);
    const [showConfetti, setShowConfetti] = useState(false);
    const [showExplanations, setShowExplanations] = useState(false);

    useEffect(() => {
        let timer: NodeJS.Timeout;
        if (quizState === 'active') {
            timer = setInterval(() => {
                setTime(prevTime => prevTime + 1);
            }, 1000);
        }
        return () => clearInterval(timer);
    }, [quizState]);

    const score = useMemo(() => {
        // This is a more robust way to calculate the score. It iterates through the
        // questions and checks the selectedAnswers map, rather than relying on
        // Object.values(), which does not guarantee order and can cause bugs.
        return examQuestions.reduce((count, question, index) => {
            if (selectedAnswers[index] === question.correctAnswer) {
                return count + 1;
            }
            return count;
        }, 0);
    }, [selectedAnswers]);

    useEffect(() => {
        if (quizState === 'finished') {
            const scorePercentage = (score / examQuestions.length) * 100;
            if (scorePercentage >= 80) {
                setShowConfetti(true);
            }
        }
    }, [quizState, score]);

    const handleStart = () => {
        if (name.trim()) {
            setQuizState('active');
            setShowExplanations(false);
        }
    };

    const handleNext = () => {
        const isFinished = currentQuestionIndex >= examQuestions.length - 1;
        setAnswerStatus(null);
        if (isFinished) {
            setQuizState('finished');
        } else {
            setCurrentQuestionIndex(prev => prev + 1);
        }
    };

    const handleSelectAnswer = (option: string) => {
        if (answerStatus) return;

        setSelectedAnswers(prev => ({ ...prev, [currentQuestionIndex]: option }));
        if (option === examQuestions[currentQuestionIndex].correctAnswer) {
            setAnswerStatus('correct');
        } else {
            setAnswerStatus('incorrect');
        }

        setTimeout(() => {
            handleNext();
        }, 1500);
    };
    
    const handleReset = () => {
        setQuizState('idle');
        setCurrentQuestionIndex(0);
        setSelectedAnswers({});
        setAnswerStatus(null);
        setTime(0);
        setShowConfetti(false);
        setName('');
        setShowExplanations(false);
    };

    const formatTime = (totalSeconds: number) => {
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    };

    if (quizState === 'idle') {
        return (
            <Card className="animate-pop-in">
                <CardHeader>
                    <CardTitle>Ready for the challenge?</CardTitle>
                    <CardDescription>Enter your name to begin the final exam and earn your diploma.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Input 
                        placeholder="Enter your name..." 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="text-lg"
                    />
                </CardContent>
                <CardFooter>
                    <Button size="lg" onClick={handleStart} disabled={!name.trim()}>Start Exam</Button>
                </CardFooter>
            </Card>
        );
    }

    if (quizState === 'active') {
        const currentQuestion = examQuestions[currentQuestionIndex];
        const progress = ((currentQuestionIndex + 1) / examQuestions.length) * 100;
        return (
            <Card className="animate-pop-in">
                <CardHeader>
                    <div className="flex justify-between items-center mb-4">
                        <p className="text-sm text-muted-foreground">Question {currentQuestionIndex + 1} of {examQuestions.length}</p>
                        <div className="flex items-center gap-2 text-primary font-semibold">
                            <Clock className="h-4 w-4" />
                            <span>{formatTime(time)}</span>
                        </div>
                    </div>
                    <Progress value={progress} className="w-full" />
                    <CardTitle className="pt-6 !text-2xl">{currentQuestion.question}</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {currentQuestion.options.map((option, index) => {
                             const isSelected = selectedAnswers[currentQuestionIndex] === option;
                             const isCorrect = option === currentQuestion.correctAnswer;
                             
                             return (
                                <Button
                                    key={index}
                                    variant="outline"
                                    size="lg"
                                    className={cn(
                                        "h-auto py-4 whitespace-normal justify-start text-left animate-pop-in",
                                        answerStatus && isSelected && answerStatus === 'incorrect' && 'bg-destructive/20 border-destructive text-destructive-foreground animate-shake',
                                        answerStatus && isCorrect && 'bg-primary/20 border-primary text-primary-foreground animate-pulse-correct',
                                    )}
                                    style={{ animationDelay: `${index * 100}ms` }}
                                    onClick={() => handleSelectAnswer(option)}
                                    disabled={!!answerStatus}
                                >
                                    <div className="flex items-center w-full">
                                        <div className="flex-1">{option}</div>
                                        {answerStatus && isSelected && answerStatus === 'correct' && <Check className="h-6 w-6 text-primary" />}
                                        {answerStatus && isSelected && answerStatus === 'incorrect' && <X className="h-6 w-6 text-destructive" />}
                                    </div>
                                </Button>
                             )
                        })}
                    </div>
                </CardContent>
            </Card>
        );
    }
    
    if (quizState === 'finished') {
        const scorePercentage = Math.round((score / examQuestions.length) * 100);
        const passed = scorePercentage >= 80;

        const ReviewSection = () => (
             <Card className="animate-pop-in">
                <CardHeader>
                    <CardTitle>Answer Review</CardTitle>
                    <CardDescription>Here are the explanations for each question.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Accordion type="single" collapsible className="w-full">
                        {examQuestions.map((q, index) => (
                            <AccordionItem value={`item-${index}`} key={index}>
                                <AccordionTrigger>
                                    <div className="flex items-center gap-4 text-left flex-1">
                                        {selectedAnswers[index] === q.correctAnswer ? (
                                            <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                                        ) : (
                                            <XCircle className="h-5 w-5 text-destructive flex-shrink-0" />
                                        )}
                                        <span className="flex-1">Question {index + 1}: {q.question}</span>
                                    </div>
                                </AccordionTrigger>
                                <AccordionContent>
                                    <div className="space-y-4 p-2">
                                        <p><strong>Your Answer:</strong> <span className={cn(selectedAnswers[index] === q.correctAnswer ? "text-primary" : "text-destructive")}>{selectedAnswers[index] || 'Not answered'}</span></p>
                                        <p><strong>Correct Answer:</strong> {q.correctAnswer}</p>
                                        <div className="p-4 bg-muted/50 rounded-md border">
                                            <h4 className="font-semibold mb-2">Explanation</h4>
                                            <p className="text-sm text-muted-foreground">{q.explanation}</p>
                                        </div>
                                    </div>
                                </AccordionContent>
                            </AccordionItem>
                        ))}
                    </Accordion>
                </CardContent>
            </Card>
        );

        if (passed) {
            return (
                 <>
                    {showConfetti && <Confetti recycle={false} numberOfPieces={400} />}
                    <div className="w-full max-w-4xl space-y-8">
                        <Card id="diploma" className="animate-pop-in border-4 border-primary/50 shadow-2xl bg-secondary/20">
                            <CardHeader className="text-center items-center">
                                <Trophy className="h-16 w-16 text-primary" />
                                <CardTitle className="!text-4xl font-headline mt-2">
                                   Congratulations!
                                </CardTitle>
                                <CardDescription className="text-lg">
                                   You've passed the final exam.
                                </CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div className="text-center p-8 border-2 border-dashed border-primary/30 rounded-lg">
                                    <h2 className="text-2xl font-bold font-headline text-primary">Certificate of Completion</h2>
                                    <p className="mt-4 text-muted-foreground">This certifies that</p>
                                    <p className="text-3xl font-bold my-2">{name}</p>
                                    <p className="text-muted-foreground">has successfully completed the Java Deep Dive course on</p>
                                    <p className="font-semibold">{new Date().toLocaleDateString()}</p>
                                    <div className="flex justify-around mt-8">
                                        <div>
                                            <p className="text-sm text-muted-foreground">Final Score</p>
                                            <p className={cn("text-3xl font-bold", passed ? "text-primary" : "text-destructive")}>{scorePercentage}%</p>
                                            <p className="text-xs">({score}/{examQuestions.length} correct)</p>
                                        </div>
                                        <div>
                                            <p className="text-sm text-muted-foreground">Time Taken</p>
                                            <p className="text-3xl font-bold">{formatTime(time)}</p>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                            <CardFooter className="flex-wrap justify-center gap-4 no-print">
                                <Button variant="outline" onClick={() => window.print()}>
                                    <Printer className="mr-2 h-4 w-4" />
                                    Print Diploma
                                </Button>
                                <Button variant="secondary" onClick={() => setShowExplanations(!showExplanations)}>
                                    <BookText className="mr-2 h-4 w-4" />
                                    {showExplanations ? 'Hide Explanations' : 'Review Answers'}
                                </Button>
                                <Button size="lg" onClick={handleReset}>
                                Try Again
                                </Button>
                            </CardFooter>
                        </Card>

                        {showExplanations && <ReviewSection />}
                    </div>
                </>
            );
        } else {
            return (
                <div className="w-full max-w-2xl mx-auto space-y-8 animate-pop-in">
                    <Card className="text-center">
                        <CardHeader>
                            {scorePercentage < 30 ? (
                                <Frown className="h-16 w-16 text-muted-foreground mx-auto" />
                            ) : (
                                <PartyPopper className="h-16 w-16 text-muted-foreground mx-auto" />
                            )}
                            <CardTitle className="!text-4xl font-headline mt-2">
                                {scorePercentage < 30 ? "Ouch!" : "Great Effort!"}
                            </CardTitle>
                            <CardDescription className="text-lg">
                                You didn't pass this time, but don't give up.
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            {scorePercentage < 30 && (
                                <div className="mb-6 flex justify-center">
                                    <Image
                                        src="https://placehold.co/400x400.png"
                                        width={400}
                                        height={400}
                                        alt="A picture representing a very low score"
                                        className="rounded-lg shadow-md"
                                        data-ai-hint="sad chimpanzee"
                                    />
                                </div>
                            )}
                            <div className="text-center p-8 border-2 border-dashed border-destructive/30 rounded-lg bg-destructive/10">
                                <p className="text-sm text-muted-foreground">Your Score</p>
                                <p className={cn("text-4xl font-bold text-destructive")}>{scorePercentage}%</p>
                                <p className="text-xs text-muted-foreground">({score}/{examQuestions.length} correct)</p>
                                <p className="mt-4">You need at least 80% to pass. Review the answers and try again!</p>
                            </div>
                        </CardContent>
                        <CardFooter className="flex-wrap justify-center gap-4">
                            <Button variant="secondary" onClick={() => setShowExplanations(!showExplanations)}>
                                <BookText className="mr-2 h-4 w-4" />
                                {showExplanations ? 'Hide Explanations' : 'Review Answers'}
                            </Button>
                            <Button size="lg" onClick={handleReset}>
                                Try Again
                            </Button>
                        </CardFooter>
                    </Card>

                    {showExplanations && <ReviewSection />}
                </div>
            );
        }
    }

    return null;
}
