import * as vscode from 'vscode';

export class Logger {
    private outputChannel: vscode.OutputChannel;
    private enabled: boolean;

    constructor(enabled: boolean = false) {
        this.outputChannel = vscode.window.createOutputChannel('Codestral Autocomplete');
        this.enabled = enabled;
    }

    setLoggingEnabled(enabled: boolean): void {
        this.enabled = enabled;
    }

    log(message: string, ...args: any[]): void {
        if (!this.enabled) return;
        
        const timestamp = new Date().toISOString();
        const formattedMessage = `[${timestamp}] ${message}`;
        
        if (args.length > 0) {
            console.log(formattedMessage, ...args);
            this.outputChannel.appendLine(`${formattedMessage} ${args.map(arg => 
                typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
            ).join(' ')}`);
        } else {
            console.log(formattedMessage);
            this.outputChannel.appendLine(formattedMessage);
        }
    }

    error(message: string, error?: any): void {
        const timestamp = new Date().toISOString();
        const formattedMessage = `[${timestamp}] ERROR: ${message}`;
        
        if (error) {
            console.error(formattedMessage, error);
            this.outputChannel.appendLine(`${formattedMessage} ${error instanceof Error ? error.stack : String(error)}`);
        } else {
            console.error(formattedMessage);
            this.outputChannel.appendLine(formattedMessage);
        }
    }

    warn(message: string, ...args: any[]): void {
        const timestamp = new Date().toISOString();
        const formattedMessage = `[${timestamp}] WARN: ${message}`;
        
        if (args.length > 0) {
            console.warn(formattedMessage, ...args);
            this.outputChannel.appendLine(`${formattedMessage} ${args.map(arg => 
                typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
            ).join(' ')}`);
        } else {
            console.warn(formattedMessage);
            this.outputChannel.appendLine(formattedMessage);
        }
    }

    show(): void {
        this.outputChannel.show();
    }

    dispose(): void {
        this.outputChannel.dispose();
    }
}
