(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_25005c80._.js",
  "static/chunks/src_3e46689a._.js"
],
    source: "dynamic"
});
