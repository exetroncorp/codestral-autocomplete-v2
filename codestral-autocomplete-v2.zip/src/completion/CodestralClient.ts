import { CodestralConfig } from '../config/ConfigManager';
import { Logger } from '../utils/Logger';
import fetch from 'node-fetch';
import * as https from 'https';

export interface CompletionRequest {
    model: string;
    prompt: string;
    suffix?: string;
    max_tokens: number;
    temperature: number;
    stop?: string[];
}

export interface CompletionResponse {
    id: string;
    object: string;
    created: number;
    model: string;
    choices: Array<{
        index: number;
        message: {
            content: string;
        };
        finish_reason: string;
    }>;
}

export class CodestralClient {
    private config: CodestralConfig;
    private logger: Logger;

    constructor(config: CodestralConfig, logger: Logger) {
        this.config = config;
        this.logger = logger;
    }

    updateConfig(config: CodestralConfig): void {
        this.config = config;
    }

    async testConnection(): Promise<boolean> {
        try {
            this.logger.log('Testing Codestral API connection...');
            
            const response = await this.makeRequest({
                model: this.config.model,
                prompt: 'test',
                max_tokens: 1,
                temperature: 0.1,
            });

            return response !== null;
        } catch (error) {
            this.logger.error('Connection test failed:', error);
            return false;
        }
    }

    async getCompletion(
        prefix: string,
        suffix: string = '',
        languageId: string = '',
        signal?: AbortSignal
    ): Promise<string | null> {
        try {
            this.logger.log(`Getting completion for language: ${languageId}`);
            this.logger.log(`Prefix length: ${prefix.length}, Suffix length: ${suffix.length}`);

            // Use Continue's EXACT Codestral FIM template
            const prompt = this.formatCodestralFimPrompt(prefix, suffix);

            const request: CompletionRequest = {
                model: this.config.model,
                prompt: prompt,
                max_tokens: this.config.maxTokens,
                temperature: this.config.temperature,
                stop: this.getCodestralStopTokens(),
            };

            const response = await this.makeRequest(request, signal);

            if (!response || !response.choices || response.choices.length === 0) {
                this.logger.log('No completion choices returned');
                return null;
            }

            const completion = response.choices[0].message.content;
            this.logger.log(`Received completion: "${completion.substring(0, 100)}..."`);

            return completion;
        } catch (error) {
            if (signal?.aborted) {
                this.logger.log('Completion request was aborted');
                return null;
            }

            this.logger.error('Error getting completion:', error);
            throw error;
        }
    }

    /**
     * Use Continue's EXACT Codestral FIM template
     */
    private formatCodestralFimPrompt(prefix: string, suffix: string): string {
        // From Continue: "[SUFFIX]{{{suffix}}}[PREFIX]{{{prefix}}}"
        return `[SUFFIX]${suffix}[PREFIX]${prefix}`;
    }

    /**
     * Use Continue's EXACT Codestral stop tokens
     */
    private getCodestralStopTokens(): string[] {
        // From Continue: stop: ["[PREFIX]", "[SUFFIX]"]
        return ["[PREFIX]", "[SUFFIX]"];
    }

    private async makeRequest(
        request: CompletionRequest,
        signal?: AbortSignal
    ): Promise<CompletionResponse | null> {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

        // Combine external signal with timeout
        if (signal) {
            signal.addEventListener('abort', () => controller.abort());
        }

        try {
            this.logger.log('Making request to Codestral API...');

            // Create HTTPS agent based on configuration
            const httpsAgent = this.config.ignoreSslErrors ? new https.Agent({
                rejectUnauthorized: false // Ignore SSL/TLS certificate errors
            }) : undefined;

            const response = await fetch(this.config.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.config.apiKey}`,
                },
                body: JSON.stringify(request),
                signal: controller.signal,
                agent: this.config.apiEndpoint.startsWith('https:') && httpsAgent ? httpsAgent : undefined,
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`HTTP ${response.status}: ${errorText}`);
            }

            const data = await response.json() as CompletionResponse;
            this.logger.log('Successfully received response from Codestral API');

            return data;
        } catch (error) {
            clearTimeout(timeoutId);
            
            if (error instanceof Error && error.name === 'AbortError') {
                this.logger.log('Request was aborted');
                return null;
            }
            
            throw error;
        }
    }


}
