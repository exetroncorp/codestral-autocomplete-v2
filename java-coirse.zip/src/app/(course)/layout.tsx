import { CourseNav } from "@/components/CourseNav";

export default function CourseLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen">
      <aside className="fixed top-0 left-0 h-full w-80 border-r bg-card hidden lg:flex">
        <CourseNav />
      </aside>
      <main className="lg:pl-80 w-full">
          {children}
      </main>
    </div>
  );
}
