import * as assert from 'assert';
import { ConfigManager, AutocompleteDebouncer } from '../config/ConfigManager';

suite('ConfigManager Test Suite', () => {
    
    test('should validate valid configuration', () => {
        const config = {
            apiKey: 'test-key',
            apiEndpoint: 'https://api.test.com',
            model: 'test-model',
            enabled: true,
            manualMode: false,
            debounceDelay: 300,
            timeout: 10000,
            maxTokens: 64,
            temperature: 0.1,
            enableLogging: false,
            minTriggerChars: 2,
            useCache: true,
            ignoreSslErrors: false,
        };

        const errors = ConfigManager.validateConfig(config);
        assert.strictEqual(errors.length, 0);
    });

    test('should detect missing API key', () => {
        const config = {
            apiKey: '',
            apiEndpoint: 'https://api.test.com',
            model: 'test-model',
            enabled: true,
            manualMode: false,
            debounceDelay: 300,
            timeout: 10000,
            maxTokens: 64,
            temperature: 0.1,
            enableLogging: false,
            minTriggerChars: 2,
            useCache: true,
            ignoreSslErrors: false,
        };

        const errors = ConfigManager.validateConfig(config);
        assert.ok(errors.includes('API key is required'));
    });

    test('should detect invalid temperature', () => {
        const config = {
            apiKey: 'test-key',
            apiEndpoint: 'https://api.test.com',
            model: 'test-model',
            enabled: true,
            manualMode: false,
            debounceDelay: 300,
            timeout: 10000,
            maxTokens: 64,
            temperature: 3.0, // Invalid: > 2
            enableLogging: false,
            minTriggerChars: 2,
            useCache: true,
            ignoreSslErrors: false,
        };

        const errors = ConfigManager.validateConfig(config);
        assert.ok(errors.includes('Temperature must be between 0 and 2'));
    });

    test('should detect negative timeout', () => {
        const config = {
            apiKey: 'test-key',
            apiEndpoint: 'https://api.test.com',
            model: 'test-model',
            enabled: true,
            manualMode: false,
            debounceDelay: 300,
            timeout: -1000, // Invalid: negative
            maxTokens: 64,
            temperature: 0.1,
            enableLogging: false,
            minTriggerChars: 2,
            useCache: true,
            ignoreSslErrors: false,
        };

        const errors = ConfigManager.validateConfig(config);
        assert.ok(errors.includes('Timeout must be positive'));
    });
});

suite('AutocompleteDebouncer Test Suite', () => {
    
    test('should not debounce first request', async () => {
        const debouncer = new AutocompleteDebouncer();
        const shouldDebounce = await debouncer.delayAndShouldDebounce(100);
        assert.strictEqual(shouldDebounce, false);
    });

    test('should debounce rapid requests', async () => {
        const debouncer = new AutocompleteDebouncer();
        
        // Start first request
        const promise1 = debouncer.delayAndShouldDebounce(200);
        
        // Start second request immediately
        const promise2 = debouncer.delayAndShouldDebounce(200);
        
        const [result1, result2] = await Promise.all([promise1, promise2]);
        
        // First request should be debounced, second should proceed
        assert.strictEqual(result1, true);  // debounced
        assert.strictEqual(result2, false); // not debounced
    });

    test('should cancel debouncing', async () => {
        const debouncer = new AutocompleteDebouncer();
        
        // Start a request
        const promise = debouncer.delayAndShouldDebounce(1000);
        
        // Cancel immediately
        debouncer.cancel();
        
        // The promise should still resolve, but the behavior is implementation-dependent
        // This test mainly ensures cancel() doesn't throw
        assert.doesNotThrow(() => debouncer.cancel());
    });
});
