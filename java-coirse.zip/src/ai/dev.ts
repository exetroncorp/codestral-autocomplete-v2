import { config } from 'dotenv';
config();

import '@/ai/flows/explain-code-snippet.ts';