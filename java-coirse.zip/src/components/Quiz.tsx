
"use client";

import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Label } from "./ui/label";
import { Button } from "./ui/button";
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";
import { CheckCircle, XCircle } from "lucide-react";
import { useRouter } from "next/navigation";
import { courseData } from "@/lib/course-data";

interface QuizProps {
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  slug: string;
}

export function Quiz({
  question,
  options,
  correctAnswer,
  explanation,
  slug,
}: QuizProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAnswer) {
      setSubmitted(true);
    }
  };

  const isCorrect = selectedAnswer === correctAnswer;

  const currentIndex = courseData.findIndex((part) => part.slug === slug);
  const nextPart =
    currentIndex > -1 && currentIndex < courseData.length - 1
      ? courseData[currentIndex + 1]
      : null;

  useEffect(() => {
    if (submitted && isCorrect && nextPart) {
      const timer = setTimeout(() => {
        router.push(`/${nextPart.slug}`);
      }, 2500); // 2.5-second delay to read the explanation

      return () => clearTimeout(timer);
    }
  }, [submitted, isCorrect, nextPart, router]);


  return (
    <Card className="my-8 bg-secondary/30">
      <CardHeader>
        <CardTitle className="font-headline text-xl">Check Your Understanding</CardTitle>
        <CardDescription>{question}</CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent>
          <RadioGroup
            onValueChange={setSelectedAnswer}
            disabled={submitted}
            value={selectedAnswer ?? undefined}
          >
            <div className="space-y-3">
              {options.map((option, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <RadioGroupItem value={option} id={`q-${index}`} />
                  <Label htmlFor={`q-${index}`} className="flex-1 font-normal">{option}</Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </CardContent>
        <CardFooter className="flex flex-col items-start gap-4">
          {!submitted && (
            <Button type="submit" disabled={!selectedAnswer}>
              Submit Answer
            </Button>
          )}
          {submitted && (
            <Alert variant={isCorrect ? "default" : "destructive"}>
              {isCorrect ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
              <AlertTitle>{isCorrect ? "Correct!" : "Incorrect"}</AlertTitle>
              <AlertDescription>
                {isCorrect
                  ? explanation
                  : `The correct answer is: "${correctAnswer}". ${explanation}`}
              </AlertDescription>
            </Alert>
          )}
        </CardFooter>
      </form>
    </Card>
  );
}

    