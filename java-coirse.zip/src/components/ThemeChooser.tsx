"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Palette } from "lucide-react";

const themes = [
    { name: 'Light', class: 'light' },
    { name: 'Dark', class: 'dark' },
    { name: 'Solarized', class: 'theme-solarized' },
    { name: 'Nord', class: 'theme-nord' },
    { name: 'Dracula', class: 'theme-dracula' },
    { name: 'Rosé Pine', class: 'theme-rose-pine' },
    { name: 'Gruvbox', class: 'theme-gruvbox' },
];

export function ThemeChooser() {
  const [theme, setTheme] = useState("light");
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    const savedTheme = localStorage.getItem("diploma-theme");
    const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
    setTheme(savedTheme || systemTheme);
  }, []);

  useEffect(() => {
    if (isMounted) {
      document.body.className = "";
      // The 'light' theme is the default (no class), so we only add a class if it's not light.
      if (theme !== 'light') {
        document.body.classList.add(theme);
      }
      localStorage.setItem("diploma-theme", theme);
    }
  }, [theme, isMounted]);

  if (!isMounted) {
    return null; // Don't render anything on the server to avoid hydration mismatches
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline">
          <Palette className="mr-2 h-4 w-4" />
          Change Theme
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56">
        <DropdownMenuLabel>Select Theme</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuRadioGroup value={theme} onValueChange={setTheme}>
          {themes.map((t) => (
            <DropdownMenuRadioItem key={t.class} value={t.class}>
              {t.name}
            </DropdownMenuRadioItem>
          ))}
        </DropdownMenuRadioGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
