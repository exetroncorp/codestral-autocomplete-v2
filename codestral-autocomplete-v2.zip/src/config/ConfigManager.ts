import * as vscode from 'vscode';

export interface CodestralConfig {
    apiKey: string;
    apiEndpoint: string;
    model: string;
    enabled: boolean;
    manualMode: boolean;
    debounceDelay: number;
    timeout: number;
    maxTokens: number;
    temperature: number;
    enableLogging: boolean;
    minTriggerChars: number;
    useCache: boolean;
    ignoreSslErrors: boolean;
}

export class ConfigManager {
    private static readonly EXTENSION_ID = 'codestral-autocomplete';

    static getConfig(): CodestralConfig {
        const config = vscode.workspace.getConfiguration(this.EXTENSION_ID);
        
        return {
            apiKey: config.get<string>('apiKey') || '',
            apiEndpoint: config.get<string>('apiEndpoint') || 'https://codestral.mistral.ai/v1/fim/completions',
            model: config.get<string>('model') || 'codestral-latest',
            enabled: config.get<boolean>('enabled') ?? true,
            manualMode: config.get<boolean>('manualMode') ?? false,
            debounceDelay: config.get<number>('debounceDelay') ?? 300,
            timeout: config.get<number>('timeout') ?? 10000,
            maxTokens: config.get<number>('maxTokens') ?? 32,
            temperature: config.get<number>('temperature') ?? 0.1,
            enableLogging: config.get<boolean>('enableLogging') ?? false,
            minTriggerChars: config.get<number>('minTriggerChars') ?? 2,
            useCache: config.get<boolean>('useCache') ?? true,
            ignoreSslErrors: config.get<boolean>('ignoreSslErrors') ?? false,
        };
    }

    static onConfigurationChanged(callback: () => void): vscode.Disposable {
        return vscode.workspace.onDidChangeConfiguration(event => {
            if (event.affectsConfiguration(this.EXTENSION_ID)) {
                callback();
            }
        });
    }

    static validateConfig(config: CodestralConfig): string[] {
        const errors: string[] = [];

        if (!config.apiKey.trim()) {
            errors.push('API key is required');
        }

        if (!config.apiEndpoint.trim()) {
            errors.push('API endpoint is required');
        }

        if (!config.model.trim()) {
            errors.push('Model name is required');
        }

        if (config.debounceDelay < 0) {
            errors.push('Debounce delay must be non-negative');
        }

        if (config.timeout <= 0) {
            errors.push('Timeout must be positive');
        }

        if (config.maxTokens <= 0) {
            errors.push('Max tokens must be positive');
        }

        if (config.temperature < 0 || config.temperature > 2) {
            errors.push('Temperature must be between 0 and 2');
        }

        if (config.minTriggerChars < 0) {
            errors.push('Minimum trigger characters must be non-negative');
        }

        return errors;
    }

    static async updateConfig(key: keyof CodestralConfig, value: any): Promise<void> {
        const config = vscode.workspace.getConfiguration(this.EXTENSION_ID);
        await config.update(key, value, vscode.ConfigurationTarget.Global);
    }
}

/**
 * Debouncer class for autocomplete requests
 * Adapted from Continue's implementation
 */
export class AutocompleteDebouncer {
    private timeoutId: NodeJS.Timeout | undefined;
    private lastRequestTime: number = 0;

    async delayAndShouldDebounce(delay: number): Promise<boolean> {
        return new Promise((resolve) => {
            const now = Date.now();
            this.lastRequestTime = now;

            if (this.timeoutId) {
                clearTimeout(this.timeoutId);
            }

            this.timeoutId = setTimeout(() => {
                // Only proceed if this is still the latest request
                if (this.lastRequestTime === now) {
                    resolve(false); // Don't debounce
                } else {
                    resolve(true); // Debounce (cancel this request)
                }
            }, delay);
        });
    }

    cancel(): void {
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = undefined;
        }
    }
}
