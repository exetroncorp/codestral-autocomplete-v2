import * as vscode from 'vscode';
import { CodestralClient } from './CodestralClient';
import { CodestralConfig, AutocompleteDebouncer } from '../config/ConfigManager';
import { Logger } from '../utils/Logger';
import { CompletionCache } from '../utils/CompletionCache';
import { StatusBarManager, StatusBarStatus } from '../utils/StatusBar';
import {
    processSingleLineCompletion,
    isSingleLineCompletion,
    getLastLineOfCompletion
} from '../utils/processSingleLineCompletion';

// Continue's AutocompleteInput interface
interface AutocompleteInput {
    pos: { line: number; character: number };
    manuallyPassFileContents?: string;
    manuallyPassPrefix?: string;
    selectedCompletionInfo?: vscode.SelectedCompletionInfo;
    injectDetails?: string;
    isUntitledFile: boolean;
    completionId: string;
    filepath: string;
    recentlyVisitedRanges?: any[];
    recentlyEditedRanges?: any[];
}

// Continue's AutocompleteOutcome interface
interface AutocompleteOutcome {
    completion: string;
    time: number;
    prefix: string;
    suffix: string;
    prompt: string;
    modelProvider?: string;
    modelName?: string;
    completionOptions?: any;
    cacheHit: boolean;
    filepath: string;
    numLines: number;
    completionId: string;
    gitRepo?: string;
    uniqueId?: string;
    timestamp: string;
}

export class CodestralCompletionProvider implements vscode.InlineCompletionItemProvider {
    private client: CodestralClient;
    private config: CodestralConfig;
    private logger: Logger;
    private cache: CompletionCache;
    private statusBar: StatusBarManager;
    private debouncer: AutocompleteDebouncer;
    private abortController: AbortController | undefined;

    constructor(
        client: CodestralClient,
        config: CodestralConfig,
        logger: Logger,
        statusBar: StatusBarManager
    ) {
        this.client = client;
        this.config = config;
        this.logger = logger;
        this.cache = CompletionCache.getInstance();
        this.statusBar = statusBar;
        this.debouncer = new AutocompleteDebouncer();
    }

    updateConfig(config: CodestralConfig): void {
        this.config = config;
        this.client.updateConfig(config);
        this.logger.setLoggingEnabled(config.enableLogging);
    }

    async provideInlineCompletionItems(
        document: vscode.TextDocument,
        position: vscode.Position,
        context: vscode.InlineCompletionContext,
        token: vscode.CancellationToken
    ): Promise<vscode.InlineCompletionItem[] | null> {
        // Continue's EXACT early returns
        if (!this.statusBar.isEnabled() || !this.config.enabled) {
            return null;
        }

        if (token.isCancellationRequested) {
            return null;
        }

        if (document.uri.scheme === "vscode-scm") {
            return null;
        }

        // Don't autocomplete with multi-cursor (Continue's check)
        const editor = vscode.window.activeTextEditor;
        if (editor && editor.selections.length > 1) {
            return null;
        }

        // Continue's selectedCompletionInfo handling
        const selectedCompletionInfo = context.selectedCompletionInfo;
        if (selectedCompletionInfo) {
            const { text, range } = selectedCompletionInfo;
            const typedText = document.getText(range);
            const typedLength = range.end.character - range.start.character;
            if (typedLength < 4) {
                return null;
            }
            if (!text.startsWith(typedText)) {
                return null;
            }
        }

        try {
            // Continue's abort controller setup
            const abortController = new AbortController();
            const signal = abortController.signal;
            token.onCancellationRequested(() => abortController.abort());

            // Continue's position handling
            const pos = {
                line: position.line,
                character: position.character,
            };

            // Continue's file contents handling
            let manuallyPassFileContents: string | undefined = undefined;
            if (document.isUntitled) {
                manuallyPassFileContents = document.getText();
            }

            // Continue's manual trigger detection
            const wasManuallyTriggered = context.triggerKind === vscode.InlineCompletionTriggerKind.Invoke;

            // Continue's AutocompleteInput structure
            const input: AutocompleteInput = {
                pos,
                manuallyPassFileContents,
                manuallyPassPrefix: undefined,
                selectedCompletionInfo,
                injectDetails: undefined,
                isUntitledFile: document.isUntitled,
                completionId: this.generateCompletionId(),
                filepath: document.uri.toString(),
                recentlyVisitedRanges: [],
                recentlyEditedRanges: [],
            };

            this.statusBar.setLoading(true);

            // Call Continue-style completion provider
            const outcome = await this.provideInlineCompletionItemsCore(input, signal, wasManuallyTriggered);

            if (!outcome || !outcome.completion) {
                return null;
            }

            // Continue's selectedCompletionInfo extension
            if (selectedCompletionInfo) {
                outcome.completion = selectedCompletionInfo.text + outcome.completion;
            }

            // Continue's range/text construction
            const startPos = selectedCompletionInfo?.range.start ?? position;
            let range = new vscode.Range(startPos, startPos);
            let completionText = outcome.completion;

            // Continue's EXACT single-line processing
            const isSingleLineCompletion = outcome.completion.split('\n').length <= 1;
            if (isSingleLineCompletion) {
                const lastLineOfCompletionText = completionText.split('\n').pop() || '';
                const currentText = document.lineAt(startPos).text.substring(startPos.character);
                const result = processSingleLineCompletion(
                    lastLineOfCompletionText,
                    currentText,
                    startPos.character,
                );
                if (result === undefined) {
                    return null;
                }
                completionText = result.completionText;
                if (result.range) {
                    range = new vscode.Range(
                        new vscode.Position(startPos.line, result.range.start),
                        new vscode.Position(startPos.line, result.range.end),
                    );
                }
            } else {
                // Extend the range to the end of the line for multiline completions
                range = new vscode.Range(startPos, document.lineAt(startPos).range.end);
            }

            const autocompleteCompletionItem = new vscode.InlineCompletionItem(completionText, range);
            (autocompleteCompletionItem as any).completeBracketPairs = true;

            return [autocompleteCompletionItem];

        } catch (error) {
            this.logger.error('Error in completion provider:', error);
            this.statusBar.setError(true);
            return null;
        } finally {
            this.statusBar.setLoading(false);
        }
    }

    /**
     * Continue-style core completion provider
     */
    private async provideInlineCompletionItemsCore(
        input: AutocompleteInput,
        signal: AbortSignal,
        wasManuallyTriggered: boolean
    ): Promise<AutocompleteOutcome | null> {
        try {
            const startTime = Date.now();

            // Get prefix and suffix (Continue-style)
            const { prefix, suffix } = await this.getCompletionContext(input);

            // Apply Continue's prefiltering
            if (!wasManuallyTriggered && this.shouldPrefilter(prefix, suffix, input)) {
                return null;
            }

            // Debounce for automatic triggers
            if (!wasManuallyTriggered) {
                const shouldDebounce = await this.debouncer.delayAndShouldDebounce(this.config.debounceDelay);
                if (shouldDebounce || signal.aborted) {
                    return null;
                }
            }

            // Check cache first
            let completion: string | null = null;
            if (this.config.useCache) {
                const cachedResult = this.cache.get(prefix, suffix);
                if (cachedResult) {
                    completion = cachedResult;
                    this.logger.log('Using cached completion');
                }
            }

            // Get completion from API if not cached
            if (!completion) {
                // Use Continue's EXACT streaming approach with filters
                completion = await this.getCompletionWithStreamFilters(prefix, suffix, input, signal);
                if (!completion || signal.aborted) {
                    return null;
                }

                // Cache the result
                if (this.config.useCache) {
                    this.cache.set(prefix, suffix, completion);
                }
            }

            // Create Continue-style outcome
            const outcome: AutocompleteOutcome = {
                completion,
                time: Date.now() - startTime,
                prefix,
                suffix,
                prompt: `[SUFFIX]${suffix}[PREFIX]${prefix}`, // Codestral FIM format
                modelProvider: 'mistral',
                modelName: this.config.model,
                completionOptions: {},
                cacheHit: completion !== null,
                filepath: input.filepath,
                numLines: completion.split('\n').length,
                completionId: input.completionId,
                timestamp: new Date().toISOString(),
            };

            return outcome;

        } catch (error) {
            this.logger.error('Error in core completion provider:', error);
            return null;
        }
    }

    private generateCompletionId(): string {
        return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    }

    private getLanguageFromFilepath(filepath: string): string {
        const ext = filepath.split('.').pop()?.toLowerCase();
        const languageMap: { [key: string]: string } = {
            'js': 'javascript',
            'ts': 'typescript',
            'py': 'python',
            'java': 'java',
            'cs': 'csharp',
            'cpp': 'cpp',
            'c': 'c',
            'go': 'go',
            'rs': 'rust',
            'php': 'php',
            'rb': 'ruby',
            'swift': 'swift',
            'kt': 'kotlin',
            'scala': 'scala',
        };
        return languageMap[ext || ''] || 'text';
    }

    private async getCompletionContext(input: AutocompleteInput): Promise<{ prefix: string; suffix: string }> {
        // Get file contents
        let fileContents: string;
        if (input.manuallyPassFileContents) {
            fileContents = input.manuallyPassFileContents;
        } else {
            // In a real implementation, you'd read from the IDE
            // For now, we'll use the active editor
            const editor = vscode.window.activeTextEditor;
            if (!editor) {
                return { prefix: '', suffix: '' };
            }
            fileContents = editor.document.getText();
        }

        const lines = fileContents.split('\n');
        const { line, character } = input.pos;

        // Calculate prefix (all text before cursor)
        let prefix = '';
        for (let i = 0; i < line; i++) {
            prefix += lines[i] + '\n';
        }
        if (line < lines.length) {
            prefix += lines[line].substring(0, character);
        }

        // Calculate suffix (all text after cursor)
        let suffix = '';
        if (line < lines.length) {
            suffix = lines[line].substring(character);
            for (let i = line + 1; i < lines.length; i++) {
                suffix += '\n' + lines[i];
            }
        }

        // Continue-style prefix/suffix pruning
        const maxPrefixLength = 2000;
        if (prefix.length > maxPrefixLength) {
            prefix = prefix.substring(prefix.length - maxPrefixLength);
        }

        const maxSuffixLength = 500;
        if (suffix.length > maxSuffixLength) {
            suffix = suffix.substring(0, maxSuffixLength);
        }

        return { prefix, suffix };
    }

    /**
     * Continue-style prefiltering
     */
    private shouldPrefilter(prefix: string, suffix: string, input: AutocompleteInput): boolean {
        // Don't offer completions when we have no information
        if (input.filepath.includes("Untitled") && prefix.trim() === "") {
            return true;
        }

        // Skip very large files
        if (prefix.length + suffix.length > 1024 * 1024) {
            return true;
        }

        return false;
    }

    private shouldTriggerCompletion(
        prefix: string,
        suffix: string,
        context: vscode.InlineCompletionContext,
        position: vscode.Position,
        document: vscode.TextDocument
    ): boolean {
        const currentLine = document.lineAt(position.line);
        const linePrefix = currentLine.text.substring(0, position.character);
        const lineSuffix = currentLine.text.substring(position.character);

        // Don't trigger in certain contexts
        if (this.isInSkipContext(linePrefix, lineSuffix)) {
            return false;
        }

        // For automatic triggers, apply Continue's conservative filtering
        if (context.triggerKind === vscode.InlineCompletionTriggerKind.Automatic) {
            // Don't trigger if we're at the very beginning of a line with no content
            if (linePrefix.trim().length === 0 && position.character === 0) {
                return false;
            }

            // Minimum character requirement - be more conservative
            if (linePrefix.trim().length < Math.max(this.config.minTriggerChars, 3)) {
                return false;
            }

            // Don't trigger immediately after opening brackets/quotes
            const lastChar = linePrefix.slice(-1);
            const skipChars = ['"', "'", '`', '(', '[', '{', '<'];
            if (skipChars.includes(lastChar)) {
                return false;
            }

            // Only trigger after specific characters or at end of words
            const triggerChars = ['.', ':', '=', ' ', '\t', ';', ',', ')', '}', ']'];
            const isAtWordEnd = linePrefix.length > 0 &&
                               /[a-zA-Z0-9_]/.test(linePrefix.slice(-1)) &&
                               (!lineSuffix.charAt(0) || !/[a-zA-Z0-9_]/.test(lineSuffix.charAt(0)));

            if (linePrefix.length > 0 && !triggerChars.includes(lastChar) && !isAtWordEnd) {
                return false;
            }

            // Don't trigger if we're in the middle of a word
            if (lineSuffix.charAt(0) && /[a-zA-Z0-9_]/.test(lineSuffix.charAt(0))) {
                return false;
            }

            // Don't trigger if the line already has substantial content after cursor
            if (lineSuffix.trim().length > 20) {
                return false;
            }
        }

        return true;
    }

    private isInSkipContext(linePrefix: string, lineSuffix: string): boolean {
        const trimmedPrefix = linePrefix.trim();

        // Skip in strings (more robust detection)
        const quoteCount = (linePrefix.match(/"/g) || []).length;
        const singleQuoteCount = (linePrefix.match(/'/g) || []).length;
        const backtickCount = (linePrefix.match(/`/g) || []).length;

        if (quoteCount % 2 === 1 || singleQuoteCount % 2 === 1 || backtickCount % 2 === 1) {
            return true;
        }

        // Skip in certain comment contexts - but be more permissive for continuing comments
        if (trimmedPrefix.startsWith('//')) {
            // Allow continuing single-line comments, but only if we're adding meaningful content
            const commentContent = trimmedPrefix.substring(2).trim();
            // Don't trigger if the comment is very short or just starting
            if (commentContent.length < 5) {
                return true;
            }
        }

        // Skip in block comments
        if (trimmedPrefix.startsWith('/*') && !linePrefix.includes('*/')) {
            return true;
        }

        // Skip if we're at the very end of a line that ends with certain characters
        const lastChar = linePrefix.slice(-1);
        if ([';', '{', '}', '(', ')', '[', ']'].includes(lastChar) && lineSuffix.trim().length === 0) {
            return true;
        }

        return false;
    }

    /**
     * Continue's shouldCompleteMultiline logic
     */
    private shouldCompleteMultiline(prefix: string, suffix: string, document: vscode.TextDocument, position: vscode.Position): boolean {
        // Don't complete multi-line for single-line comments
        const currentLine = document.lineAt(position.line);
        const linePrefix = currentLine.text.substring(0, position.character);

        // Check if we're in a single-line comment (Continue's logic)
        if (linePrefix.trimStart().startsWith('//')) {
            return false;
        }

        // For other cases, default to single-line for now (more conservative)
        return false;
    }

    private createCompletionItem(
        completion: string,
        document: vscode.TextDocument,
        position: vscode.Position,
        context: vscode.InlineCompletionContext,
        shouldBeMultiline: boolean = false
    ): vscode.InlineCompletionItem | null {
        if (!completion || completion.trim().length === 0) {
            return null;
        }

        const currentLine = document.lineAt(position.line);
        const linePrefix = currentLine.text.substring(0, position.character);
        const lineSuffix = currentLine.text.substring(position.character);

        // Handle single-line completions using Continue's logic
        if (isSingleLineCompletion(completion)) {
            const lastLineOfCompletion = getLastLineOfCompletion(completion);
            const result = processSingleLineCompletion(
                lastLineOfCompletion,
                lineSuffix,
                position.character
            );

            if (!result) {
                return null;
            }

            let range = new vscode.Range(position, position);
            if (result.range) {
                range = new vscode.Range(
                    new vscode.Position(position.line, result.range.start),
                    new vscode.Position(position.line, result.range.end)
                );
            }

            return new vscode.InlineCompletionItem(result.completionText, range);
        }

        // Handle multi-line completions
        // For multi-line, extend range to end of current line to replace any existing content
        const range = new vscode.Range(position, currentLine.range.end);

        // Clean up the completion for multi-line
        let cleanedCompletion = this.cleanMultilineCompletion(completion, linePrefix);

        return new vscode.InlineCompletionItem(cleanedCompletion, range);
    }

    private cleanMultilineCompletion(completion: string, linePrefix: string): string {
        // Remove any leading whitespace that would duplicate existing indentation
        const lines = completion.split('\n');
        if (lines.length === 0) return completion;

        // Keep the first line as-is for inline completion
        const firstLine = lines[0];
        const restLines = lines.slice(1);

        // For subsequent lines, ensure proper indentation
        const baseIndent = this.getIndentation(linePrefix);
        const indentedRestLines = restLines.map(line => {
            if (line.trim().length === 0) return line;
            return baseIndent + line.trimStart();
        });

        return [firstLine, ...indentedRestLines].join('\n');
    }

    private getIndentation(line: string): string {
        const match = line.match(/^(\s*)/);
        return match ? match[1] : '';
    }

    /**
     * Continue's EXACT streaming approach with filters
     */
    private async getCompletionWithStreamFilters(
        prefix: string,
        suffix: string,
        input: AutocompleteInput,
        signal: AbortSignal
    ): Promise<string | null> {
        try {
            // Get raw completion from API
            const rawCompletion = await this.client.getCompletion(
                prefix,
                suffix,
                this.getLanguageFromFilepath(input.filepath),
                signal
            );

            if (!rawCompletion || signal.aborted) {
                return null;
            }

            // Apply Continue's EXACT stream transform pipeline
            const filteredCompletion = await this.applyStreamTransformPipeline(
                rawCompletion,
                prefix,
                suffix,
                input
            );

            return filteredCompletion;
        } catch (error) {
            this.logger.error('Error in stream filtering:', error);
            return null;
        }
    }

    /**
     * Continue's EXACT StreamTransformPipeline implementation - COMPLETE REWRITE
     */
    private async applyStreamTransformPipeline(
        completion: string,
        prefix: string,
        suffix: string,
        input: AutocompleteInput
    ): Promise<string | null> {
        let shouldStop = false;
        const fullStop = () => { shouldStop = true; };

        // Apply Continue's EXACT order from StreamTransformPipeline.ts

        // 1. Character-level filters first (Continue's exact order)
        let filteredCompletion = completion;

        // stopAtStopTokens (Continue's char filter)
        const stopTokens = ["[PREFIX]", "[SUFFIX]", "```", "diff --git"];
        filteredCompletion = this.stopAtStopTokens(filteredCompletion, stopTokens);

        // stopAtStartOf (Continue's char filter for suffix)
        if (suffix.trim().length > 0) {
            filteredCompletion = this.stopAtStartOf(filteredCompletion, suffix);
        }

        // 2. Convert to line stream (Continue's streamLines approach)
        let lines = filteredCompletion.split('\n');

        // 3. stopAtLines (Continue's FIRST line filter - CRITICAL!)
        this.logger.log(`Before stopAtLines: ${lines.length} lines`);
        lines = this.stopAtLines(lines, fullStop);
        this.logger.log(`After stopAtLines: ${lines.length} lines, shouldStop: ${shouldStop}`);
        if (shouldStop) return this.joinLinesWithProperFormatting(lines);

        // 4. stopAtLinesExact (Continue's second filter)
        const lineBelowCursor = this.getLineBelowCursor(input);
        if (lineBelowCursor.trim() !== "") {
            lines = this.stopAtLinesExact(lines, fullStop, [lineBelowCursor]);
            if (shouldStop) return this.joinLinesWithProperFormatting(lines);
        }

        // 5. stopAtRepeatingLines (Continue's third filter)
        lines = this.stopAtRepeatingLines(lines, fullStop);
        if (shouldStop) return this.joinLinesWithProperFormatting(lines);

        // 6. avoidEmptyComments (Continue's fourth filter)
        lines = this.avoidEmptyComments(lines);

        // 7. avoidPathLine (Continue's fifth filter)
        lines = this.avoidPathLine(lines);

        // 8. skipPrefixes (Continue's sixth filter)
        lines = this.skipPrefixes(lines);

        // 9. noDoubleNewLine (Continue's seventh filter)
        lines = this.noDoubleNewLine(lines);

        // 10. stopAtSimilarLine (Continue's eighth filter)
        lines = this.stopAtSimilarLine(lines, lineBelowCursor, fullStop);
        if (shouldStop) return this.joinLinesWithProperFormatting(lines);

        // 11. Apply formatting fixes AFTER filtering
        let result = this.joinLinesWithProperFormatting(lines);
        result = this.fixFormattingIssues(result);

        // 12. Apply Continue's EXACT postprocessing
        return this.postprocessCompletion(result, prefix, suffix);
    }

    /**
     * Continue's EXACT stopAtRepeatingLines implementation
     */
    private stopAtRepeatingLines(lines: string[], fullStop: () => void): string[] {
        const result: string[] = [];
        let previousLine: string | undefined;
        let repeatCount = 0;
        const MAX_REPEATS = 3; // Continue's exact value

        for (const line of lines) {
            if (line === previousLine) {
                repeatCount++;
                if (repeatCount === MAX_REPEATS) {
                    fullStop();
                    break;
                }
            } else {
                result.push(line);
                repeatCount = 1;
            }
            previousLine = line;
        }

        return result;
    }

    /**
     * Continue's EXACT stopAtSimilarLine implementation
     */
    private stopAtSimilarLine(lines: string[], targetLine: string, fullStop: () => void): string[] {
        const result: string[] = [];
        const trimmedTarget = targetLine.trim();

        for (const line of lines) {
            if (trimmedTarget === "") {
                result.push(line);
                continue;
            }

            if (line === targetLine) {
                fullStop();
                break;
            }

            if (this.lineIsRepeated(line, trimmedTarget)) {
                fullStop();
                break;
            }

            result.push(line);
        }

        return result;
    }

    /**
     * Get line below cursor (Continue's helper)
     */
    private getLineBelowCursor(input: AutocompleteInput): string {
        // In a real implementation, you'd get this from the file
        // For now, return empty to be safe
        return "";
    }

    /**
     * Continue's EXACT stream filtering pipeline (legacy method)
     */
    private async applyStreamFilters(completion: string, prefix: string, suffix: string): Promise<string | null> {
        // Convert completion to line stream
        const lines = completion.split('\n');

        // Apply Continue's EXACT filters in order
        let filteredLines = lines;

        // 1. Filter English explanations at start
        filteredLines = this.filterEnglishLinesAtStart(filteredLines);

        // 2. Filter code block markers (legacy method - remove this)
        // filteredLines = this.filterCodeBlockLines(filteredLines);

        // 3. Remove trailing whitespace
        filteredLines = filteredLines.map(line => line.trimEnd());

        // 4. Stop at English post-explanations
        filteredLines = this.filterEnglishLinesAtEnd(filteredLines);

        // 5. Remove useless lines
        filteredLines = filteredLines.filter(line => !this.isUselessLine(line));

        const filteredCompletion = filteredLines.join('\n');

        // Apply basic postprocessing
        return this.postprocessCompletion(filteredCompletion, prefix, suffix);
    }

    /**
     * Continue's EXACT filterEnglishLinesAtStart
     */
    private filterEnglishLinesAtStart(lines: string[]): string[] {
        const result: string[] = [];
        let i = 0;
        let wasEnglishFirstLine = false;

        for (const line of lines) {
            if (i === 0 && line.trim() === "") {
                continue;
            }
            if (i === 0) {
                if (this.isEnglishFirstLine(line)) {
                    wasEnglishFirstLine = true;
                    i++;
                    continue;
                }
            } else if (i === 1 && wasEnglishFirstLine && line.trim() === "") {
                i++;
                continue;
            }
            i++;
            result.push(line);
        }

        return result;
    }



    /**
     * Continue's EXACT filterEnglishLinesAtEnd
     */
    private filterEnglishLinesAtEnd(lines: string[]): string[] {
        const result: string[] = [];
        let finishedCodeBlock = false;

        for (const line of lines) {
            if (line.trim() === "```") {
                finishedCodeBlock = true;
            }
            if (finishedCodeBlock && this.isEnglishPostExplanation(line)) {
                break;
            }
            result.push(line);
        }

        return result;
    }

    /**
     * Continue's EXACT postprocessing logic for Codestral
     */
    private postprocessCompletion(completion: string, prefix: string, suffix: string): string | null {
        // Don't return empty (Continue's isBlank check)
        if (completion.trim().length === 0) {
            return null;
        }

        // Don't return whitespace only (Continue's isOnlyWhitespace check)
        const whitespaceRegex = /^[\s]+$/;
        if (whitespaceRegex.test(completion)) {
            return null;
        }

        // Don't return if it's just a repeat of the line above (Continue's rewritesLineAbove)
        if (this.rewritesLineAbove(completion, prefix)) {
            return null;
        }

        // Filter out extreme repetitions (Continue's isExtremeRepetition)
        if (this.isExtremeRepetition(completion)) {
            return null;
        }

        // Continue's EXACT Codestral-specific postprocessing
        if (this.config.model.includes('codestral')) {
            // Codestral sometimes starts with an extra space
            if (completion[0] === ' ' && completion[1] !== ' ') {
                if (prefix.endsWith(' ') && suffix.startsWith('\n')) {
                    completion = completion.slice(1);
                }
            }

            // When there is no suffix, Codestral tends to begin with a new line
            // We do this to avoid double new lines
            if (suffix.length === 0 && prefix.endsWith('\n\n') && completion.startsWith('\n')) {
                // Remove a single leading \n from the completion
                completion = completion.slice(1);
            }
        }

        // If prefix ends with space and so does completion, then remove the space from completion
        if (prefix.endsWith(' ') && completion.startsWith(' ')) {
            completion = completion.slice(1);
        }

        return completion;
    }

    /**
     * Continue's EXACT rewritesLineAbove implementation
     */
    private rewritesLineAbove(completion: string, prefix: string): boolean {
        const lineAbove = prefix
            .split('\n')
            .filter((line) => line.trim().length > 0)
            .slice(-1)[0];

        if (!lineAbove) {
            return false;
        }

        const firstLineOfCompletion = completion
            .split('\n')
            .find((line) => line.trim().length > 0);

        if (!firstLineOfCompletion) {
            return false;
        }

        // Continue's lineIsRepeated logic (simplified)
        return this.lineIsRepeated(lineAbove, firstLineOfCompletion);
    }

    /**
     * Continue's lineIsRepeated logic
     */
    private lineIsRepeated(line1: string, line2: string): boolean {
        // Simple implementation of Continue's line repetition detection
        const trimmed1 = line1.trim();
        const trimmed2 = line2.trim();

        if (trimmed1 === trimmed2) {
            return true;
        }

        // Check if one line is contained in the other (common repetition pattern)
        if (trimmed1.length > 0 && trimmed2.length > 0) {
            return trimmed1.includes(trimmed2) || trimmed2.includes(trimmed1);
        }

        return false;
    }

    /**
     * Continue's EXACT isExtremeRepetition implementation
     */
    private isExtremeRepetition(completion: string): boolean {
        const lines = completion.split('\n');
        if (lines.length < 6) {
            return false;
        }

        const MAX_REPETITION_FREQ_TO_CHECK = 3;

        for (let freq = 1; freq < MAX_REPETITION_FREQ_TO_CHECK; freq++) {
            const lcs = this.longestCommonSubsequence(lines[0], lines[freq]);
            if (lcs.length > 5 || lcs.length > lines[0].length * 0.5) {
                let matchCount = 0;
                for (let i = 0; i < lines.length; i += freq) {
                    if (lines[i].includes(lcs)) {
                        matchCount++;
                    }
                }
                if (matchCount * freq > 8 || (matchCount * freq) / lines.length > 0.8) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Continue's longestCommonSubsequence implementation
     */
    private longestCommonSubsequence(str1: string, str2: string): string {
        const m = str1.length;
        const n = str2.length;
        const dp: number[][] = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));

        for (let i = 1; i <= m; i++) {
            for (let j = 1; j <= n; j++) {
                if (str1[i - 1] === str2[j - 1]) {
                    dp[i][j] = dp[i - 1][j - 1] + 1;
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
                }
            }
        }

        // Reconstruct the LCS
        let lcs = '';
        let i = m, j = n;
        while (i > 0 && j > 0) {
            if (str1[i - 1] === str2[j - 1]) {
                lcs = str1[i - 1] + lcs;
                i--;
                j--;
            } else if (dp[i - 1][j] > dp[i][j - 1]) {
                i--;
            } else {
                j--;
            }
        }

        return lcs;
    }

    /**
     * Continue's EXACT filterCodeBlockLines implementation
     */
    private filterCodeBlockLines(lines: string[], fullStop: () => void): string[] {
        const result: string[] = [];
        let seenFirstFence = false;
        let nestCount = 0;

        for (const line of lines) {
            if (!seenFirstFence) {
                if (this.shouldRemoveLineBeforeStart(line)) {
                    // Filter out starting ``` or START block
                    continue;
                }
                // Regardless of a fence or START block start tracking the nesting level
                seenFirstFence = true;
                nestCount = 1;
            }

            if (nestCount > 0) {
                // Inside a block including the outer block
                const changedEndLine = this.shouldChangeLineAndStop(line);
                if (typeof changedEndLine === "string") {
                    // Ending a block with just backticks (```) or STOP
                    nestCount--;
                    if (nestCount === 0) {
                        // if we are closing the outer block then exit early
                        fullStop();
                        return result;
                    } else {
                        // otherwise just add the line
                        result.push(line);
                    }
                } else if (line.startsWith("```")) {
                    // Going into a nested codeblock - STOP HERE for inline ```java
                    fullStop();
                    return result;
                } else {
                    // otherwise just add the line
                    result.push(line);
                }
            }
        }

        return result;
    }

    /**
     * Stop at any ```java or ``` blocks that appear mid-completion
     */
    private stopAtCodeBlocks(lines: string[], fullStop: () => void): string[] {
        const result: string[] = [];

        for (const line of lines) {
            const trimmed = line.trim();

            // Stop at any line that starts with ``` (markdown code blocks)
            if (trimmed.startsWith("```")) {
                fullStop();
                break;
            }

            result.push(line);
        }

        return result;
    }

    /**
     * Fix formatting issues in completion (CRITICAL for newline problems)
     */
    private fixFormattingIssues(completion: string): string {
        // Fix the specific issue: missing newlines before class declarations, etc.
        let fixed = completion;

        // Add newlines before class declarations
        fixed = fixed.replace(/([;}])(public\s+class\s+)/g, '$1\n$2');

        // Add newlines before method declarations
        fixed = fixed.replace(/([;}])(public\s+\w+\s+\w+\s*\()/g, '$1\n$2');
        fixed = fixed.replace(/([;}])(private\s+\w+\s+\w+\s*\()/g, '$1\n$2');

        // Add newlines before field declarations
        fixed = fixed.replace(/([;}])(private\s+\w+\s+\w+;)/g, '$1\n    $2');

        // Fix compressed code like "JFrame {    private"
        fixed = fixed.replace(/(\{)(\s*)(private|public|protected)/g, '$1\n    $3');

        // Fix missing newlines after semicolons in field declarations
        fixed = fixed.replace(/(;\s*)(private|public|protected)\s+/g, ';\n    $2 ');

        // Fix missing newlines after closing braces
        fixed = fixed.replace(/(\})\s*(public|private|protected)/g, '$1\n$2');

        return fixed;
    }

    /**
     * Continue's EXACT character-level filters
     */
    private stopAtStopTokens(completion: string, stopTokens: string[]): string {
        if (stopTokens.length === 0) {
            return completion;
        }

        for (const stopToken of stopTokens) {
            const index = completion.indexOf(stopToken);
            if (index !== -1) {
                return completion.substring(0, index);
            }
        }

        return completion;
    }

    private stopAtStartOf(completion: string, suffix: string, sequenceLength: number = 20): string {
        if (suffix.length < sequenceLength) {
            return completion;
        }

        const targetPart = suffix.trimStart().slice(0, Math.floor(sequenceLength * 1.5));

        // Simple implementation - look for suffix content in completion
        const index = completion.indexOf(targetPart);
        if (index !== -1) {
            return completion.substring(0, index);
        }

        return completion;
    }

    /**
     * Continue's EXACT joinLinesWithProperFormatting
     */
    private joinLinesWithProperFormatting(lines: string[]): string {
        // Continue's approach: preserve original formatting and ensure proper newlines
        if (lines.length === 0) return '';

        // Filter out empty lines at the end
        while (lines.length > 0 && lines[lines.length - 1].trim() === '') {
            lines.pop();
        }

        // Join with newlines, ensuring proper formatting
        return lines.join('\n');
    }

    /**
     * Continue's EXACT avoidEmptyComments
     */
    private avoidEmptyComments(lines: string[]): string[] {
        const singleLineComment = "//"; // Java comment syntax
        return lines.filter(line => {
            return !singleLineComment || line.trim() !== singleLineComment;
        });
    }

    /**
     * Continue's EXACT stopAtLines implementation (CRITICAL - first line filter)
     */
    private stopAtLines(lines: string[], fullStop: () => void): string[] {
        // Continue's EXACT LINES_TO_STOP_AT from lineStream.ts
        const LINES_TO_STOP_AT = [
            "```",
            "```java",
            "```python",
            "```javascript",
            "```typescript",
            "```cpp",
            "```c",
            "```go",
            "```rust",
            "```php",
            "```ruby",
            "```swift",
            "```kotlin",
            "```scala",
            "```html",
            "```css",
            "```sql",
            "```shell",
            "```bash",
            "```powershell",
            "```dockerfile",
            "```yaml",
            "```json",
            "```xml",
            "```markdown",
            "```md",
        ];

        // Continue's EXACT ENGLISH_START_PHRASES
        const ENGLISH_START_PHRASES = [
            "here is",
            "here's",
            "sure, here",
            "sure thing",
            "sure!",
            "sure,",
            "sure.",
            "to fill",
            "certainly",
            "of course",
            "the code should",
            "below is",
            "sure! below",
            "it looks like",
            "you're on the right track",
            "this code creates",
            "this will create",
            "this creates",
            "the above code",
            "this program",
            "this application",
            "let's complete",
            "we'll add",
            "we need to",
            "let's add",
        ];

        const result: string[] = [];

        for (const line of lines) {
            const trimmed = line.trim().toLowerCase();
            this.logger.log(`Checking line: "${trimmed}"`);

            // Stop at code block markers
            if (LINES_TO_STOP_AT.some(stopLine => trimmed.startsWith(stopLine))) {
                this.logger.log(`Stopping at code block: "${trimmed}"`);
                fullStop();
                break;
            }

            // Stop at English explanations (Continue's logic)
            if (ENGLISH_START_PHRASES.some(phrase => trimmed.startsWith(phrase))) {
                this.logger.log(`Stopping at English phrase: "${trimmed}"`);
                fullStop();
                break;
            }

            // Stop at lines ending with colon (explanations)
            if (trimmed.endsWith(":") && !this.isCodeKeywordEndingInColon(trimmed)) {
                this.logger.log(`Stopping at colon line: "${trimmed}"`);
                fullStop();
                break;
            }

            result.push(line);
        }

        return result;
    }

    /**
     * Continue's EXACT stopAtLinesExact implementation
     */
    private stopAtLinesExact(lines: string[], fullStop: () => void, exactLines: string[]): string[] {
        const result: string[] = [];

        for (const line of lines) {
            if (exactLines.some(exactLine => line.trim() === exactLine.trim())) {
                fullStop();
                break;
            }
            result.push(line);
        }

        return result;
    }

    /**
     * Continue's EXACT helper methods for stream filtering
     */
    private avoidPathLine(lines: string[]): string[] {
        return lines.filter(line => !line.startsWith("// Path: "));
    }

    private skipPrefixes(lines: string[]): string[] {
        const PREFIXES_TO_SKIP = [""];
        if (lines.length === 0) return lines;

        const firstLine = lines[0];
        const match = PREFIXES_TO_SKIP.find((prefix) => firstLine.startsWith(prefix));
        if (match) {
            return [firstLine.slice(match.length), ...lines.slice(1)];
        }
        return lines;
    }

    private noDoubleNewLine(lines: string[]): string[] {
        const result: string[] = [];
        let isFirstLine = true;

        for (const line of lines) {
            if (line.trim() === "" && !isFirstLine) {
                break; // Stop at first empty line after content
            }
            isFirstLine = false;
            result.push(line);
        }
        return result;
    }

    /**
     * Continue's EXACT helper methods for filtering
     */
    private isEnglishFirstLine(line: string): boolean {
        const ENGLISH_START_PHRASES = [
            "here is",
            "here's",
            "sure, here",
            "sure thing",
            "sure!",
            "to fill",
            "certainly",
            "of course",
            "the code should",
            "below is",
            "sure! below",
            "it looks like",
            "you're on the right track",
            "this code creates",
            "this will create",
            "this creates",
            "the above code",
            "this program",
            "this application",
        ];

        const trimmed = line.trim().toLowerCase();
        if (trimmed.endsWith(":") && !this.isCodeKeywordEndingInColon(trimmed)) {
            return true;
        }
        return ENGLISH_START_PHRASES.some((phrase) => trimmed.startsWith(phrase));
    }

    private isCodeKeywordEndingInColon(line: string): boolean {
        const CODE_KEYWORDS_ENDING_IN_COLON = ["def", "class", "if", "for", "while", "try", "except", "with"];
        return CODE_KEYWORDS_ENDING_IN_COLON.some((keyword) => line.startsWith(keyword));
    }

    private isEnglishPostExplanation(line: string): boolean {
        const ENGLISH_POST_PHRASES = [
            "explanation:",
            "here is",
            "here's how",
            "the above",
            "it looks like",
            "you're on the right track",
            "this code creates",
            "this will create",
            "this creates",
            "the above code",
            "this program",
            "this application",
        ];
        const lower = line.toLowerCase();
        return ENGLISH_POST_PHRASES.some((phrase) => lower.startsWith(phrase));
    }

    private shouldRemoveLineBeforeStart(line: string): boolean {
        const LINES_TO_REMOVE_BEFORE_START = [
            "",
            "[CODE]",
            "",
            "{{FILL_HERE}}",
        ];

        // Continue's EXACT logic - remove any line starting with ```
        const trimmed = line.trimStart();
        if (trimmed.startsWith("```")) {
            return true;
        }

        return LINES_TO_REMOVE_BEFORE_START.some((l) => line.trim() === l);
    }

    private shouldChangeLineAndStop(line: string): string | undefined {
        const CODE_STOP_BLOCK = "[/CODE]";
        if (line.trimStart() === "```") {
            return line;
        }
        if (line.includes(CODE_STOP_BLOCK)) {
            return line.split(CODE_STOP_BLOCK)[0].trimEnd();
        }
        return undefined;
    }

    private isUselessLine(line: string): boolean {
        const USELESS_LINES = [""];
        const trimmed = line.trim().toLowerCase();
        const hasUselessLine = USELESS_LINES.some(
            (uselessLine) => trimmed === uselessLine,
        );
        return hasUselessLine || trimmed.startsWith("// end");
    }

    dispose(): void {
        this.debouncer.cancel();
        if (this.abortController) {
            this.abortController.abort();
        }
    }
}
